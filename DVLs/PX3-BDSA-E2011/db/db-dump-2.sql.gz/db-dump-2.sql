-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Vært: localhost
-- Genereringstid: 02. 12 2011 kl. 00:01:38
-- Serverversion: 5.0.51
-- PHP-version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `px3`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `action`
--

CREATE TABLE IF NOT EXISTS `action` (
  `id` int(11) NOT NULL auto_increment,
  `label` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Data dump for tabellen `action`
--


-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `permission`
--

CREATE TABLE IF NOT EXISTS `permission` (
  `action_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY  (`action_id`,`user_id`),
  KEY `Person_Action_Action1` (`action_id`),
  KEY `fk_permission_user1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `permission`
--


-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `person`
--

CREATE TABLE IF NOT EXISTS `person` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `address` text,
  `cpr` int(11) NOT NULL,
  `eligible_to_vote` tinyint(1) NOT NULL,
  `has_voted` tinyint(1) NOT NULL,
  `place_of_birth` varchar(255) default NULL,
  `passport_number` int(11) default NULL,
  `voting_venue_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `person_voting_venue1` (`voting_venue_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Data dump for tabellen `person`
--

INSERT INTO `person` (`id`, `name`, `address`, `cpr`, `eligible_to_vote`, `has_voted`, `place_of_birth`, `passport_number`, `voting_venue_id`) VALUES
(1, 'Hans Hansen', 'Rued Langgaardsvej 7\r\n2300 København S', 2103762234, 1, 0, 'Roskilde Amts Sygehus', 1235213461, 0),
(2, 'Jonas Schmidt', 'Æblehaven 37\r\n4215 Bogense', 406971367, 0, 0, 'Odense', NULL, 0),
(3, 'Michael Valentin', 'Rued Langgaardsvej 16, 6. sal, 641\r\n2300 København S', 2006912489, 1, 0, 'Gentofte', 1234512345, 0),
(6, 'Morten Hyllekilde', 'Lange Müllers Gade 27, 3 th\r\n2100 København Ø', 1234567891, 1, 0, 'Odense', 1231231234, 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `quiz`
--

CREATE TABLE IF NOT EXISTS `quiz` (
  `id` int(11) NOT NULL auto_increment,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `person_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `quiz_person1` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Data dump for tabellen `quiz`
--


-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `raw_data`
--

CREATE TABLE IF NOT EXISTS `raw_data` (
  `cpr` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mother_cpr` int(11) default NULL,
  `father_cpr` int(11) default NULL,
  `address` text,
  `last_address` text,
  PRIMARY KEY  (`cpr`),
  KEY `raw_data_raw_data` (`mother_cpr`),
  KEY `raw_data_raw_data1` (`father_cpr`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `raw_data`
--


-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL auto_increment,
  `user_name` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `person_id` int(11) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `user_name_UNIQUE` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Data dump for tabellen `user`
--


-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `voter_card`
--

CREATE TABLE IF NOT EXISTS `voter_card` (
  `id` int(11) NOT NULL auto_increment,
  `person_id` int(11) NOT NULL,
  `valid` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `voter_card_Person1` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Data dump for tabellen `voter_card`
--


-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `voting_venue`
--

CREATE TABLE IF NOT EXISTS `voting_venue` (
  `id` int(11) NOT NULL auto_increment,
  `address` text NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Data dump for tabellen `voting_venue`
--

INSERT INTO `voting_venue` (`id`, `address`, `name`) VALUES
(1, 'Lars Bjørns Allé 17\r\n2300 København S', 'Storebjerg Skolen'),
(2, 'Merkurvej 71\r\n2100 København Ø', 'Øserbro Bibliotek');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `workplace`
--

CREATE TABLE IF NOT EXISTS `workplace` (
  `user_id` int(11) NOT NULL,
  `voting_venue_id` int(11) NOT NULL,
  PRIMARY KEY  (`user_id`,`voting_venue_id`),
  KEY `user_voting_venue_voting_venue1` (`voting_venue_id`),
  KEY `user_voting_venue_user1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `workplace`
--


--
-- Begrænsninger for dumpede tabeller
--

--
-- Begrænsninger for tabel `permission`
--
ALTER TABLE `permission`
  ADD CONSTRAINT `fk_permission_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `Person_Action_Action1` FOREIGN KEY (`action_id`) REFERENCES `action` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Begrænsninger for tabel `person`
--
ALTER TABLE `person`
  ADD CONSTRAINT `person_voting_venue1` FOREIGN KEY (`voting_venue_id`) REFERENCES `voting_venue` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Begrænsninger for tabel `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_person1` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Begrænsninger for tabel `raw_data`
--
ALTER TABLE `raw_data`
  ADD CONSTRAINT `raw_data_raw_data` FOREIGN KEY (`mother_cpr`) REFERENCES `raw_data` (`cpr`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `raw_data_raw_data1` FOREIGN KEY (`father_cpr`) REFERENCES `raw_data` (`cpr`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Begrænsninger for tabel `voter_card`
--
ALTER TABLE `voter_card`
  ADD CONSTRAINT `voter_card_Person1` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Begrænsninger for tabel `workplace`
--
ALTER TABLE `workplace`
  ADD CONSTRAINT `user_voting_venue_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `user_voting_venue_voting_venue1` FOREIGN KEY (`voting_venue_id`) REFERENCES `voting_venue` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
