<?php

passthru("java -jar ../Boothprompt.jar");

?>



