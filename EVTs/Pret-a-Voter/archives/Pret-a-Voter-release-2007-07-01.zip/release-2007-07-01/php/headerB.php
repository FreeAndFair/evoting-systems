<?php 
function writeheadA() {
?><html>
<head>
<title><? echo($titleprefix) ?> - Election07 USSU:Pr&ecirc;t &agrave; Voter</title>
<style>
body {
	text-align: center;
	min-width: 400px;
	font-size: medium;
	background-color:white;
}

#superbox {
	margin:0 auto;
/*	width:600px;   */
	width: 50em;
	text-align: left;
	background-color:white;
}

#header {
	margin:0;
	width:100%;
	height:11em;
}

#headlinks {
	margin-top:2em;
	border:0;
	width:30%;
	float:left;
	text-align:right;
	font-family:"Bitstream Charter",Charter,"Zapf Chancery","Times New Roman",serif;
	font-size:large;
	color:#111571;
}

#headimage {
	margin-top:2em;
	border:0;
	width:60%;
	float:left;
	vertical-align:middle;
}

#headvider {
	width:0.3em;
	margin-left:1em;
	margin-right:1em;
	border:none;
	float:left;
	background-color:#111571;
	height:100%;
} 

#titleimage {
	margin:0;
	border:0;
	width:100%;
}

#main {
	margin-top:3em;
	width:100%;
}

#mainlinks {
	margin-top:2em;
	border:0;
	width:30%;
	float:left;
	text-align:right;
	font-family:"Bitstream Charter",Charter,serif;
	font-size:large;
	color:black;
}

#mainvider {
	width:0.3em;
	margin-left:1em;
	margin-right:1em;
	border:none;
	float:left;
	background-color:#b3b3b3;
	height:20em;
} 

#maintitle {
	font-family:"Bitstream Charter",Charter,serif;
	font-size:x-large;
	color:#111571;
}

#maincontent {
	font-family:"Bitstream Charter",Charter,serif;
	margin-top:2em;
	border:0;
	width:60%;
	float:left;
}

/* RV */
#ballot {
	width:24em;
	height:130%;
	margin:0;
	border-bottom:2px solid black;
}

.candidate {
	height: 8%;
	/*border: 2px solid black;*/
	margin:0;
}

.race {
	border-top: 2px solid black;
	padding: 2px;
	padding-left:2em;
	padding-right:2em;
	margin:0;
}

.racename {
	float:left;
	width:13em;
	margin:0;
	font-size:medium;
	/*border:2px dashed green;*/
}

.candidatebox {
	width:7em;
	float:right;
	margin:0;
	text-align:left;
	/*border:2px solid red;*/
}

.error {
	color:red;
}

.warning {
	color:#880000; /* dark red */
}
<?
}

function writeheadB() {
?></style>
<?
}

function writeheadC() {
?>
</head>
<body><div id="superbox">

<div id="header">
    <div id="headlinks">
Pr&ecirc;t &agrave; Voter?<br />
Where's my vote?<br />
Audit interface<br />
Where can I vote?<br />
    </div>
    <div id="headvider">
      <!-- nowt -->&nbsp;
    </div>
    <div id="headimage">
      <img src="title1000b.png" id="titleimage" />
    </div>
</div>

<div id="main">
<?
}