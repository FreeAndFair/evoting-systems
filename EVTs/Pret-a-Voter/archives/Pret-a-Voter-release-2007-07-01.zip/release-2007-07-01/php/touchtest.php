<?php 
exec("echo 'this' >> whoami.log");
?>