function ui.set_for_partial_load()
  ui._partial_load = true
end