function ui.is_for_partial_load()
  return ui._partial_load
end