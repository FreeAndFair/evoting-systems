db:query("BEGIN;")

execute.inner()

db:query("COMMIT;")