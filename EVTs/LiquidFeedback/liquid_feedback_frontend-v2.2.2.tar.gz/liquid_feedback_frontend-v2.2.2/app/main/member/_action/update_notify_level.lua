app.session.member.notify_level = param.get("notify_level")
app.session.member:save()
