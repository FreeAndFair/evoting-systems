app.html_title.title = _("Member menu")

execute.view{
  module = "index",
  view = "_menu"
}

