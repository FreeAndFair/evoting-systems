ui.title("404 Not found")

ui.container{ content = "Page not found" }
