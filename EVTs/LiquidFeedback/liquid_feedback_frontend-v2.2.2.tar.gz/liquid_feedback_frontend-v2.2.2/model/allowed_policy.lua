AllowedPolicy = mondelefant.new_class()
AllowedPolicy.table = 'allowed_policy'
AllowedPolicy.primary_key = { "area_id", "policy_id" }
