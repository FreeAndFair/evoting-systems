RenderedVoterComment = mondelefant.new_class()
RenderedVoterComment.table = 'rendered_voter_comment'
RenderedVoterComment.primary_key = { "issue_id", "member_id", "format" }
