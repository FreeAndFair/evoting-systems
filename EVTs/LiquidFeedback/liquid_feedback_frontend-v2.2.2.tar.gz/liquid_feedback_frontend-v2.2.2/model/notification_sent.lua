NotificationSent = mondelefant.new_class()
NotificationSent.table = 'notification_sent'
