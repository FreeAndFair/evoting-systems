FEEDBACK


VHTi is based on the concept of transparent provable elections. We believe that public disclosure of our protocols and reference source code is essential to providing this transparency. It is important that voters have confidence that their vote is cast and counted as intended. This is achieved by an open, transparent voting system.

In order to fully understand VHTi, refer to both the Protocols and the Reference Source Code. The Protocols can be found http://www.votehere.com/documents.html. The VHTi Reference Source Code Implementation includes the VHTi_KnownIssues document that outlines known issues, instructions to build the source and samples. 

How to provide feedback
We welcome constructive feedback as part of this review process. You can submit any feedback you have to vhtifeedback@votehere.com. We will address any valid issues and/or suggestions.


This material is subject to the VoteHere Source Code Evaluation License Agreement (�Agreement�).  Possession and/or use of this material indicates your acceptance of this Agreement in its entirety.  Copies of the Agreement may be found at www.votehere.net.

Copyright 2004 VoteHere, Inc.  All Rights Reserved


