# 
# This material is subject to the VoteHere Source Code Evaluation
# License Agreement ("Agreement").  Possession and/or use of this
# material indicates your acceptance of this Agreement in its entirety.
# Copies of the Agreement may be found at www.votehere.net.
# 
# Copyright 2004 VoteHere, Inc.  All Rights Reserved
# 
# You may not download this Software if you are located in any country
# (or are a national of a country) subject to a general U.S. or
# U.N. embargo or are deemed to be a terrorist country (i.e., Cuba,
# Iran, Iraq, Libya, North Korea, Sudan and Syria) by the United States
# (each a "Prohibited Country") or are otherwise denied export
# privileges from the United States or Canada ("Denied Person").
# Further, you may not transfer or re-export the Software to any such
# country or Denied Person without a license or authorization from the
# U.S. government.  By downloading the Software, you represent and
# warrant that you are not a Denied Person, are not located in or a
# national of a Prohibited Country, and will not export or re-export to
# any Prohibited Country or Denied Party.
use 5.008;
use ExtUtils::MakeMaker;
# See lib/ExtUtils/MakeMaker.pm for details of how to influence
# the contents of the Makefile that is written.

# If you change this path to .../lib/debug/..., then
# you'll probably also want to edit examples/go.sh, and
# change the `true' to `false'

my $ODIR   = "../../lib";
my $OBJECT = $ODIR."/vhti_dll.dll";
if ($^O =~ /MSWIN/io) {
  $OBJECT = $ODIR."/vhti_dll.lib";
}

WriteMakefile(
    'NAME'		=> 'VHTI_XS',
    'VERSION_FROM'	=> 'VHTI.pm', # finds $VERSION
    'PREREQ_PM'		=> {}, # e.g., Module::Name => 1.1
    'LIBS'		=> [], # e.g., '-lm'
    'DEFINE'		=> '', # e.g., '-DHAVE_SOMETHING'
    'INC'		=> '-I. -I../../../include/vhti/ -I../../../include/', # e.g., '-I. -I/usr/include/other'
    'OBJECT'		=> '$(O_FILES) '.$OBJECT,
);
