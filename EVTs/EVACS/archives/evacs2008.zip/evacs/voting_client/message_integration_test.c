/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "message.c"

/* Stubs required: should never be called. */
unsigned int get_language(void)
{
	abort();
}

void wait_for_reset(void)
{
	abort();
}

struct audio *get_audio(const char *fmt, ...)
{
	return NULL;
}

void play_audio(bool interrupt, struct audio *audio)
{
}

int main()
{
	struct image *img;

	img = get_message(1, MSG_SWIPE_BARCODE_TO_BEGIN);
	exit(0);
}
