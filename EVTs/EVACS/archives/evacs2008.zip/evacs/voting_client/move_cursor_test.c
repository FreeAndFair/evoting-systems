/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "move_cursor.c"
#include <stdlib.h>
#include <unistd.h>
#include <common/evacs.h>
#include "verify_barcode.h"
#include "vote_in_progress.h"
#include "get_rotation.h"
#include "initiate_session.h"
#include <common/voter_electorate.h>
#include "audio.h"

struct ballot_contents *bc;
struct electorate *voter_electorate;
/* Set Default Language to English */
static unsigned int language = 0; 
static struct rotation *curr_rotation;
static struct preference_set prefs = { 1, { { 1, 2, 1 } } };
static struct rotation rot7 = { 7, { 7, 6, 5, 4, 1, 2, 3 } };


void get_event(void);

void get_event(void)
{
	return;
}


unsigned int get_language(void)
{
	return(language);
}          

void wait_for_reset(void)
{
        /* get_event handles RESET internally */
        while (true) get_event();
}

const struct rotation *get_current_rotation(void)
{
	return curr_rotation;
}

const struct preference_set *get_vote_in_progress(void)
{
	return &prefs;
}

const struct electorate *get_voter_electorate(void)
{
	return voter_electorate;
}

struct ballot_contents *get_ballot_contents(void)
{
	return bc;
}

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

struct audio *get_audio(const char *fmt, ...)
{
	return NULL;
}

void play_audio(bool interrupt, struct audio *audio)
{
}

int main(int argc, const char *argv[])
{
	char electorate_name[9];
	int i, j;
	struct cursor cursor, new_cursor;
	enum input_event next;
	struct image *ballot_h_image;
	
	/* TEST DDS3.2.12: Get Cursor Position */
	/* TEST DDS3.2.12: Set Cursor Position */
	cursor = get_cursor_position();
	if (cursor.group_index != 0) exit(1);
	if (cursor.screen_candidate_index != -1) exit(1);
	new_cursor.group_index = 3;
	new_cursor.screen_candidate_index = 2;
	set_cursor_position(new_cursor);
	cursor = get_cursor_position();
	if (cursor.group_index != 3) exit(1);
	if (cursor.screen_candidate_index != 2) exit(1);
	
	/* setup data for move_cursor test */
	curr_rotation = &rot7;

	bc = malloc(sizeof(struct ballot_contents) + sizeof(unsigned int)*8);

	bc->num_groups = 8;
	bc->num_candidates[0] = 4;
	bc->num_candidates[1] = 2;
	bc->num_candidates[2] = 1;
	bc->num_candidates[3] = 3;
	bc->num_candidates[4] = 2;
	bc->num_candidates[5] = 2;
	bc->num_candidates[6] = 4;
	bc->num_candidates[7] = 3;
	
	strcpy(electorate_name,"Molonglo");

	voter_electorate = malloc(sizeof(struct electorate) 
				  + strlen(electorate_name)+1);

	voter_electorate->code = 1;
	voter_electorate->num_seats = 5;
	strcpy(voter_electorate->name, "Molonglo");

	/* Set up screen */
	if(!initialise_display(false))
                exit(1);
	
	ballot_h_image = get_bh_image(0, voter_electorate);
	paste_image(0,0,ballot_h_image);

	for (cursor.group_index = 0;
	     cursor.group_index < 8;
	     cursor.group_index++) {
		for (cursor.screen_candidate_index = -1;
		     cursor.screen_candidate_index 
			     < (int)bc->num_candidates[cursor.group_index];
		     cursor.screen_candidate_index++) {
			draw_group_entry(cursor,NO);
		}	
	}
		
	cursor.group_index = 0;
	cursor.screen_candidate_index = -1;
	draw_group_entry(cursor,YES);
	
	if (argc == 2) sleep(1);
	set_cursor_position(cursor);
	
	/* TEST DDS3.2.12: Move Cursor */
	for (i=0;i<5;i++) {
		next = INPUT_DOWN;
		move_cursor(next);
		if (argc == 2) sleep(1);
	}
	cursor = get_cursor_position();
	if ((cursor.group_index != 0) || (cursor.screen_candidate_index != 0))
		exit(1);

	for (i=0;i<6;i++) {
		next = INPUT_NEXT;
		move_cursor(next);
		if (argc == 2) sleep(1);
	}
	cursor = get_cursor_position();
	if ((cursor.group_index != 6) || (cursor.screen_candidate_index != -1))
		exit(1);

	for (i=0;i<6;i++) {
		next = INPUT_UP;
		move_cursor(next);
		if (argc == 2) sleep(1);
	}
	cursor = get_cursor_position();
	if ((cursor.group_index != 6) || (cursor.screen_candidate_index != 2))
		exit(1);

	for (i=0;i<6;i++) {
		next = INPUT_PREVIOUS;
		move_cursor(next);
		if (argc == 2) sleep(1);
		for (j=0;j<2;j++) {
			next = INPUT_DOWN;
			move_cursor(next);
			if (argc == 2) sleep(1);
		}
	}
	cursor = get_cursor_position();
	if ((cursor.group_index != 0) || (cursor.screen_candidate_index != 1))
		exit(1);

	if (argc == 2) sleep(2);

	/* TEST DDS3.2.12: Update Cursor Position */
	cursor.group_index = 3;
	cursor.screen_candidate_index = 1;
	update_ccp(cursor, INPUT_DOWN);
	cursor = get_cursor_position();
	if ((cursor.group_index != 3) || (cursor.screen_candidate_index != 2))
		exit(1);
	update_ccp(cursor, INPUT_NEXT);
	cursor = get_cursor_position();
	if ((cursor.group_index != 4) || (cursor.screen_candidate_index != -1))
		exit(1);
	update_ccp(cursor, INPUT_UP);
	cursor = get_cursor_position();
	if ((cursor.group_index != 4) || (cursor.screen_candidate_index != 1))
		exit(1);
	update_ccp(cursor, INPUT_PREVIOUS);
	cursor = get_cursor_position();
	if ((cursor.group_index != 3) || (cursor.screen_candidate_index != -1))
		exit(1);

	/* TEST DDS3.2.12: Get Number of Groups in Electorate */
	if (get_num_gps_electorate() != bc->num_groups) exit(1);
	
	/* TEST DDS3.2.12: Get Number of Candidates in Group */
	if (get_num_cands_in_gp(2) != bc->num_candidates[2]) exit(1);

	exit(0);
}
