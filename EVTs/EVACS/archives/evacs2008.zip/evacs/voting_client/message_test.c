/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "message.c"

/* We include http.c directly here, so we can override it to force failure */
extern char *_http_get_file(const char *servername,
			    uint16_t portnum,
			    const char *page);
#define http_get_file _http_get_file
#include <common/http.c>
#undef http_get_file

#include <common/socket.h>
#include <fcntl.h>
#include <stdbool.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <signal.h>
#include <setjmp.h>

static bool fail;

/* Our http_get_file */
char *http_get_file(const char *servername,
		    uint16_t portnum,
		    const char *page)
{
	if (fail) return NULL;
	else return _http_get_file(servername, portnum, page);
}

static jmp_buf jmpbuf;
static bool jmpbuf_set = false;

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

/* This is our replacement "wait_for_reset()", which jumps back to the
   main code */
void wait_for_reset(void)
{
	if (!jmpbuf_set) abort();
	longjmp(jmpbuf, 1);
}

/* This is our replacement get_language() */
unsigned int get_language(void)
{
	return 1;
}

struct audio *get_audio(const char *fmt, ...)
{
	return NULL;
}

void play_audio(bool interrupt, struct audio *audio)
{
}


/* Args used by shell script to check root size is correct */
int main(int argc, const char *argv[])
{
	struct image *val;

	jmpbuf_set = false;
	/* TEST DDS3.2.14: Get Message */
	fail = 0;
	val = get_message(1, MSG_ERROR);
	if (image_width(val) != 1152) exit(1);
	if (image_height(val) != 432) exit(1);

	/* Test cache */
	fail = 1;
	if (get_message(1, MSG_ERROR) != val) exit(1);

	/* TEST DDS3.2.14: Get Preference Number Image */
	fail = 0;
	val = get_preference_image(0, 18);
	if (image_width(val) != 30) exit(1);
	if (image_height(val) != 30) exit(1);
	/* Test cache */
	fail = 1;
	if (get_preference_image(0,18) != val) exit(1);

	/* TEST DDS3.2.12: Get Group Image */
	fail = 0;
	val = get_group_image(0, 2);
	if (image_width(val) != 288) exit(1);
	if (image_height(val) != 30) exit(1);
	/* Test cache */
	fail = 1;
	if (get_group_image(0, 2) != val) exit(1);

	/* TEST DDS3.2.12: Get Candidate Image */
	fail = 0;
	val = get_candidate_image(0, 2, 6);
	if (image_width(val) != 258) exit(1);
	if (image_height(val) != 30) exit(1);
	/* Test cache */
	fail = 1;
	if (get_candidate_image(0, 2, 6) != val) exit(1);

	/* TEST DDS????: Get Candidate With Group Image */
	fail = 0;
	val = get_cand_with_group_img(0, 2, 6);
	if (image_width(val) != 258) exit(1);
	if (image_height(val) != 30) exit(1);
	/* Test cache */
	fail = 1;
	if (get_cand_with_group_img(0, 2, 6) != val) exit(1);

	/* Try drawing it on screen */
	if (!initialise_display(false)) exit(1);
	paste_image(0,0,val);

	/* TEST DDS????: Display Error */
	/* Returns non-zero when coming back from display_error */
	if (setjmp(jmpbuf) == 0) {
		jmpbuf_set = true;
		/* Images chosen such that they are already cached */
		fail = 0;
		display_error((enum error)18);
	}

	/* Should even work when "server" is down */
	if (setjmp(jmpbuf) == 0) {
		/* Images chosen such that they are NOT already cached */
		fail = 1;
		display_error(ERR_INTERNAL);
	}

	exit(0);
}
