/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "confirm_vote.c"
#include "initiate_session.h"

static struct preference_set vip;
static enum input_event *in_events;
static bool verify_ok;
static bool did_commit = false;

static struct {
	struct electorate elec;
	char name[80];
} elec = {{ NULL, 3, 7 }, "TEST ELECTORATE"};

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

/* Stubs */
const struct preference_set *get_vote_in_progress(void)
{
	return &vip;
}

const struct electorate *get_voter_electorate(void)
{
	return &elec.elec;
}

enum input_event get_keystroke_or_barcode(struct barcode *bc)
{
	return *(in_events++);
}

bool verify_barcode(struct barcode *bc)
{
	return verify_ok;
}

void commit_vote(struct barcode *bc)
{
	did_commit = true;
}

unsigned int get_language(void)
{
	abort();
}

void wait_for_reset(void)
{
	abort();
}

struct audio *get_audio(const char *fmt, ...)
{
	return NULL;
}

void play_audio(bool interrupt, struct audio *audio)
{
}

void play_audio_loop(bool interrupt, struct audio *audio)
{
}

void play_multiaudio_loop(bool interrupt, 
			  unsigned int num_samples,
			  struct audio *audio[num_samples])
{
}

int main()
{
	enum input_event events[10];
	if (!initialise_display(false)) exit(1);

	/* TEST DDS3.2.24: Display Confirmation Screen */
	vip.num_preferences = 5;
	vip.candidates[0].group_index = 1;
	vip.candidates[0].db_candidate_index = 0;
	vip.candidates[1].group_index = 1;
	vip.candidates[1].db_candidate_index = 1;
	vip.candidates[2].group_index = 1;
	vip.candidates[2].db_candidate_index = 2;
	vip.candidates[3].group_index = 1;
	vip.candidates[3].db_candidate_index = 3;
	vip.candidates[4].group_index = 1;
	vip.candidates[4].db_candidate_index = 4;

	format_confirm_screen(0);
	sleep(1);
	vip.num_preferences = 0;
	format_confirm_screen(0);
	sleep(1);

	/* TEST DDS3.2.22: Formate Hidden Vote Screen */
	format_hidden_vote_screen(0);
	sleep(1);

	/* TEST DDS3.2.22: Confirm and Commit Vote */
	events[0] = INPUT_UNDO;
	in_events = events;
	if (confirm_and_commit_vote(0) != true) exit(1);
	if (in_events != &events[1]) exit(1);
	if (did_commit) exit(1);

	events[0] = INPUT_SELECT;
	events[1] = INPUT_UNDO;
	in_events = events;
	if (confirm_and_commit_vote(0) != true) exit(1);
	if (in_events != &events[2]) exit(1);
	if (did_commit) exit(1);

	events[0] = INPUT_BARCODE;
	verify_ok = true;
	did_commit = false;
	in_events = events;
	if (confirm_and_commit_vote(0) != false) exit(1);
	if (in_events != &events[1]) exit(1);
	if (!did_commit) exit(1);

	events[0] = INPUT_BARCODE;
	events[1] = INPUT_UNDO;
	verify_ok = false;
	did_commit = false;
	in_events = events;
	if (confirm_and_commit_vote(0) != true) exit(1);
	if (in_events != &events[2]) exit(1);
	if (did_commit) exit(1);

	/* Should be the same with votes on the screen */
	vip.num_preferences = 5;
	events[0] = INPUT_UNDO;
	in_events = events;
	if (confirm_and_commit_vote(0) != true) exit(1);
	if (in_events != &events[1]) exit(1);
	if (did_commit) exit(1);

	events[0] = INPUT_SELECT;
	events[1] = INPUT_UNDO;
	in_events = events;
	if (confirm_and_commit_vote(0) != true) exit(1);
	if (in_events != &events[2]) exit(1);
	if (did_commit) exit(1);

	events[0] = INPUT_BARCODE;
	verify_ok = true;
	did_commit = false;
	in_events = events;
	if (confirm_and_commit_vote(0) != false) exit(1);
	if (in_events != &events[1]) exit(1);
	if (!did_commit) exit(1);

	events[0] = INPUT_BARCODE;
	events[1] = INPUT_UNDO;
	verify_ok = false;
	did_commit = false;
	in_events = events;
	if (confirm_and_commit_vote(0) != true) exit(1);
	if (in_events != &events[2]) exit(1);
	if (did_commit) exit(1);

	exit(0);
}
