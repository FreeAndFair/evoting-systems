/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "image.c"
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <common/socket.h>

#define TEST_IMAGE "voting_client/test_data/arabic.png"

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

/* stub */
char *http_get(const char *servername,
	       uint16_t portnum,
	       const char *page,
	       size_t *size)
{
	struct stat stbuf;
	int fd;
	char *buf;
	size_t done;

	fd = open(TEST_IMAGE, O_RDONLY);
	if (fd < 0) exit(1);
	if (fstat(fd, &stbuf) < 0) exit(1);

	*size = stbuf.st_size;
	buf = malloc(*size);
	done = 0;
	while (done < *size) {
		int r;
		r = read(fd, buf + done, *size - done);
		if (r <= 0) exit(1);
		done += r;
	}
	return buf;
}

int main(int argc, char *argv[])
{
	struct image *img;

	if (!initialise_display(true)) exit(1);

	/* TEST DDS3.2.11: Get Screen Width */
	if (get_screen_width() != WINDOW_WIDTH) exit(1);

	/* TEST DDS?????: Get Screen Height */
	if (get_screen_height() != WINDOW_HEIGHT) exit(1);

	/* Shell script test */
	if (argc == 2) {
		if (get_screen_width() != atoi(argv[1])) {
			fprintf(stderr, "Screen width reported as %u\n",
				get_screen_width());
			exit(1);
		}
		exit(0);
	}

	img = get_image(IMAGE_BASE "1/4.png", true);
	paste_image(0, 0, img);
	if (img->width != 432) exit(1);
	if (img->height != 102) exit(1);
	if (!img->image) exit(1);

	/* TEST DDS3.2.12: Highlight Image */
	{
		struct image *newimg;

		newimg = highlight_image(img);
		if (newimg->height != img->height
		    || newimg->width != img->width)
			exit(1);
		paste_image(0, img->height, newimg);
	}
	
	if (!clear_screen()) exit(1);

	/* Much of the rest is tested in message_test.c */
	exit(0);
}
