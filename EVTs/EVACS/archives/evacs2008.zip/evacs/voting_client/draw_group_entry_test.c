/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "draw_group_entry.c"
#include <stdlib.h>
#include <unistd.h>
#include "get_rotation.h"
#include "vote_in_progress.h"
#include "initiate_session.h"
#include <common/authenticate.h>
#include "input.h"
#include <common/ballot_contents.h>

static struct rotation rot7 = { 7, { 7, 6, 5, 4, 1, 2, 3 } };
static struct rotation *curr_rotation;
static struct preference_set prefs = { 1, { { 1, 2, 1 } } };

struct ballot_contents *bc;
struct electorate *voter_electorate;
/* Set Default Language to English */
static unsigned int language = 0; 

void get_event(void);

void get_event(void)
{
	return;
}


unsigned int get_language(void)
{
	return(language);
}          

void wait_for_reset(void)
{
        /* get_event handles RESET internally */
        while (true) get_event();
}

const struct rotation *get_current_rotation(void)
{
	return curr_rotation;
}

const struct preference_set *get_vote_in_progress(void)
{
	return &prefs;
}

const struct electorate *get_voter_electorate(void)
{
	return voter_electorate;
}

struct ballot_contents *get_ballot_contents(void)
{
	return bc;
}

struct audio *get_audio(const char *fmt, ...)
{
	return NULL;
}

void play_audio(bool interrupt, struct audio *audio)
{
}

int main(int argc, char *argv[])
{
	char electorate_name[9];
	struct cursor cursor;
	struct image *ballot_h_image;
	struct coordinates coords;
	unsigned int size = 0;

	curr_rotation = &rot7;

	if(!initialise_display(false))
                exit(1);
	
	bc = malloc(sizeof(struct ballot_contents) + sizeof(unsigned int)*8);

	bc->num_groups = 8;
	bc->num_candidates[0] = 4;
	bc->num_candidates[1] = 2;
	bc->num_candidates[2] = 1;
	bc->num_candidates[3] = 5;
	bc->num_candidates[4] = 3;
	bc->num_candidates[5] = 2;
	bc->num_candidates[6] = 4;
	bc->num_candidates[7] = 3;
	
	strcpy(electorate_name,"Molonglo");

	voter_electorate = malloc(sizeof(struct electorate) 
				  + strlen(electorate_name)+1);

	voter_electorate->code = 1;
	voter_electorate->num_seats = 5;
	strcpy(voter_electorate->name, "Molonglo");

	/*TEST DDS3.2.12: Calculate Cursor Coordinates */
	coords = calc_curs_coord(0,-1);
	if (coords.x != 0) exit(1);
	if (coords.y != 144) exit(1);
	coords = calc_curs_coord(5,2);
	if (coords.x != 288) exit(1);
	if (coords.y != 684) exit(1);

	/* TEST DDS3.2.12: Get Cursor Coordinates */
	cursor.group_index = 6;
	cursor.screen_candidate_index = 3;
	coords = get_cursor_coordinates(cursor);
	if (coords.x != 576) exit(1);
	if (coords.y != 744) exit(1);

	/* TEST DDS3.2.12: Get Preference Image Size */
	size = get_preference_image_size(voter_electorate);
	if (size <= 0) exit(1);

	/* TEST DDS3.2.12: Get Group Width */
	size = 0;
	size = get_group_width(voter_electorate);
	if (size <= 0) exit(1);

	/* TEST DDS3.2.12: Get Ballot Heading Height */
	size = get_ballot_h_height(voter_electorate);
	if (size != 144) exit(1);

	ballot_h_image = get_bh_image(0, voter_electorate);
	paste_image(0,0,ballot_h_image);

	/* TEST DDS3.2.12: Draw Group Entry */
	for (cursor.group_index = 0;
	     cursor.group_index < 8;
	     cursor.group_index++) {
		for (cursor.screen_candidate_index = -1;
		     cursor.screen_candidate_index 
			     < (int)bc->num_candidates[cursor.group_index];
		     cursor.screen_candidate_index++) {
			draw_group_entry(cursor,NO);
		}	
	}
		
	cursor.group_index = 0;
	cursor.screen_candidate_index = -1;
	draw_group_entry(cursor,YES);

	if (argc == 2) sleep(5);

	exit(0);
}
