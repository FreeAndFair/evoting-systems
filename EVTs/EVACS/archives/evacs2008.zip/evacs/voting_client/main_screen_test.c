/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "main_screen.c"
#include "input.h"
#include <stdlib.h>
#include <unistd.h>

struct ballot_contents *bc;
struct electorate *voter_electorate;
/* Set Default Language to English */
static unsigned int language = 0; 

void get_event(void);

void get_event(void)
{
	return;
}


unsigned int get_language(void)
{
	return(language);
}          


enum input_event get_keystroke_or_barcode(struct barcode *bc)
{ 
	return 0;
}

/* Wait for end of the world */
void wait_for_reset(void)
{
        /* get_event handles RESET internally */
        while (true) get_event();
}


void draw_group_entry(struct cursor cp, bool HlFlag)
{
	return;
}

/* Draw a blank groun entry */
void draw_blank_entry(unsigned int group_index, int screen_index)
{
	return;
}

unsigned int groups_possible(void)
{
	return 0;
}

const struct electorate *get_voter_electorate(void)
{
	return voter_electorate;
}

struct ballot_contents *get_ballot_contents(void)
{
	return bc;
}

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

int main(void)
{
	/* TEST DDS3.2.8: Display Main Voting Screen */
	/* TEST DDS3.12: Display DEO Ballot Screen */
	char electorate_name[9];
	struct image *image;

	audio_init();
	if (!initialise_display(false))
		exit(1);
	
	bc = malloc(sizeof(struct ballot_contents) + sizeof(unsigned int)*3);

	bc->num_groups = 3;
	bc->num_candidates[0] = 3;
	bc->num_candidates[1] = 2;
	bc->num_candidates[2] = 5;

	strcpy(electorate_name,"Molonglo");

	voter_electorate = malloc(sizeof(struct electorate) 
				  + strlen(electorate_name)+1);

	voter_electorate->code = 1;
	voter_electorate->num_seats = 7;
	strcpy(voter_electorate->name, "Molonglo");

	/* TEST DDS3.2.8: Get Ballot Heading Image */
	image = get_bh_image(0, voter_electorate);
	if (!image) exit(1);
	dsp_mn_vt_scn();

	sleep(1);
	
	exit(0);
}

