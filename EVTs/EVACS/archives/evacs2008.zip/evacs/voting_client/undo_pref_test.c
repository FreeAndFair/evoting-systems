/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "undo_pref.c"
#include <stdlib.h>
#include <unistd.h>
#include "get_rotation.h"
#include "vote_in_progress.h"
#include "initiate_session.h"
#include <common/authenticate.h>
#include "input.h"
#include "verify_barcode.h"
#include <common/voter_electorate.h>

static struct rotation rot5 = { 5, { 1, 2, 3, 4, 5 } };
static struct rotation *curr_rotation;
static struct preference_set prefs = { 3, { { 3,2,1 },{ 3,4,2 },{ 2,0,3 } } };
struct ballot_contents bc = {8,{4,2,1,5,3,2,4,3}};
struct electorate *voter_electorate;
static unsigned int language = 0; 
void get_event(void);
/* Stubs */
void get_event(void)
{
	return;
}

void add_candidate(unsigned int group_index,
                   unsigned int db_candidate_index)
{
        prefs.candidates[prefs.num_preferences]
                .group_index = group_index;
        prefs.candidates[prefs.num_preferences]
                .db_candidate_index = db_candidate_index;
        prefs.num_preferences++;
}

unsigned int get_language(void)
{
	return(language);
}          

void wait_for_reset(void)
{
       while (true) get_event();
}

const struct rotation *get_current_rotation(void)
{
	return curr_rotation;
}

const struct preference_set *get_vote_in_progress(void)
{
	return &prefs;
}

bool remove_last_pref(struct preference *undone_pref)
{
	if (prefs.num_preferences == 0)
		return false;
	prefs.num_preferences--;
	*undone_pref = prefs.candidates
		[prefs.num_preferences];
	return true;
}

const struct electorate *get_voter_electorate(void)
{
	return voter_electorate;
}

struct ballot_contents *get_ballot_contents(void)
{
	return &bc;
}

struct audio *get_audio(const char *fmt, ...)
{
	return NULL;
}

void play_audio(bool interrupt, struct audio *audio)
{
}

int main(int argc, char *argv[])
{
	/* TEST DDS3.2.18: Undo Preference */
	char electorate_name[9];
	struct cursor cursor;
	struct image *ballot_h_image;
	int i, candidate_index;

	curr_rotation = &rot5;
	
	if(!initialise_display(false))
                exit(1);
	
	/* Setup data */
	strcpy(electorate_name,"Molonglo");

	voter_electorate = malloc(sizeof(struct electorate) 
				  + strlen(electorate_name)+1);

	voter_electorate->code = 1;
	voter_electorate->num_seats = 5;
	strcpy(voter_electorate->name, "Molonglo");

	/* Set up screen */
	ballot_h_image = get_bh_image(0, voter_electorate);
	paste_image(0,0,ballot_h_image);

	for (cursor.group_index = 0;
	     cursor.group_index < 8;
	     cursor.group_index++) {
		for (cursor.screen_candidate_index = -1;
		     cursor.screen_candidate_index 
			     < (int)bc.num_candidates[cursor.group_index];
		     cursor.screen_candidate_index++) {
			draw_group_entry(cursor,NO);
		}	
	}
		
	/* TEST3.2.18: Move Cursor to Candidate */
	move_cursor_to_cand(7,2);
	cursor = get_cursor_position();
	if (cursor.group_index != 7) exit(1);
	if (cursor.screen_candidate_index != 2) exit(1);

	if (argc == 2) sleep(1);
	/* TEST3.2.18: Undo Preference */
	/* TEST3.2.18: Unhighlight Current Candidate */
	if (prefs.num_preferences != 3) exit(1);

	for (i=0; i<3; i++) {
		undo_pref();
		if (argc == 2) sleep(1);
		if (prefs.num_preferences != 2-i) exit(1);
		if (i<2) {
			cursor = get_cursor_position();
			if (cursor.group_index 
			    != prefs.candidates[2-i].group_index) exit(1);
			candidate_index = translate_dbci_to_sci(5,
			    prefs.candidates[2-i].db_candidate_index, &rot5);
			if (cursor.screen_candidate_index != candidate_index) 
				exit(1);
		}
	}
	

	exit(0);
}
