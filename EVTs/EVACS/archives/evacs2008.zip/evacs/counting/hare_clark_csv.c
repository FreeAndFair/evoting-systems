/* This file is (C) copyright 2001-2004 Software Improvements, Pty */
/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <common/evacs.h>
#include "hare_clark.h"
/* #include "fetch.h" */
#include "report.h"
#include "ballot_iterators.h"
#include "candidate_iterators.h"
#include "count.h"


enum action {
	TITLE=0,
	ELECTORATE,
	VACANCIES,
	GROUP,
	CANDIDATE,
	VOTES,
	INVALID,
};
const char *keyword[7]={(const char *)  "ELECTION TITLE",
			( const char *) "ELECTORATE",
			( const char *) "VACANCIES",
			( const char *) "GROUP",
			( const char *) "CANDIDATE",
			( const char *) "VOTES",
			( const char *) "UNKNOWN KEYWORD",
};

enum action get_action_code(char *action_str);
enum action get_action_code(char *action_str) 
{
	enum action i;
	for (i=TITLE; i<=INVALID; i++) {
		if (i == INVALID) break;
		if (strcasecmp(action_str,keyword[i])==0) {
			break;
		}
	}
	return i;
}

void parse_error(char *filename, unsigned int linenumber, enum action command);
void parse_error(char *filename, unsigned int linenumber, enum action command)
     /*
       Print a message 
     */
{
	fprintf(stderr,"Error in %s line %u while processing %s\n",filename,linenumber,keyword[command]);

}

void bailout(const char *fmt, ...);
void bailout(const char *fmt, ...)
     /*
       Print a message and exit fatally.
     */
{
  va_list arglist;

  va_start(arglist,fmt);
 
  /* Default handler */
  fprintf(stderr,"FATAL: ");
  vfprintf(stderr,fmt,arglist);

  va_end(arglist);
  
  exit(1);
}

char *sprintf_malloc(const char *fmt, ...);
char *sprintf_malloc(const char *fmt, ...)
     /*
       Variable number of parameter interface to vsprintf_malloc().
     */
     
{
  char *str;
  va_list arglist;
  
  va_start(arglist,fmt);
  str = vsprintf_malloc(fmt,arglist);
  va_end(arglist);
  
  return(str);
}


char *vsprintf_malloc(const char *fmt, va_list arglist);
char *vsprintf_malloc(const char *fmt, va_list arglist)
     /*
       This is a self-allocating vsprintf function.
       
       NOTE: This function allocates memory. It is
       the callers responsibility to free it after
       use. Also, this function does not call va_end.
       It is the callers responsibility to do this.
      */

{
  char *str=NULL;

  /* Allocate amount of space indicated by vsnprintf */

  str = (char *)malloc(vsnprintf(str,0,fmt,arglist)+1);

  /* Write into string for real this time */

  vsprintf(str,fmt,arglist);
  return(str);
}
static int strip_nl(char *s);
static int strip_nl(char *s)
     /*
       Return true (1) if string s contained a trailing newline. The
       string s will be returned minus this character.

       Otherwise return false (0), string s is untouched.
     */
{
  int len=strlen(s)-1;

  if (len >= 0 && s[len] == '\n') {
    s[len] = '\0';
    return(1);
  }
  else
    return(0);
}

char *fgets_malloc(FILE *stream);
char *fgets_malloc(FILE *stream)
     /*
       Returns a pointer to the next line of text read from
       the stream.

       NOTE: This function allocates memory if end of file
       was not encountered and no characters were copied to
       the string. It is the callers responsibility
       to free it after use. If end of file was encountered
       then the memory is released before return.
     */
{ 
  char *str;
  int start=0,empty_size,size=128;
  
  str = malloc(size);
  *str = '\0';
  empty_size = size;
  
  /* Loop until newline or EOF encountered */

  while (1) {
    if ( fgets(&str[start],empty_size,stream) == NULL ) { /* end-of-file ? */
      if ( *str == '\0' ) {  /* and nothing in the buffer */
	free(str);
	return(NULL);  /* then return NULL*/
      }
      else {
	strip_nl(str);
	break;   /* otherwise return string */
      }
    }
    
    if (strip_nl(str))  /* If string contained a newline at the end */
      break;      /* then return it */

    /* Newline not hit - double buf size and read some more */

    start += size-1;    
    empty_size = size+1;  /* We score one extra byte due to null terminator */
    size *= 2;
    str = realloc(str,size);
  }
  
  return(str);
}

/* allocates a ballot structure . Caller must free*/
static struct ballot *load_vote(const char *preference_list);
static struct ballot *load_vote(const char *preference_list)
{
	struct ballot *ballot;
	char *pref[PREFNUM_MAX]; 
	char *pref_ptr;
	unsigned int num_preferences=0,i;
	unsigned int pref_number, group_index, db_cand_index;

	pref[0]= (char *)preference_list;
    
	while ((int) (pref[num_preferences+1]=strchr(pref[num_preferences],44)+1) != 1)
		num_preferences++;
	
	ballot = malloc(sizeof(*ballot)
			+ sizeof(ballot->prefs[0]) * (num_preferences+1));
	ballot->num_preferences = num_preferences+1;
	ballot->count_transferred = 0;
	
	/* They many not be in order */
	for (pref_ptr=(char *)pref[0], i = 0;
	     i < ballot->num_preferences; 
	     pref_ptr=pref[++i] )
	{
		
		if (sscanf(pref_ptr,"%2u%2u%2u",&pref_number,&group_index,&db_cand_index) != 3) {
			if (sscanf(pref_ptr,"%u",&db_cand_index) != 1) {
				/* Can't parse preference */
				fprintf(stderr,"Can't parse preference '%u': '%s'\n",i+1,preference_list);
				return NULL;
			}
			/* format is 1,2,3,4,5*/
			pref_number = i;
			group_index = 0;
		}
		ballot->prefs[pref_number]
			.group_index = group_index;
		ballot->prefs[pref_number]
			.db_candidate_index = db_cand_index-1;
	}
	
	return ballot;
	
}

static int parse_election_file (char *election_filename, struct election *e,struct ballot_list **ballots);
static int parse_election_file (char *election_filename, struct election *e,struct ballot_list **ballots) 
{
	FILE *fh;
	int ret=0;
	int linenumber=0;
	struct ballot *vote;
	char *line_str;
	char cmd_str[256],data_str[256];
	char name_str[256],abbrev_str[256];
	struct cand_list *list = NULL,*list_ptr;
	int cand_counter=0,vote_counter=0,found_votes=0;
	enum action command;

        fh=fopen(election_filename,"r");
	if (NULL == fh) {
		fprintf(stderr,"Can't open %s for reading: %s\n",election_filename,strerror(errno));
		exit(0);
	}

	while ((line_str = fgets_malloc(fh))){
		linenumber++;
/*		fprintf(stderr,"line %u:'%s'\n",linenumber,line_str);*/
		/* skip blank or commented lines */
		if ((sscanf(line_str,"%s",data_str) <=0) || 
		    (strncmp(line_str,"#",1) == 0)) { 
			free(line_str);
			continue;
		}
		if (found_votes) {
			/* vote processing */ 
			vote=load_vote(line_str);
			if ( vote == NULL) {
				parse_error(election_filename,linenumber,VOTES);
				ret=1;
				continue;
			}
			
			*ballots = new_ballot_list(load_vote(line_str),*ballots);
			vote_counter++;
			
			
		} else {
			/* election definition processing */
			sscanf(line_str,"%[^,],%[ 0-9 a-z A-Z ,' _  -]",cmd_str,data_str);
			if (strlen(cmd_str) == 0) {
				parse_error(election_filename,linenumber,INVALID);
				ret=1;
				continue;
			}

			command=get_action_code(cmd_str);
			
			/* error check and process a line*/
			switch(command) {
				
			case TITLE:
				e->title=sprintf_malloc(data_str);
				break;
				
			case ELECTORATE:
				if (e->electorate) {
					fprintf(stderr,"Duplicate ELECTORATE definition line %u. Discarding.\n",linenumber);
					
				} else {
					e->electorate = malloc(sizeof(struct electorate) + strlen(data_str)+1);
					e->electorate->next = NULL;
					strcpy(e->electorate->name,data_str);
				}
				break;
				
			case VACANCIES:
				if (sscanf(data_str,"%u",&e->electorate->num_seats) != 1) {
					parse_error(election_filename,linenumber,command);
					ret=1;
				}
				break;
				
			case GROUP:
				if (sscanf(data_str,"%[ 0-9 a-z A-Z ' _  -],%s",name_str,abbrev_str)!=2) {
					parse_error(election_filename,linenumber,command);
					ret=1;
					break;
				}
				e->groups[e->num_groups].name=sprintf_malloc(name_str);  
				strcpy(	e->groups[e->num_groups].name,name_str);
				e->groups[e->num_groups].abbrev=sprintf_malloc(abbrev_str);  
				strcpy(	e->groups[e->num_groups].abbrev,abbrev_str);
				e->groups[e->num_groups].group_index=e->num_groups++;
				
				break;
				
			case CANDIDATE:
				list = new_cand_list(malloc(sizeof(struct candidate)), list);
				list->cand->name = strdup(data_str);
				list->cand->db_candidate_index=cand_counter;
				list->cand->group = &e->groups[e->num_groups - 1];
				list->cand->count_when_quota_reached = 0;
				/* We are PREpending to list, so count is now backwards */
				list->cand->scrutiny_pos = cand_counter++;
				/* All piles empty, all totals 0 */
				memset(list->cand->c, 0, sizeof(list->cand->c));
				/* surplus distributed flag: init false */
				list->cand->surplus_distributed=false;
				
				break;
				
			case VOTES:
				found_votes=1;

				/* fix scrutiny positions of previous groups candidates */
				/* now we know how many candidates there were */
				for (list_ptr=list; list_ptr; list_ptr=list_ptr->next) {
					list_ptr->cand->scrutiny_pos= (cand_counter - list_ptr->cand->scrutiny_pos -1 );
				}

				break;
				
			case INVALID:
				fprintf(stderr,"Can't interpret %s:%i '%s'\n",election_filename,linenumber,line_str);
				ret=1;
			}
			
			free(line_str);
		}
	}
	fclose(fh);

	/* load up last parameter return values */
	e->candidates = list;
	fprintf(stderr, "Read in %u votes\n",vote_counter);
	if (ret) fprintf(stderr, "Errors found\n");

	return ret;
}

void free_electorates(struct electorate *elec);
void free_electorates(struct electorate *elec)
{

		free(elec);
}

static bool free_piles(struct candidate *cand, void *unused)
{
	unsigned int i;

	for (i = 0; i < MAX_COUNTS; i++)
		if (cand->c[i].pile)
			free_ballot_list(cand->c[i].pile);

	return false;
}

static bool free_candidate(struct candidate *cand, void *unused)
{
	free(cand->name);
	free(cand);
	return false;
}

static void free_group_names(struct group *groups, unsigned int num_groups)
{
	unsigned int i;

	for (i = 0; i < num_groups; i++)
		free(groups[i].name);
}

#define TITLE "ACT Legislative Assembly Election - 16 October 2004"

int main(int argc, char *argv[])
{
	struct ballot_list *ballots=NULL;
	int err;
	char *election_filename;
	struct election e = {NULL};
	
	argc=2;
	argv[1]=malloc(sizeof("./elec.csv1"));
	argv[1]= (char *) "./elec.csv\0";

	/* Open definition file (argv[1])  */
	if (argc < 2) {
		fprintf(stderr,"USAGE: %s <election_definition_file>\n",argv[0]);
		exit(0);
	}
	
	election_filename=argv[1];

	/* Get the information we need */
	err=parse_election_file(election_filename, &e, &ballots);

	if (err) {
		bailout("election file processing of %s failed(see above).\n",election_filename);
	}
	/* Start the reporting for a regular Hare Clark count*/
	report_start(&e, NULL);

	do_count(&e, ballots, NULL);

	/* We've finished! */
	fprintf(stderr,"\nFinished Count; Cleaning up\n");
	report_end(get_count_number(), e.title);

	/* free allocated memory */
	for_each_candidate(e.candidates, &free_candidate, NULL);
	for_each_candidate(e.candidates, &free_piles, NULL);
	free_group_names(e.groups, e.num_groups);
	free_cand_list(e.candidates);
	free_electorates(e.electorate);

	return 0;
}








