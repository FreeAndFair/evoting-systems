/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#define main xmain
int xmain(int argc, char *argv[]);
#include "vacancy.c"
#undef main
#include <stdarg.h>

struct a_elec {
	struct electorate elec;
	char name[80];
};

static struct a_elec electorate = { { NULL, 0, 7 }, "Molonglo" };

static struct group mygroups[]
= {{ (char *)"Indep Prog", 0 },
   { (char *)"Corp Slaves", 1 },
   { (char *)"Democrats", 2 }};

static struct candidate cands[] 
= { { 0, (char *)"Candidate A1", &mygroups[0] },
    { 1, (char *)"Candidate A2", &mygroups[0] },
    { 2, (char *)"Candidate A3", &mygroups[0] },
    { 3, (char *)"Candidate A4", &mygroups[0] },
    { 4, (char *)"Candidate A5", &mygroups[0] },
    { 5, (char *)"Candidate A6", &mygroups[0] },
    { 6, (char *)"Candidate A7", &mygroups[0] },
    { 0, (char *)"Candidate B1", &mygroups[1] },
    { 1, (char *)"Candidate B2", &mygroups[1] },
    { 2, (char *)"Candidate B3", &mygroups[1] },
    { 3, (char *)"Candidate B4", &mygroups[1] },
    { 4, (char *)"Candidate B5", &mygroups[1] },
    { 5, (char *)"Candidate B6", &mygroups[1] },
    { 6, (char *)"Candidate B7", &mygroups[1] },
    { 0, (char *)"Nofriends Nige", &mygroups[2] } };

#define NUM_CANDIDATES (sizeof(cands)/sizeof(cands[0]))

/* Case-insensitive search for electorate: NULL if not found. */
struct electorate *fetch_electorate(PGconn *conn, const char *ename)
{
	if (strcmp(ename, "Molonglo") == 0)
		return &electorate.elec;
	return NULL;
}

/* Given the non-NULL electorate, fill in all the groups, return number. */
unsigned int fetch_groups(PGconn *conn, 
			  const struct electorate *elec,
			  struct group *groups)
{
	unsigned int i;

	for (i = 0; i < sizeof(mygroups)/sizeof(mygroups[0]); i++) {
		groups[i] = mygroups[i];
		groups[i].name = strdup(mygroups[i].name);
	}

	return i;
}

/* Given the group information, return the candidate list */
struct cand_list *fetch_candidates(PGconn *conn, 
				   const struct electorate *elec,
				   struct group *groups)
{
	int i;
	struct cand_list *list = NULL;

	/* We prepend to list, so do this backwards */
	for (i = NUM_CANDIDATES-1; i >= 0; i--) {
		struct candidate *cand = malloc(sizeof(*cand));
		*cand = cands[i];
		cand->name = strdup(cands[i].name);
		/* Prepend to list */
		list = new_cand_list(cand, list);
		list->cand->scrutiny_pos = i;
	}
	return list;
}

static struct ballot_list *gen_prefs(struct ballot_list *list,
				     unsigned int num_ballots,
				     unsigned int num_prefs, ...)
{
	unsigned int i;
	size_t ballot_size;
	struct ballot *ballot;
	va_list ap;

	fprintf(stderr, "Generating %u votes: ", num_ballots);
	ballot_size = sizeof(*ballot) + sizeof(ballot->prefs[0])*num_prefs;
	/* Create one ballot */
	va_start(ap, num_prefs);
	ballot = malloc(ballot_size);
	ballot->num_preferences = num_prefs;
	for (i = 0; i < num_prefs; i++) {
		struct candidate *cand;

		cand = &cands[va_arg(ap, unsigned int)];
		fprintf(stderr, "%s ", cand->name);
		
		ballot->prefs[i].db_candidate_index = cand->db_candidate_index;
		ballot->prefs[i].group_index = cand->group->group_index;
	}
	va_end(ap);
	fprintf(stderr, "\n");

	/* Create all the ballots */
	for (i = 0; i < num_ballots; i++) {
		struct ballot_list *tmp;

		tmp = malloc(sizeof(*tmp));
		tmp->next = list;
		tmp->ballot = malloc(ballot_size);
		memcpy(tmp->ballot, ballot, ballot_size);
		list = tmp;
	}
	free(ballot);
	return list;
}

/* Get all the ballots for this electorate */
struct ballot_list *fetch_ballots(PGconn *conn, const struct electorate *elec)
{
	unsigned int i;
	struct ballot_list *list = NULL;

	/* Two informal */
	list = gen_prefs(list, 2, 0);
	/* 1 for first candidate ONLY */
	list = gen_prefs(list, 1, 1, 0);
	/* A few for each candidate, cascading */
	for (i = 0; i < NUM_CANDIDATES; i++) {
		assert(NUM_CANDIDATES < 16);
		list = gen_prefs(list, i, NUM_CANDIDATES-i-1,
				 i, i+1, i+2, i+3, i+4, i+5, i+6, i+7, i+8,i+9,
				 i+10, i+11, i+12, i+13, i+14, i+15,i+16);
	}
	return list;
}

PGconn *connect_db(const char *name)
{
	return NULL;
}

void free_electorates(struct electorate *e)
{
	if (e != &electorate.elec) exit(1);
}

/* Debugger use function */
static bool dump_candidate(struct candidate *cand, void *unused)
{
	printf("  %s (%s): ", cand->name, cand->group->name);
	switch (cand->status) {
	case CAND_CONTINUING: printf("CONTINUING\n"); break;
	case CAND_EXCLUDED: printf("EXCLUDED\n"); break;
	case CAND_ELECTED: printf("ELECTED\n"); break;
	case CAND_PENDING: printf("PENDING\n"); break;
	case CAND_BEING_EXCLUDED: printf("BEING_EXCLUDED\n"); break;
	default: printf("UNKNOWN\n"); break;
	}
	return false;
}	

static void print_candidates(struct cand_list *list) __attribute__((unused));
static void print_candidates(struct cand_list *list)
{
	for_each_candidate(list, &dump_candidate, NULL);
}

int main(int argc, char *argv[])
{
	/* It's just a compile test unless we're interactive */
	if (argc == 1) exit(0);
	return xmain(argc, argv);
}
