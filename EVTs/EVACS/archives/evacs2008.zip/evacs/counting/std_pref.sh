#!/bin/bash
#
#
SCRIPTROOT=`pwd`
OUTPUTDIR=/tmp

run_std_pref()
{
    # remove any previous output files before proceeding
    rm -f $OUTPUTDIR/election*
    RETURN_CODE=`$SCRIPTROOT/std_pref_csv $1 > /dev/tty && echo 0`
    if [ "$RETURN_CODE" != 0 ]; then
	echo "FATAL: Count failed (return code: $RETURN_CODE). Aborting ...."
    fi
}

run_std_pref $1

echo
echo  Formatting and printing scrutiny sheets:
$SCRIPTROOT/print_std_pref_scrutiny
