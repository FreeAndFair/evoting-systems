/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "report.c"

struct a_elec {
	struct electorate elec;
	char name[80];
};

static struct a_elec electorate = { { NULL, 0, 7 }, "Molonglo" };

static struct election election 
= { &electorate.elec, NULL, 2,
    {{ (char *)"Indep Prog", 0 }, { (char *)"Democrats", 1 }} };

static struct candidate cands[8] 
= { { 0, (char *)"Candidate 1", &election.groups[0], 0, -1, 0 },
    { 1, (char *)"Candidate 2", &election.groups[0], 1, -1, 0 },
    { 2, (char *)"Candidate 3", &election.groups[0], 2, -1, 0 },
    { 3, (char *)"Candidate 4", &election.groups[0], 3, -1, 0 },
    { 4, (char *)"Candidate 5", &election.groups[0], 4, -1, 0 },
    { 5, (char *)"Candidate 6", &election.groups[0], 5, -1, 0 },
    { 6, (char *)"Candidate 7", &election.groups[0], 6, -1, 0 },
    { 0, (char *)"Nofriends Nige", &election.groups[1], 7, -1, 0 } };

static struct cand_list list[sizeof(cands)/sizeof(cands[0])];

int main()
{
	unsigned int i;

	for (i = 0; i < sizeof(list)/sizeof(list[0]); i++) {
		list[i].next = &list[i+1];
		list[i].cand = &cands[i];
	}
	list[i-1].next = NULL;
	election.candidates = list;

	report_start(&election);
	report_transfer(1, ((struct fraction){ 1, 1}), 1);
	report_exhausted(1, 0, 0);
	for (i = 0; i < sizeof(list)/sizeof(list[0]); i++) {
		report_ballots_transferred(1, i, 100 + i, CAND_CONTINUING);
		report_votes_transferred(1, i, CAND_CONTINUING, i, 100 + i);
	}
	report_lost_or_gained(1, 0);
	report_end(2, "Test");
	exit(0);
}
