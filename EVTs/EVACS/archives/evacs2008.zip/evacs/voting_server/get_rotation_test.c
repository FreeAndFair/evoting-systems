/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

/* This CGI is invoked by the client to get the next robson rotation
   for the current electorate. */
#define fetch_next_rotation _fetch_next_rotation
extern int xmain(int argc, char *argv[]);
#define main xmain
#include "get_rotation.c"
#undef main
#include <common/createtables.h>
#include <setjmp.h>
#include <assert.h>

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

static bool interactive;
static struct http_vars http_vars[] = { { (char *)"ecode", (char *)"0" },
					 { NULL, NULL } };

/* stub */
void cgi_good_response(const struct http_vars *vars)
{
	if (interactive) {
		printf("error=0&%s", http_urlencode(vars));
		exit(0);
	}
	if (strcmp(vars[0].name, "rotation0") != 0) exit(1);
	if (strcmp(vars[1].name, "rotation1") != 0) exit(1);
	if (strcmp(vars[2].name, "rotation2") != 0) exit(1);
	if (strcmp(vars[3].name, "rotation3") != 0) exit(1);
	if (strcmp(vars[4].name, "rotation4") != 0) exit(1);
	if (strcmp(vars[5].name, "rotation5") != 0) exit(1);
	if (strcmp(vars[6].name, "rotation6") != 0) exit(1);
	if (vars[7].name != NULL) exit(1);

	/* Should get "normal" rotation */
	if (atoi(vars[0].value) != 0) exit(1);
	if (atoi(vars[1].value) != 1) exit(1);
	if (atoi(vars[2].value) != 2) exit(1);
	if (atoi(vars[3].value) != 3) exit(1);
	if (atoi(vars[4].value) != 4) exit(1);
	if (atoi(vars[5].value) != 5) exit(1);
	if (atoi(vars[6].value) != 6) exit(1);
	if (vars[7].value != NULL) exit(1);
	exit(0);
}

void cgi_error_response(enum error err)
{
	abort();
}

struct http_vars *cgi_get_arguments(void)
{
	return http_vars;
}

void http_free(struct http_vars *vars)
{
	if (vars != http_vars) exit(1);
}

/* Retrieve a string value from an http_vars associative array.
   Returns NULL on failure.  */
const char *http_string(const struct http_vars *hvars, const char *name)
{
	unsigned int i;

	for (i=0; hvars && hvars[i].name; i++)
		if (strcmp(name, hvars[i].name) == 0) return hvars[i].value;

	/* Not found. */
	return NULL;
}

/*
 * List of characters which must be escaped in a x-www-form-urlencoded string
 */
#define UNSAFE_CHARACTERS "+&=%/"

/* Encodes an http_vars associative array into a x-www-form-urlencoded
   string.  Caller must free string. */
char *http_urlencode(const struct http_vars *hvars)
{
	const char hex[16] = "0123456789ABCDEF";
	unsigned int length = 0;
	char *buf, *s;
	unsigned int i;

	/* Count number of escapes required */
	for (i=0; hvars[i].name; i++) {
		char *tmp;
		int nunsafe = 0;

		tmp = strpbrk(hvars[i].name, UNSAFE_CHARACTERS);
		while (tmp) {
			nunsafe++;
			tmp = strpbrk(tmp + 1, UNSAFE_CHARACTERS);
		}

		tmp = strpbrk(hvars[i].value, UNSAFE_CHARACTERS);
		while (tmp) {
			nunsafe++;
			tmp = strpbrk(tmp + 1, UNSAFE_CHARACTERS);
		}

		length += strlen(hvars[i].name) +
			strlen(hvars[i].value) +
			nunsafe*2 + 1 + (i?1:0);
	}

	/* Allocate buffer */
	buf = malloc(length + 1);
	if (!buf) return NULL;
	s = buf;

	/* Write out variables, and do escapes */
	for (i=0; hvars && hvars[i].name; i++) {
		char *p;

		/* & separates variable names (after first one) */
		if (i != 0)
			*s++ = '&';

		for (p = hvars[i].name; *p; p++) {
			if (strchr(UNSAFE_CHARACTERS, *p)) {
				*s++ = '%';
				*s++ = hex[*p >> 4];
				*s++ = hex[*p & 0xf];
			} else if (*p == ' ')
				*s++ = '+';
			else
				*s++ = *p;
		}
		
		*s++ = '=';

		for (p = hvars[i].value; *p; p++) {
			if (strchr(UNSAFE_CHARACTERS, *p)) {
				*s++ = '%';
				*s++ = hex[*p >> 4];
				*s++ = hex[*p & 0xf];
			} else if (*p == ' ')
				*s++ = '+';
			else
				*s++ = *p;
		}
	}

	*s = '\0';

	assert (s == buf + length);

	return buf;
}

extern void set_cgi_bailout(void)
{
	/* Abort is fine for testing */
}

int main(int argc, char *argv[])
{
	PGconn *conn;

	conn = clean_database("evacs");

	/* Create election table, insert for each */
	drop_table(conn,"electorate");
	SQL_command(conn,"CREATE TABLE electorate ("
		    "code INTEGER PRIMARY KEY,"
		    "name TEXT NOT NULL UNIQUE,"
		    "seat_count INTEGER NOT NULL);");
	SQL_command(conn, "INSERT INTO electorate"
		    " VALUES ( 0, 'Molonglo', 7 );");
	SQL_command(conn, "INSERT INTO electorate"
		    " VALUES ( 1, 'Ginnindera', 5 );");

	/* Create tables, and insert two rotations each */
	create_robson_rotation_table(conn, 5);
	SQL_command(conn, "INSERT INTO robson_rotation_5"
		    " VALUES ( 0, '{0,1,2,3,4}' );");
	SQL_command(conn, "INSERT INTO robson_rotation_5"
		    " VALUES ( 1, '{4,3,2,1,0}' );");
	SQL_command(conn,
		    "CREATE SEQUENCE robson_5_seq START 0 "
		    "MINVALUE 0 MAXVALUE %d CYCLE;", 1);
		 
	create_robson_rotation_table(conn,7);
	SQL_command(conn, "INSERT INTO robson_rotation_7"
		    " VALUES ( 0, '{0,1,2,3,4,5,6}' );");
	SQL_command(conn, "INSERT INTO robson_rotation_7"
		    " VALUES ( 1, '{6,5,4,3,2,1,0}' );");
	SQL_command(conn,
		    "CREATE SEQUENCE robson_7_seq START 0 "
		       "MINVALUE 0 MAXVALUE %d CYCLE;", 1);

	if (argc == 1) {
		struct rotation rot;

		interactive = 0;
		/* TEST DDS3.2.5: Update Rotation Indices */
		rot = fetch_next_rotation(conn, 0);
		if (rot.size != 7) exit(1);
		if (rot.rotations[0] != 0) exit(1);
		if (rot.rotations[1] != 1) exit(1);
		if (rot.rotations[2] != 2) exit(1);
		if (rot.rotations[3] != 3) exit(1);
		if (rot.rotations[4] != 4) exit(1);
		if (rot.rotations[5] != 5) exit(1);
		if (rot.rotations[6] != 6) exit(1);

		rot = fetch_next_rotation(conn, 0);
		if (rot.size != 7) exit(1);
		if (rot.rotations[0] != 6) exit(1);
		if (rot.rotations[1] != 5) exit(1);
		if (rot.rotations[2] != 4) exit(1);
		if (rot.rotations[3] != 3) exit(1);
		if (rot.rotations[4] != 2) exit(1);
		if (rot.rotations[5] != 1) exit(1);
		if (rot.rotations[6] != 0) exit(1);

		rot = fetch_next_rotation(conn, 1);
		if (rot.size != 5) exit(1);
		if (rot.rotations[0] != 0) exit(1);
		if (rot.rotations[1] != 1) exit(1);
		if (rot.rotations[2] != 2) exit(1);
		if (rot.rotations[3] != 3) exit(1);
		if (rot.rotations[4] != 4) exit(1);

		rot = fetch_next_rotation(conn, 1);
		if (rot.size != 5) exit(1);
		if (rot.rotations[0] != 4) exit(1);
		if (rot.rotations[1] != 3) exit(1);
		if (rot.rotations[2] != 2) exit(1);
		if (rot.rotations[3] != 1) exit(1);
		if (rot.rotations[4] != 0) exit(1);
	} else {
		/* Do the whole thing */
		interactive = 1;
		xmain(argc, argv);
	}

	PQfinish(conn);
	return 0;
}

