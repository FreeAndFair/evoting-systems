/* This file is (C) copyright 2001 Software Improvements, Pty Ltd.
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#include "cgi.c"
#include <fcntl.h>

int main(int argc, char *argv[])
{
	struct http_vars *vars;

	/* Reopen STDIN_FILENO */
	close(STDIN_FILENO);
	open("voting_server/test_data/post_input", O_RDONLY);
	setenv("CONTENT_LENGTH", "19", 0);
	
	vars = cgi_get_arguments();
	if (strcmp(vars[0].name, "var1") != 0) exit(1);
	if (strcmp(vars[0].value, "val1") != 0) exit(1);
	if (strcmp(vars[1].name, "var2") != 0) exit(1);
	if (strcmp(vars[1].value, "val2") != 0) exit(1);
	if (vars[2].name || vars[2].value) exit(1);
	http_free(vars);

	if (argc == 2) {
		/* Actually do the CGI response */
		struct http_vars vars[]
			= { { (char *)"varret1", (char *)"valret1" },
			    { (char *)"varret2", (char *)"valret2" },
			    { NULL, NULL } };
		if (strcmp(argv[1], "OK") == 0)
			cgi_good_response(vars);
		else
			cgi_error_response(atoi(argv[1]));
	}
	exit(0);
}
