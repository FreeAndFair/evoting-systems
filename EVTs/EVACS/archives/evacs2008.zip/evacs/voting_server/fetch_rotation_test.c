/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

#include "fetch_rotation.c"
#include <common/createtables.h>

int main()
{
	PGconn *conn;
	struct rotation *rot;

	conn = clean_database("test");

	/* Create election table, insert for each */
	drop_table(conn,"electorate");
	SQL_command(conn,"CREATE TABLE electorate ("
		    "code INTEGER PRIMARY KEY,"
		    "name TEXT NOT NULL UNIQUE,"
		    "seat_count INTEGER NOT NULL);");
	SQL_command(conn, "INSERT INTO electorate"
		    " VALUES ( 0, 'Molonglo', 7 );");
	SQL_command(conn, "INSERT INTO electorate"
		    " VALUES ( 1, 'Ginnindera', 5 );");

	/* Create tables, and insert two rotations each */
	create_robson_rotation_table(conn, 5);
	SQL_command(conn, "INSERT INTO robson_rotation_5"
		    " VALUES ( 0, '{0,1,2,3,4}' );");
	SQL_command(conn, "INSERT INTO robson_rotation_5"
		    " VALUES ( 1, '{4,3,2,1,0}' );");
	SQL_command(conn,
		    "CREATE SEQUENCE robson_5_seq START 0 "
		    "MINVALUE 0 MAXVALUE %d CYCLE;", 1);
		 
	create_robson_rotation_table(conn,7);
	SQL_command(conn, "INSERT INTO robson_rotation_7"
		    " VALUES ( 0, '{0,1,2,3,4,5,6}' );");
	SQL_command(conn, "INSERT INTO robson_rotation_7"
		    " VALUES ( 1, '{6,5,4,3,2,1,0}' );");
	SQL_command(conn,
		    "CREATE SEQUENCE robson_7_seq START 0 "
		       "MINVALUE 0 MAXVALUE %d CYCLE;", 1);

	rot = fetch_rotation(conn, 0, 5);
	
	if (rot == NULL) {
		bailout("Could not get rotation number 0 for 5 seat electorate");
	}
	if (rot->size != 5) exit(1);
	if (rot->rotations[0] != 0) exit(1);
	if (rot->rotations[1] != 1) exit(1);
	if (rot->rotations[2] != 2) exit(1);
	if (rot->rotations[3] != 3) exit(1);
	if (rot->rotations[4] != 4) exit(1);

	rot = fetch_rotation(conn, 1, 5);
	if (rot == NULL) {
		bailout("Could not get rotation number 1 for 5 seat electorate");
	}
	if (rot->size != 5) exit(1);
	if (rot->rotations[0] != 4) exit(1);
	if (rot->rotations[1] != 3) exit(1);
	if (rot->rotations[2] != 2) exit(1);
	if (rot->rotations[3] != 1) exit(1);
	if (rot->rotations[4] != 0) exit(1);

	rot = fetch_rotation(conn, 0, 7);
	if (rot == NULL) {
		bailout("Could not get rotation number 0 for 7 seat electorate");
	}

	if (rot->size != 7) exit(1);
	if (rot->rotations[0] != 0) exit(1);
	if (rot->rotations[1] != 1) exit(1);
	if (rot->rotations[2] != 2) exit(1);
	if (rot->rotations[3] != 3) exit(1);
	if (rot->rotations[4] != 4) exit(1);
	if (rot->rotations[5] != 5) exit(1);
	if (rot->rotations[6] != 6) exit(1);

	rot = fetch_rotation(conn, 1, 7);
	if (rot == NULL) {
		bailout("Could not get rotation number 1 for 7 seat electorate");
	}
	if (rot->size != 7) exit(1);
	if (rot->rotations[0] != 6) exit(1);
	if (rot->rotations[1] != 5) exit(1);
	if (rot->rotations[2] != 4) exit(1);
	if (rot->rotations[3] != 3) exit(1);
	if (rot->rotations[4] != 2) exit(1);
	if (rot->rotations[5] != 1) exit(1);
	if (rot->rotations[6] != 0) exit(1);

	free(rot);
	PQfinish(conn);
	return 0;
}

