#! /bin/sh

# Remember: this is run from the top directory!
OUTPUT="`voting_server/cgi_test OK`"
[ $? = 0 ] || exit 1
echo "$OUTPUT" | fgrep -q "error=0" || exit 1
echo "$OUTPUT" | fgrep -q "varret1=valret1" || exit 1
echo "$OUTPUT" | fgrep -q "varret2=valret2" || exit 1

OUTPUT="`voting_server/cgi_test 7`"
[ $? = 0 ] || exit 1
echo "$OUTPUT" | fgrep -q "error=7" || exit 1

exit 0
