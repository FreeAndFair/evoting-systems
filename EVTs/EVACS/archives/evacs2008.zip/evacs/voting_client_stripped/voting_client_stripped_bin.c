/* This file is (C) copyright 2001-2004 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <malloc.h>
#include <libpq-fe.h>
#include <common/rotation.h>
#include <common/database.h>
#include <common/ballot_contents.h>
#include "voting_client.h"
#include "message.h"
#include "initiate_session.h"
#include "accumulate_preferences.h"

struct ballot_contents *get_electorate_info(unsigned int ecode);
extern void show_ballot(const struct electorate *electorate, const struct ballot_contents *bc);



/* DDS3.1: Do Voting */
int main(int argc, char *argv[])
{
   struct electorate e ;
   struct ballot_contents *bc ;

	if (argc < 6 || argc > 7)
	{
	  fprintf(stderr, "\nStripped-down voting client used to preview ballot papers\n");
	  fprintf(stderr, "Usage: %s <electorate_name> <electorate_code> <number_of_seats> <screen width> <screen height>\n", argv[0]);
	  fprintf(stderr, "The electorate_code & number_of_seats should be as specified in the electorates.txt file\n");
	  fprintf(stderr, "e.g. %s Brindabella 1 5 1152 864\n", argv[0]);
	  return(-1);
	}
	sprintf(e.name, argv[1]);
	e.code=atoi(argv[2]);
	e.num_seats=atoi(argv[3]);
	bc=get_electorate_info(e.code);
	store_electorate(&e);

	/* If we have > 6 arguments, monitor is upside down */
	initialise_display(atoi(argv[4]), atoi(argv[5]), (argc == 7 ));
	init_session();
	show_ballot(&e, bc);
	sleep(60);
	return(0);
}


struct ballot_contents *get_electorate_info(unsigned int ecode)
{
	PGconn *conn;
        PGresult *result;
	unsigned int num_groups,group;
        struct ballot_contents *bc;

	conn = connect_db("evacs");
	if (!conn) 
	{
		fprintf(stderr, "Could not open database connection\n");
		exit(-1);
	}
	
	result = SQL_query(conn,
			   "SELECT party_index,count(index) FROM candidate "
			   "WHERE electorate_code = %u "
			   "GROUP BY party_index;",ecode);

	if ( (num_groups = PQntuples(result)) == 0 )
	{
	  	fprintf(stderr,"No groups found for this electorate.\n");
		exit(-1);
	}

	bc = (struct ballot_contents *)malloc(sizeof(*bc) + num_groups*sizeof(unsigned int));
        if (!bc)  
	{
		fprintf(stderr, "Malloc Failed, System Low on Memory\n");
		exit(-1);
	}

	bc->num_groups=num_groups;
//fprintf(stderr, "setting num_groups to %d\n", bc->num_groups);
	
	for (group=0;group<num_groups;group++) {
	  bc->num_candidates[group] = atoi(PQgetvalue(result,group,1));
//fprintf(stderr, "setting cand[%u] to %d\n", group, bc->num_candidates[group]);
	}
	PQclear(result);
	PQfinish(conn);

	return(bc);
}


