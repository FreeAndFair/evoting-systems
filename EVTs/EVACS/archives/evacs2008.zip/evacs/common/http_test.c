/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "http.c"
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>

#define TEST_GET "images/foo.png"
#define TEST_RESPONSE "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
#define TEST_POST "cgi-bin/test"

static void child()
{
	int fd_in, fd_new;
	int done, to_do;
	struct sockaddr_in addr;
	int one=1;
	char buffer[1000];
	socklen_t socklen = sizeof(addr);

	fd_in = socket(PF_INET, SOCK_STREAM, 0);
	if (fd_in < 0) exit(1);

	/* Ensure test can run again immediately if we die. */
	setsockopt(fd_in, SOL_SOCKET, SO_REUSEADDR,
		   (char *)&one,sizeof(one));

	/* Set up to listen on localhost:8088 */
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(8088);
	addr.sin_addr.s_addr = INADDR_ANY;
	if (bind(fd_in, (struct sockaddr *)&addr, sizeof(addr)) != 0)
		exit(1);

	if (listen(fd_in, 1) != 0) exit(1);

	/* Die in 5 seconds */
	alarm(5);
	fd_new = accept(fd_in, (struct sockaddr *)&addr, &socklen);
	if (fd_new < 0) {
		exit(1);
	}

	alarm(5);

	done = 0;
#undef EXPECTED_STRING
#define EXPECTED_STRING				\
	"GET "TEST_GET" HTTP/1.0\r\n"		\
	"User-Agent: EVACS booth\r\n\r\n"

	to_do = strlen(EXPECTED_STRING);
	/* Can't use sock_load here. */
	while (to_do > 0) {
		int r;

		r = read(fd_new, buffer+done, to_do);
		if (r <= 0) exit(1);
		done += r;
		to_do -= r;
	}
	if (memcmp(buffer, EXPECTED_STRING, done) != 0)
		exit(1);

	/* "serve" */
	sock_printf(fd_new, "HTTP/1.1 200 OK\r\n"
		    "Content-Type: text/plain\r\n\r\n");
	sock_printf(fd_new, "%s", TEST_RESPONSE);
	close(fd_new);

	alarm(5);
	fd_new = accept(fd_in, (struct sockaddr *)&addr, &socklen);
	if (fd_new < 0) exit(1);

	alarm(5);
	/* Can't use sock_load here: they won't close until we
                   respond */
#undef EXPECTED_STRING
#define EXPECTED_STRING						\
	"POST "TEST_POST" HTTP/1.0\r\n"				\
	"User-Agent: EVACS booth\r\n"				\
	"Content-type: application/x-www-form-urlencoded\r\n"	\
	"Content-length: 39\r\n"				\
	"\r\n"							\
	"test=testvalue&test2=testvalue2&error=0"
	done = 0;
	to_do = strlen(EXPECTED_STRING);

	while (to_do > 0) {
		int r;

		r = read(fd_new, buffer+done, to_do);
		if (r <= 0) exit(1);
		done += r;
		to_do -= r;
	}
	if (memcmp(buffer, EXPECTED_STRING, done) != 0)
		exit(1);

	sock_printf(fd_new, "HTTP/1.1 200 OK\r\n"
		    "Content-Type: application/x-www-form-urlencoded\r\n\r\n");
	sock_printf(fd_new, "%s", "error=0&test=value+with+spaces&test2=%2B%26%3D%25%2f");
	close(fd_new);
	exit(0);
}

int main(int argc, char *argv[])
{
	char *val;
	size_t size;
	int status;
	struct http_vars *resp;
	const struct http_vars request[]
		= { { (char *)"test", (char *)"testvalue" },
		    { (char *)"test2", (char *)"testvalue2" },
		    { (char *)"error", (char *)"0" },
		    { NULL, NULL } };

	/* Interactive */
	if (argc == 5) {
		printf("%s\n",
		       http_post(argv[1], atoi(argv[2]), argv[3], argv[4],
				 &size));
		exit(0);
	}

	if (strcmp(http_string(request, "test"), "testvalue") != 0) exit(1);
	if (strcmp(http_string(request, "test2"), "testvalue2") != 0) exit(1);
	if (http_error(request) != 0) exit(1);

	/* Now fork and "serve" from the child. */
	if (!fork()) child();

	/* Wait for child to set up before connecting */
	sleep(1);
	val = http_get("127.0.0.1", 8088, TEST_GET, &size);
	if (!val) exit(1);
	if (size != strlen(TEST_RESPONSE)) exit(1);
	if (memcmp(val, TEST_RESPONSE, size) != 0) exit(1);
	free(val);

	resp = http_exchange("127.0.0.1", 8088, TEST_POST, request);
	if (!resp) exit(1);
	if (http_error(resp) != ERR_OK) exit(1);
	if (strcmp(http_string(resp, "test"), "value with spaces") != 0)
		exit(1);
	if (strcmp(http_string(resp, "test2"), "+&=%/") != 0)
		exit(1);
	http_free(resp);

	wait(&status);
	if (!WIFEXITED(status) || WEXITSTATUS(status) != 0)
		exit(1);

	exit(0);
}
