#! /bin/sh

# Remember: this is run from the top directory!
./common/evacs_test || echo './common/evacs_test failed'; exit 1


exit 0
