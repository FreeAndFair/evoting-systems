/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "cursor.c"
#include <stdbool.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

static struct rotation rot5 = { 5, { 5, 4, 3, 1, 2 } };
static struct rotation rot7 = { 7, { 7, 6, 5, 4, 1, 2, 3 } };

/* If the two maps are equivalent (the first is a collapsed version of
   the second) return true */
static bool is_equiv(const unsigned int map[], unsigned int size,
		     const unsigned int full_map[7])
{
	unsigned int i, tmp_map[7];

	/* Copy across, and mark out those positions which are not in
           the collapsed map */
	for (i = 0; i < 7; i++) {
		if (map[i] > size) tmp_map[i] = UINT_MAX;
		else tmp_map[i] = map[i];
	}

	/* Now, bubble the valid numbers to the top of the map */
	for (i = 7; i != 0; i--) {
		/* Invalid entry before us? */
		if (tmp_map[i-1] == UINT_MAX) {
			/* Move everyone up one */
			memmove(&tmp_map[i-1], &tmp_map[i],
				(7-i)*sizeof(unsigned int));
		}
	}

	/* Now compare the two */
	for (i = 0; i < size; i++)
		if (map[i] != tmp_map[i]) return false;

	return true;
}

int main()
{
	unsigned int i, size;
	unsigned int full_map[7];

	/* Populate position map for full column */
	for (i = 0; i < rot7.size; i++) {
		/* Where do I go on the screen? */
		full_map[i] = translate_dbci_to_sci(rot7.size, i, &rot7);
	}

	/* If there are fewer candidates than positions, you should
	   end up in the same place as you were before, relative to
	   the others. */
	for (size = 1; size <= rot7.size; size++) {
		unsigned int map[size+1];

		/* Create map for this rotation subset */
		for (i = 0; i < size; i++) {
			map[i] = translate_dbci_to_sci(size, i, &rot7);
			/* TEST DDS3.2.12: Translate SCI to DBCI */
			if (translate_sci_to_dbci(size, map[i], &rot7) != i)
				exit(1);
		}

		if (!is_equiv(map, size, full_map)) exit(1);
	}

	/* Populate position map for full column */
	for (i = 0; i < rot5.size; i++) {
		/* Where do I go on the screen? */
		full_map[i] = translate_dbci_to_sci(rot5.size, i, &rot5);
	}

	/* If there are fewer candidates than positions, you should
	   end up in the same place as you were before, relative to
	   the others. */
	for (size = 1; size <= rot5.size; size++) {
		unsigned int map[size+1];

		/* Create map for this rotation subset */
		for (i = 0; i < size; i++) {
			map[i] = translate_dbci_to_sci(size, i, &rot5);
			/* TEST DDS3.2.12: Translate SCI to DBCI */
			if (translate_sci_to_dbci(size, map[i], &rot5) != i)
				exit(1);
		}

		if (!is_equiv(map, size, full_map)) exit(1);
	}

	exit(0);
}
