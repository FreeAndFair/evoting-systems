/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "barcode_hash.c"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "barcode.h"

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif
int main(int argc, char *argv[])
{
	/* TEST DDS3.2.1: Generate Hash */
	char hash1[HASH_BITS + 1];
	char hash2[HASH_BITS + 1];
	unsigned int i, j;
	unsigned char num[BYTES(BARCODE_DATA_BITS)] = { 0 };
	unsigned char num2[BYTES(BARCODE_DATA_BITS)];

	if (argc == 2) {
		struct barcode bc;

		if (strlen(argv[1]) != BARCODE_ASCII_BYTES) exit(1);
		strcpy(bc.ascii, argv[1]);
		if (!bar_decode_ascii(&bc)) exit(1);
		if (gen_csum(&bc) != bc.checksum) exit(1);
		gen_hash(hash1, bc.data, sizeof(bc.data));
		printf("%s\n", hash1);
		exit(0);
	}

	hash1[HASH_BITS] = 'X';
	gen_hash(hash1, num, sizeof(num));
	
	/* Must be terminated. */
	if (hash1[HASH_BITS] != '\0') exit(1);

	/* Length HASH BITS */
	if (strlen(hash1) != HASH_BITS) exit(1);
	/* Not all ones or all zeroes. */
	if (strchr(hash1, '0') == NULL || strchr(hash1, '1') == NULL)
		exit(1);
	/* Only contains ones and zeroes */
	if (strspn(hash1, "01") != HASH_BITS) exit(1);

	/* Same data hashes to same value. */
	for (i = 0; i < BYTES(BARCODE_DATA_BITS); i++) {
		/* Not exhaustive, would take forever. */
		for (j = 0; j < 256; j += 41) {
			num[i] = j;
			memcpy(num2, num, sizeof(num2));
			gen_hash(hash1, num, sizeof(num));
			gen_hash(hash2, num2, sizeof(num2));
			if (strcmp(hash1, hash2) != 0)
				exit(1);
		}
	}
	exit(0);
}

