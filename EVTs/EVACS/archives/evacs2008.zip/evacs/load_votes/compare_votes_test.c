/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "compare_votes.c"

int main(void)
{
	/* TEST DDS3.4: Compare Votes */
	struct vote v1, v2, v3, v4, v5, v6, v7, v8;


	/* NOTE: Compare_votes now assumes preferences are pre-sorted
	   by get_prefs_for_vote. So this test must also setup sorted
	   preferences, sorted by group and candidate index.
	*/

	v1.polling_place_code = 2;
	v1.electorate_code = 1;
	v1.preferences.num_preferences = 3;
	v1.preferences.candidates[1].group_index = 3;
	v1.preferences.candidates[1].db_candidate_index = 4;
	v1.preferences.candidates[1].prefnum = 1;
	v1.preferences.candidates[2].group_index = 5;
	v1.preferences.candidates[2].db_candidate_index = 7;
	v1.preferences.candidates[2].prefnum = 4;
	v1.preferences.candidates[0].group_index = 1;
	v1.preferences.candidates[0].db_candidate_index = 3;
	v1.preferences.candidates[0].prefnum = 2;

	/* Equal */
	v2.polling_place_code = 2;
	v2.electorate_code = 1;	
	v2.preferences.num_preferences = 3;
	v2.preferences.candidates[0].group_index = 1;
	v2.preferences.candidates[0].db_candidate_index = 3;
	v2.preferences.candidates[0].prefnum = 2;
	v2.preferences.candidates[1].group_index = 3;
	v2.preferences.candidates[1].db_candidate_index = 4;
	v2.preferences.candidates[1].prefnum = 1;
	v2.preferences.candidates[2].group_index = 5;
	v2.preferences.candidates[2].db_candidate_index = 7;
	v2.preferences.candidates[2].prefnum = 4;

	/* Different num_preferences */
	v3.polling_place_code = 2;
	v3.electorate_code = 1;	
	v3.preferences.num_preferences = 2;
	v3.preferences.candidates[0].group_index = 1;
	v3.preferences.candidates[0].db_candidate_index = 3;
	v3.preferences.candidates[0].prefnum = 2;
	v3.preferences.candidates[1].group_index = 3;
	v3.preferences.candidates[1].db_candidate_index = 4;
	v3.preferences.candidates[1].prefnum = 1;

	/* Different Group Index */
	v4.polling_place_code = 2;
	v4.electorate_code = 1;
	v4.preferences.num_preferences = 3;
	v4.preferences.candidates[2].group_index = 5;
	v4.preferences.candidates[2].db_candidate_index = 7;
	v4.preferences.candidates[2].prefnum = 4;
	v4.preferences.candidates[0].group_index = 1;
	v4.preferences.candidates[0].db_candidate_index = 3;
	v4.preferences.candidates[0].prefnum = 2;
	v4.preferences.candidates[1].group_index = 2;
	v4.preferences.candidates[1].db_candidate_index = 4;
	v4.preferences.candidates[1].prefnum = 1;

	/* Different candidate index */
	v5.polling_place_code = 2;
	v5.electorate_code = 1;	
	v5.preferences.num_preferences = 3;
	v5.preferences.candidates[0].group_index = 1;
	v5.preferences.candidates[0].db_candidate_index = 6;
	v5.preferences.candidates[0].prefnum = 2;
	v5.preferences.candidates[1].group_index = 3;
	v5.preferences.candidates[1].db_candidate_index = 4;
	v5.preferences.candidates[1].prefnum = 1;
	v5.preferences.candidates[2].group_index = 5;
	v5.preferences.candidates[2].db_candidate_index = 7;
	v5.preferences.candidates[2].prefnum = 4;

	/* Different prefnum */
	v6.polling_place_code = 2;
	v6.electorate_code = 1;
	v6.preferences.num_preferences = 3;
	v6.preferences.candidates[0].group_index = 1;
	v6.preferences.candidates[0].db_candidate_index = 3;
	v6.preferences.candidates[0].prefnum = 2;
	v6.preferences.candidates[1].group_index = 3;
	v6.preferences.candidates[1].db_candidate_index = 4;
	v6.preferences.candidates[1].prefnum = 1;
	v6.preferences.candidates[2].group_index = 5;
	v6.preferences.candidates[2].db_candidate_index = 7;
	v6.preferences.candidates[2].prefnum = 3;
	
	/* Different electorate_code */
	v7.electorate_code = 0;
	v7.polling_place_code = 2;
	v7.preferences.num_preferences = 3;
	v7.preferences.candidates[0].group_index = 1;
	v7.preferences.candidates[0].db_candidate_index = 3;
	v7.preferences.candidates[0].prefnum = 2;
	v7.preferences.candidates[1].group_index = 3;
	v7.preferences.candidates[1].db_candidate_index = 4;
	v7.preferences.candidates[1].prefnum = 1;
	v7.preferences.candidates[2].group_index = 5;
	v7.preferences.candidates[2].db_candidate_index = 7;
	v7.preferences.candidates[2].prefnum = 4;
	
	/* Different polling place */
	v8.electorate_code = 1;
	v8.polling_place_code = 1;
	v8.preferences.num_preferences = 3;
	v8.preferences.candidates[0].group_index = 1;
	v8.preferences.candidates[0].db_candidate_index = 3;
	v8.preferences.candidates[0].prefnum = 2;
	v8.preferences.candidates[1].group_index = 3;
	v8.preferences.candidates[1].db_candidate_index = 4;
	v8.preferences.candidates[1].prefnum = 1;
	v8.preferences.candidates[2].group_index = 5;
	v8.preferences.candidates[2].db_candidate_index = 7;
	v8.preferences.candidates[2].prefnum = 4;
	
	if (!compare_votes(&v1,&v2)) exit(1);
	if (!compare_votes(&v2,&v1)) exit(2);
	if (compare_votes(&v1,&v3)) exit(3);
	if (compare_votes(&v4,&v1)) exit(4);
	if (compare_votes(&v5,&v6)) exit(5);
	if (compare_votes(&v1,&v5)) exit(6);
	if (compare_votes(&v1,&v6)) exit(7);
	if (compare_votes(&v6,&v1)) exit(8);
	if (compare_votes(&v1,&v7)) exit(9);
	if (compare_votes(&v1,&v8)) exit(10);

	exit(0);
}
