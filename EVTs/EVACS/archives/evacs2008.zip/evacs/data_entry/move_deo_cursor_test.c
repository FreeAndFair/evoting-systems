/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "move_deo_cursor.c"
#include <stdlib.h>
#include <string.h>
#include <voting_client/verify_barcode.h>
#include <common/authenticate.h>
#include <common/ballot_contents.h>
#include <voting_client/vote_in_progress.h>
#include <voting_client/get_rotation.h>

struct ballot_contents *bc ;
struct electorate *voter_electorate;
static struct preference_set prefs = { 1, {{0,1,1}} };
static struct rotation rot5 = { 5, { 1,2,3,4,5 } };
static struct rotation *curr_rotation = &rot5;
unsigned int get_language(void);

/* Stubs */
const struct electorate *get_voter_electorate(void)
{
	return voter_electorate;
}
struct ballot_contents *get_ballot_contents(void)
{
	return bc;
}
unsigned int get_language(void)
{
	return 0;
}
void wait_for_reset(void)
{
	while (true);
}
const struct rotation *get_current_rotation(void)
{
	return curr_rotation;
}

const struct preference_set *get_vote_in_progress(void)
{
	return &prefs;
}

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif


int main(int argc, char *argv[])
{
	struct cursor cursor;	
	enum deo_keystroke key;
	int i;
	char electorate_name[9];

	if(!initialise_display(false))
                exit(1);

	bc = malloc(sizeof(*bc) + sizeof(bc->num_candidates[0])*8);
	bc->num_groups = 8;
	bc->num_candidates[0] = 4;
	bc->num_candidates[1] = 2;
	bc->num_candidates[2] = 1;
	bc->num_candidates[3] = 3;
	bc->num_candidates[4] = 2;
	bc->num_candidates[5] = 2;
	bc->num_candidates[6] = 4;
	bc->num_candidates[7] = 3;

	strcpy(electorate_name,"Molonglo");

	voter_electorate = malloc(sizeof(struct electorate) 
				  + strlen(electorate_name)+1);

	voter_electorate->code = 1;
	voter_electorate->num_seats = 5;
	strcpy(voter_electorate->name, "Molonglo");

	/* TEST DDS3.16: Update DEO Cursor Position */
	cursor.group_index = 3;
	cursor.screen_candidate_index = 1;
	update_deo_cursor_position(cursor, DEO_KEYSTROKE_DOWN);
	cursor = get_cursor_position();
	if ((cursor.group_index != 3) || (cursor.screen_candidate_index != 2))
		exit(1);
	update_deo_cursor_position(cursor, DEO_KEYSTROKE_NEXT);
	cursor = get_cursor_position();
	if ((cursor.group_index != 4) || (cursor.screen_candidate_index != -1))
		exit(1);
	update_deo_cursor_position(cursor, DEO_KEYSTROKE_UP);
	cursor = get_cursor_position();
	if ((cursor.group_index != 4) || (cursor.screen_candidate_index != 1))
		exit(1);

	dsp_mn_vt_scn();
	/* TEST DDS3.16: Move DEO Cursor */
	cursor.group_index = 0;
	cursor.screen_candidate_index = -1;
	set_cursor_position(cursor);
	for (i=0;i<5;i++) {
		key = DEO_KEYSTROKE_DOWN;
		move_deo_cursor(key);
		if (argc == 2) sleep(1);
	}
	cursor = get_cursor_position();
	if ((cursor.group_index != 0) || (cursor.screen_candidate_index != -1))
		exit(1);

	for (i=0;i<6;i++) {
		key = DEO_KEYSTROKE_NEXT;
		move_deo_cursor(key);
		if (argc == 2) sleep(1);
	}
	cursor = get_cursor_position();
	if ((cursor.group_index != 6) || (cursor.screen_candidate_index != -1))
		exit(1);

	for (i=0;i<6;i++) {
		key = DEO_KEYSTROKE_UP;
		move_deo_cursor(key);
		if (argc == 2) sleep(1);
	}
	cursor = get_cursor_position();
	if ((cursor.group_index != 6) || (cursor.screen_candidate_index != 3))
		exit(1);
	if (argc == 2) sleep(1);
	
	exit(0);
}
