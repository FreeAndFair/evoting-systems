/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Gneral Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

#include <string.h>
#include <libpq-fe.h>
#include "confirm_paper.c"

struct paper *papers[5];
unsigned int i = 0;
struct preference_set prefs ={ 1, 3,{ { 3, 2, 1 },{ 3, 1, 3 },{ 2, 0 ,2} } };
                
#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

unsigned int current_batch;


char *vsprintf_malloc(const char *fmt, va_list arglist)
     /*
       This is a self-allocating vsprintf function.
       
       NOTE: This function allocates memory. It is
       the callers responsibility to free it after
       use. Also, this function does not call va_end.
       It is the callers responsibility to do this.
      */

{
  char *str=NULL;

  /* Allocate amount of space indicated by vsnprintf */

  str = (char *)malloc(vsnprintf(str,0,fmt,arglist)+1);

  /* Write into string for real this time */

  vsprintf(str,fmt,arglist);
  return(str);
}

char *sprintf_malloc(const char *fmt, ...)
     /*
       Variable number of parameter interface to vsprintf_malloc().
     */
     
{
  char *str;
  va_list arglist;
  
  va_start(arglist,fmt);
  str = vsprintf_malloc(fmt,arglist);
  va_end(arglist);
  
  return(str);
}

/* Stubs */
unsigned int get_current_batch_number(void)
{
	return current_batch;
}

struct paper *get_paper(PGconn *conn,
			unsigned int batch_number, unsigned int paper_index)
{
	return papers[i++];
}

const struct preference_set *get_vote_in_progress(void)
{
	return &prefs;
}

void bailout(const char *fmt, ...)
{
	exit(1);
}

struct entry *get_entries_for_paper(PGconn *conn,
				    unsigned int paper_id,
				    char *electorate_name)
{
	struct entry *ret;

	int x = i-1;
	ret = papers[x]->entries;
	
	return ret;
}
	


void append_entry(PGconn *conn, struct entry *newentry, unsigned int batch_number, 
		unsigned int paper_index)
{
	int x = i-1;
	if ((x==4) || (x==3))
		papers[x]->entries = newentry;
	if (x==2)
		papers[x]->entries->next = newentry;
	if (x==0)
		papers[x]->entries->next->next = newentry;
	if (x==1)
		papers[x]->entries->next->next->next = newentry;
}

int main(int argc, char *argv[])
{
	PGconn *conn;
	unsigned int j,k;
	char *operator_id;
	struct paper *paper;
	bool save_ok;
	
	
	for (j=0;j<5;j++) {
		papers[j] = malloc(sizeof(papers[j]));
	}
	
	current_batch = 1;

	paper = malloc(sizeof(struct paper *));
	paper->entries = malloc(2*sizeof(struct entry) 
				+ sizeof(struct preference)*3);
	
	/* Incorrect group_index */
	papers[0]->p.supervisor_tick = false;
	papers[0]->entries = malloc(sizeof(struct entry)
				    + sizeof(struct preference));
	papers[0]->entries->e.paper_version_num = 1;
	papers[0]->entries->e.num_preferences = 1;
	papers[0]->entries->preferences[0].group_index = 1;
	papers[0]->entries->preferences[0].db_candidate_index = 1;
	papers[0]->entries->preferences[0].prefnum = 1;
	papers[0]->entries->next = malloc(sizeof(struct entry)
					  + sizeof(struct preference));
	papers[0]->entries->next->e.paper_version_num = 1;
	papers[0]->entries->next->e.num_preferences = 1;
	papers[0]->entries->next->preferences[0].group_index = 2;
	papers[0]->entries->next->preferences[0].db_candidate_index 
		= 1;
	papers[0]->entries->next->preferences[0].prefnum = 1;
	papers[0]->entries->next->next = NULL;
 	
	/* Corrected */
	papers[1]->p.supervisor_tick = false;
	papers[1]->entries = malloc(sizeof(struct entry)
				    + sizeof(struct preference));
	papers[1]->entries->e.paper_version_num = 1;
	papers[1]->entries->e.num_preferences = 1;
	papers[1]->entries->preferences[0].group_index = 1;
	papers[1]->entries->preferences[0].db_candidate_index = 1;
	papers[1]->entries->preferences[0].prefnum = 1;
	papers[1]->entries->next = malloc(sizeof(struct entry)
					  + sizeof(struct preference));
	papers[1]->entries->next->e.paper_version_num = 1;
	papers[1]->entries->next->e.num_preferences = 1;
	papers[1]->entries->next->preferences[0].group_index = 1;
	papers[1]->entries->next->preferences[0].db_candidate_index 
		= 2;
	papers[1]->entries->next->preferences[0].prefnum = 1;
	papers[1]->entries->next->next 
		= malloc(sizeof(struct entry) 
			 + sizeof(struct preference));
	papers[1]->entries->next->next->e.paper_version_num = 1;
	papers[1]->entries->next->next->e.num_preferences = 1;
	papers[1]->entries->next->next->preferences[0].group_index = 1;
	papers[1]->entries->next->next
		->preferences[0].db_candidate_index = 2;
	papers[1]->entries->next->next->preferences[0].prefnum = 1;
	papers[1]->entries->next->next->next = NULL;
	
	/* Only one entry */
	papers[2]->p.supervisor_tick = false;
	papers[2]->entries = malloc(sizeof(struct entry)
				    + sizeof(struct preference));
	papers[2]->entries->e.paper_version_num = 1;
	papers[2]->entries->e.num_preferences = 1;
	papers[2]->entries->preferences[0].group_index = 1;
	papers[2]->entries->preferences[0].db_candidate_index = 1;
	papers[2]->entries->preferences[0].prefnum = 1;
	papers[2]->entries->next = NULL;
	
	/* no previous entry */
	papers[3]->entries = NULL;

	papers[4]->entries = NULL;	
	
	/* TEST DDS????: Get Operator ID */
	operator_id = get_operator_id();
	
	if (argc == 2)
		printf("%s",operator_id);

	/* TEST DDS3.22: Save Entry */
	i = 4;
	paper = get_paper(conn,0,1);
	
	paper->entries = malloc(sizeof(struct entry) 
					+ strlen(operator_id) + 1
					+sizeof(struct preference) 
					* prefs.num_preferences);
	save_ok = save_deo_vote(0,1,paper->entries);
	if (!save_ok) exit(1);
	i = 4;
	paper = get_paper(conn,0,1);
	for (i=0;i<prefs.num_preferences;i++) {  
		if (papers[4]->entries->preferences[i].prefnum
            		!= prefs.candidates[i].prefnum) exit(1);
		if (papers[4]->entries->preferences[i].group_index
            		!= prefs.candidates[i].group_index) exit(1);
		if (papers[4]->entries->preferences[i].db_candidate_index
           		!= prefs.candidates[i].db_candidate_index) exit(1);
 	}
	

	/* TEST DDS3.22: Confirm Paper */
	i = 0;
	prefs.num_preferences = 2;
	prefs.candidates[0].prefnum = 2;
	prefs.candidates[0].group_index = 4;
	prefs.candidates[0].db_candidate_index = 1;
	prefs.candidates[1].prefnum = 1;
	prefs.candidates[1].group_index = 4;
	prefs.candidates[1].db_candidate_index = 0;
	for (k=0;k<4;k++) { 
		confirm_paper(1);
	}
	for (i=0;i<prefs.num_preferences;i++) { 
		if (papers[1]->entries->next->next->next != NULL) exit(1);
		
		if (papers[2]->entries->next->preferences[i].prefnum
		    != prefs.candidates[i].prefnum) exit(1);
		if (papers[2]->entries->next->preferences[i].group_index
		    != prefs.candidates[i].group_index) exit(1);
		if (papers[2]->entries->next->preferences[i]
		    .db_candidate_index 
		    != prefs.candidates[i].db_candidate_index) exit(1);

		if (papers[3]->entries->preferences[i].prefnum
		    != prefs.candidates[i].prefnum) exit(1);
		if (papers[3]->entries->preferences[i].group_index
		    != prefs.candidates[i].group_index) exit(1);
		if (papers[3]->entries->preferences[i]
		    .db_candidate_index 
		    != prefs.candidates[i].db_candidate_index) exit(1);
	}

	exit(0);
}
