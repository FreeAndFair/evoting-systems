/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include <string.h>
#define get_rotation_from_pvn _get_rotation_from_pvn
#include "get_paper_version.c"
#undef get_rotation_from_pvn
#include <common/rotation.h>

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

/* static struct rotation rot5 = { 5, { 1, 2, 3, 4, 5 } }; */
/* static struct rotation *curr_rotation = &rot5; */
struct electorate *voter_electorate;
bool valid = false;

/*
static struct rotation *get_rotation_from_pvn(const struct electorate *elec, 
				       unsigned int pvn)
{
	if (valid) {
		return curr_rotation;
	}
	else {
		valid = true;
		return NULL;
	}
}
*/

const struct electorate *get_voter_electorate(void)
{
	return voter_electorate;
}

int main(int argc, char *argv[])
{
	/* TEST DDS3.8: Start New Paper */
	/* TEST DDS3.8: Get Paper Version Number */	
	char electorate_name[9];
	unsigned int pvn;

	strcpy(electorate_name,"Molonglo");

	voter_electorate = malloc(sizeof(struct electorate) 
				  + strlen(electorate_name)+1);

	voter_electorate->code = 1;
	voter_electorate->num_seats = 5;
	strcpy(voter_electorate->name, "Molonglo");
	
	/* Interactive Test */
	if (argc == 2) {
		pvn = get_paper_version();
	}
	
	exit(0);
}
