/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include <stdlib.h>
#include <string.h>
#include <common/ballot_contents.h>
#include <voting_client/initiate_session.h>
#include <voting_client/input.h>
#include <voting_client/verify_barcode.h>
#include <voting_client/get_rotation.h>
#include <voting_client/vote_in_progress.h>
#include "move_deo_cursor.h"

#include "accumulate_deo_preferences.c"

static struct rotation rot7 = { 7, { 0, 1, 2, 3, 4, 5, 6 } };
static struct rotation *curr_rotation;
bool slow = true;
struct ballot_contents bc = {12,{4,7,3,2,2,4,2,7,2,2,4,2}};
struct electorate *voter_electorate;
struct cursor current_cursor = {-1,0};
unsigned int number_of_keystrokes = 0;
enum deo_keystroke ks[26] = {DEO_KEYSTROKE_DOWN,DEO_KEYSTROKE_DELETE,
			     DEO_KEYSTROKE_DOWN,DEO_KEYSTROKE_DELETE,
			     DEO_KEYSTROKE_UP,DEO_KEYSTROKE_3,
			     DEO_KEYSTROKE_CANCEL_PAPER,DEO_KEYSTROKE_DOWN,
			     DEO_KEYSTROKE_DOWN,DEO_KEYSTROKE_8,
			     DEO_KEYSTROKE_NEXT,DEO_KEYSTROKE_NEXT,
			     DEO_KEYSTROKE_NEXT,DEO_KEYSTROKE_NEXT,
			     DEO_KEYSTROKE_UP,DEO_KEYSTROKE_UP,DEO_KEYSTROKE_1,
			     DEO_KEYSTROKE_NEXT,DEO_KEYSTROKE_DOWN,
			     DEO_KEYSTROKE_DOWN,DEO_KEYSTROKE_DOWN,
			     DEO_KEYSTROKE_DOWN,DEO_KEYSTROKE_2,
			     DEO_KEYSTROKE_DELETE,DEO_KEYSTROKE_FINISH_PAPER,
			     DEO_KEYSTROKE_DELETE}; 
void get_event(void);
/* Stubs */
enum deo_keystroke interpret_deo_keystroke(void)
{
	if (slow) sleep(1);
	return ks[number_of_keystrokes++];
}

unsigned int get_language(void)
{
	return 0;
}
void get_event(void)
{
	abort();
}
/*  unsigned int get_num_gps_electorate(void) */
/*  { */
/*           return bc.num_groups; */
/*  } */
/*  unsigned int get_num_cands_in_gp(unsigned int group_index) */
/*  { */
/*          return bc.num_candidates[group_index]; */
/*  } */
const struct rotation *get_current_rotation(void)
{
	return curr_rotation;
}
void wait_for_reset(void)
{
	while (true) get_event();
}
const struct electorate *get_voter_electorate(void)
{
	return voter_electorate;
}
struct ballot_contents *get_ballot_contents(void)
{
	return &bc;
}
/*  struct cursor get_cursor_position(void) */
/*  { */
/*          return current_cursor; */
/*  } */
/*  void set_cursor_position(struct cursor cursor_position) */
/*  { */
/*          current_cursor.group_index = cursor_position.group_index; */
/*          current_cursor.screen_candidate_index */
/*                  = cursor_position.screen_candidate_index; */
/*  } */

void bailout(const char *fmt, ...)
{
	exit(1);
}

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

int main(int argc, char *argv[])
{
	bool cancelled, complete;
	char electorate_name[9];
	struct cursor default_cursor;
	const struct preference_set *prefs;

	default_cursor.group_index = 0;
	default_cursor.screen_candidate_index = -1;
	
	curr_rotation = &rot7;

	/* TEST DDS999998 */
	if (argc == 2) slow = true;
	if(!initialise_display(false))
		exit(1);
	
	/* Setup data */
	strcpy(electorate_name,"Molonglo");

	voter_electorate = malloc(sizeof(struct electorate) 
				  + strlen(electorate_name)+1);

	voter_electorate->code = 3;
	voter_electorate->num_seats = 7;
	strcpy(voter_electorate->name, "Molonglo");

	dsp_mn_vt_scn();
	draw_group_entry(default_cursor,NO, false);
	current_cursor.group_index = 4;
	current_cursor.screen_candidate_index = 1;
	draw_group_entry(current_cursor,YES, false);
	/* TEST DDS3.14: Handle CANCEL PAPER Screen */
	cancelled = display_cancel_paper_screen();
	if (cancelled) exit(1);
	cancelled = display_cancel_paper_screen();
	if (!cancelled) exit(1);

	/* TEST DDS3.14: Handle END PAPER Screen */
	dsp_mn_vt_scn();
	if (slow) sleep(1);
	complete = handle_end_paper_screen();
	if (complete) exit(1);
	complete = handle_end_paper_screen();
	if (!complete) exit(1);
	
	/* TEST DDS3.14: Accumulate DEO Preferences */
	set_cursor_position(default_cursor);	
	dsp_mn_vt_scn();
	cancelled = accumulate_deo_preferences();
	if (cancelled) exit(1);
	prefs = get_vote_in_progress();
	if ((prefs->num_preferences != 3) 
	    || (prefs->candidates[0].group_index != 0)
	    || (prefs->candidates[0].db_candidate_index != 3)
	    || (prefs->candidates[0].prefnum != 3))
		exit(1);
	
	exit(0);
}
