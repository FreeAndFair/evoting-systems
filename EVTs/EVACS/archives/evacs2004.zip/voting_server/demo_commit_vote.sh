#! /bin/sh  

#Dummy commit_vote.  
echo -e "Content-type: application/x-www-form-urlencoded\r"
echo -e "\r"
echo  "error=0"
exit 0
