#! /bin/sh

# Remember: this is run from the top directory!
OUTPUT="`echo ecode=0 | CONTENT_LENGTH=7 voting_server/get_rotation_test OK`"
[ $? = 0 ] || exit 1
echo "$OUTPUT" | fgrep -q "error=0" || exit 1
echo "$OUTPUT" | fgrep -q "&rotation0=0" || exit 1
echo "$OUTPUT" | fgrep -q "&rotation1=1" || exit 1
echo "$OUTPUT" | fgrep -q "&rotation2=2" || exit 1
echo "$OUTPUT" | fgrep -q "&rotation3=3" || exit 1
echo "$OUTPUT" | fgrep -q "&rotation4=4" || exit 1
echo "$OUTPUT" | fgrep -q "&rotation5=5" || exit 1
echo "$OUTPUT" | fgrep -q "&rotation6=6" || exit 1

exit 0
