/* This file is (C) copyright 2001 Software Improvements, Pty Ltd.
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#include <string.h>
#include <time.h>
#include <common/barcode.h>
#include <common/database.h>
#include <common/createtables.h>
#include <common/evacs.h>
#include "save_and_verify.c"

/*
  This program simulates 31 voters committing their votes simultaneously.
  All 31 should succeed!
*/
/* TEST DDS3.2.22: Save And Verify Vote */
int main(int argc, char *argv[])
{
	struct barcode bc;
	unsigned int i,num_rows;
	char *command;
	PGconn *conn;
	char hash[HASH_BITS + 1];

	conn = connect_db("evacs");

	create_polling_place_table(conn);
	create_barcode_table(conn);
	create_confirmed_vote_table(conn);
	create_confirmed_preference_table(conn);
	create_server_parameter_table(conn);
	
	SQL_command(conn,"INSERT INTO server_parameter(polling_place_code) "
		    "VALUES (1);");

	SQL_command(conn,"INSERT INTO polling_place VALUES(0,'Someplace');");
	/* Create a dummy barcode to use as a lock row */
	SQL_command(conn,"INSERT INTO barcode VALUES('1',0,1,false);");

	/* Create 31 barcodes for the kids */
	for (i=1;i<=31;i++) {
		memset(bc.data,'\0',sizeof(bc.data));
		sprintf(bc.data,"Multibarcode%u",i);
		gen_hash(hash,bc.data,sizeof(bc.data));      
		SQL_command(conn,"INSERT INTO barcode VALUES('%s',0,0,false);",
			    hash);
	}

	/* Lock the lock row */

	begin(conn);
	SQL_command(conn,"UPDATE barcode "
		    "SET electorate_code = 1 "
		    "WHERE electorate_code = 1;");

	/* Submit 31 child voters - this is at least 3X the amount we 
	   will every expect. 
	   NOTE: 32 is the MAXIMUM number of simultaneous connections that
	   a default Postgres installation can handle. To increase this,
	   change max_connections in the postgresql.conf file.
	*/

	for (i=0;i<31;i++) {
		command = sprintf_malloc("voting_server/voter Multibarcode%u &",i+1);
		system(command);
		free(command);
	}

	sleep(1);
	/* Unlock the row */
	commit(conn);

	/* all children will now try and vote using the same barcode */

	/* wait until the shooting match is over */
	sleep(5);

	/* Check that there is 31 votes in the system */

	num_rows = (unsigned int)SQL_singleton_int(conn,"SELECT COUNT(*) "
						   "FROM confirmed_vote;");

	/* Anything other that 31 rows is VERY VERY bad! */
	if ( num_rows != 31) {
		exit(1);
	}
	num_rows = (unsigned int)SQL_singleton_int(conn,"SELECT COUNT(*) "
						   "FROM confirmed_preference;");

	/* Anything other that 31*5 rows is VERY VERY bad! */
	if ( num_rows != 5*31) {
		exit(2);
	}
	exit(0);
}
