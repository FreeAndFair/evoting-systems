/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "reconstruct.c"

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

static struct rotation rot5 = { 5, { 4, 3, 2, 0, 1 } };

static struct {
	struct ballot_contents bc;
	unsigned int num_candidates[5];
} bc = { { 5 }, { 1, 2, 3, 4, 5 } };

struct ballot_contents *get_ballot_contents(void)
{
	return &bc.bc;
}

void bailout(const char *fmt, ...)
{
	abort();
}

/* DDS3.2.26: Reconstruct Keystrokes */
int main()
{
	struct preference_set prefs, prefs2;
	const char keystrokes[] =
		/* Move down one, then across 6 (all the way round the
		   paper to the start, plus one) */
		"DNNNNNN"
		/* Hit Select (this is on heading, does nothing) */
		"S"
		/* Three down, SELECT (still on heading) */
		"DDDS"
		/* UNDO (do nothing), then back */
		"XP"
		/* Select first candidate in each party. */
		"DSN" "DSN" "DSN" "DSN" "DSN"
		/* Undo them all, then up one. */
		"XXXXX" "U"
		/* Should be in top left.  Down and select to test */
		"DS" /* This selects GROUP0, CANDIDATE0 */
		/* Move to last group, down five, and select. */
		"PDDDDDS" /* This selects GROUP4, CANDIDATE0 */
		/* Down two, select, down two, undo, up three selec. */
		"DDSDDXUUUS" /* This selects GROUP4, CANDIDATE1 */
		/* Up three, select */
		"UUUS"; /* This selects GROUP4, CANDIDATE4 */

	/* TEST DDS3.2.26: Reconstruct Keystrokes */
	prefs = recon_keystrokes(&rot5, keystrokes);
	if (prefs.num_preferences != 4) exit(1);
	if (prefs.candidates[0].group_index != 0) exit(1);
	if (prefs.candidates[0].db_candidate_index != 0) exit(1);
	if (prefs.candidates[1].group_index != 4) exit(1);
	if (prefs.candidates[1].db_candidate_index != 0) exit(1);
	if (prefs.candidates[2].group_index != 4) exit(1);
	if (prefs.candidates[2].db_candidate_index != 1) exit(1);
	if (prefs.candidates[3].group_index != 4) exit(1);
	if (prefs.candidates[3].db_candidate_index != 3) exit(1);

	/* TEST DDS3.2.26: Compare Votes */
	prefs2 = prefs;
	if (!compare_votes(&prefs, &prefs2)) exit(1);
	prefs2.num_preferences--;
	if (compare_votes(&prefs, &prefs2)) exit(1);
	prefs2 = prefs;
	prefs2.candidates[3].db_candidate_index=5;
	if (compare_votes(&prefs, &prefs2)) exit(1);
	prefs2.num_preferences = 0;
	if (!compare_votes(&prefs2, &prefs2)) exit(1);

	/* test the whole thing */
	if (!reconstruct_and_compare(&rot5, keystrokes, &prefs))
		exit(1);
	prefs2 = prefs;
	prefs2.num_preferences++;
	if (reconstruct_and_compare(&rot5, keystrokes, &prefs2))
		exit(1);

	exit(0);
}
