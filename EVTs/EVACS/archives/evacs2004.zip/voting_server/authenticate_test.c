/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

extern int xmain(int argc, char *argv[]);
#define main xmain
#include "authenticate.c"
#undef main
#include <common/createtables.h>
#include <setjmp.h>

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

#define BARCODE_ASCII "aaaaaaaaaaaaaaaaaaaaaa"
#define USED_BARCODE_ASCII "aaaaaaaaaaaaaaaaaaaaab"

static enum error expected_error;
static jmp_buf jmpbuf;
static const char *barcode;

/* stub */
void cgi_good_response(const struct http_vars *vars)
{
	/* Expect correct electorate and ballot contents */
	if (strcmp(vars[0].name, "electorate_name") != 0) exit(1);
	if (strcmp(vars[1].name, "electorate_code") != 0) exit(1);
	if (strcmp(vars[2].name, "electorate_seats") != 0) exit(1);
	if (strcmp(vars[3].name, "num_groups") != 0) exit(1);
	if (strcmp(vars[4].name, "group0") != 0) exit(1);
	if (strcmp(vars[5].name, "group1") != 0) exit(1);
	if (strcmp(vars[6].name, "group2") != 0) exit(1);
	if (strcmp(vars[7].name, "group3") != 0) exit(1);
	if (strcmp(vars[8].name, "group4") != 0) exit(1);
	if (vars[9].name) exit(1);

	if (strcmp(vars[0].value, "Molonglo") != 0) exit(1);
	if (strcmp(vars[1].value, "0") != 0) exit(1);
	if (strcmp(vars[2].value, "7") != 0) exit(1);
	if (strcmp(vars[3].value, "5") != 0) exit(1);
	if (strcmp(vars[4].value, "7") != 0) exit(1);
	if (strcmp(vars[5].value, "4") != 0) exit(1);
	if (strcmp(vars[6].value, "3") != 0) exit(1);
	if (strcmp(vars[7].value, "2") != 0) exit(1);
	if (strcmp(vars[8].value, "1") != 0) exit(1);
	if (vars[9].value) exit(1);

	exit(0);
}

void cgi_error_response(enum error err)
{
	if (err != expected_error) exit(1);
	/* Jump home */
	longjmp(jmpbuf, 1);
}

struct http_vars *cgi_get_arguments(void)
{
	struct http_vars *vars;

	vars = malloc(sizeof(*vars)*2);
	vars[0].name = strdup("barcode");
	vars[0].value = strdup(barcode);
	vars[1].name = vars[1].value = NULL;

	return vars;
}

void set_cgi_bailout(void)
{
	/* Do nothing: normal abort is fine for testing */
}

int main(int argc, char *argv[])
{
	struct barcode_hash_entry *bhentry;
	struct barcode bc, bc2;
	struct http_vars *vars;
	struct electorate *elec;
	char hash[HASH_BITS + 1], hash2[HASH_BITS + 1];
	PGconn *conn;

	conn = clean_database("evacs");

	setenv("SERVER_PORT", STRINGIZE(SERVER_PORT), 1);
	strcpy(bc.ascii, BARCODE_ASCII);
	bar_decode_ascii(&bc);
	gen_hash(hash, bc.data, sizeof(bc.data));

	strcpy(bc2.ascii, USED_BARCODE_ASCII);
	bar_decode_ascii(&bc2);
	gen_hash(hash2, bc2.data, sizeof(bc2.data));

	/* Setup server_parameter table with polling place zero */
        create_table(conn, "server_parameter",
		     "id INTEGER NOT NULL PRIMARY KEY,"
		     "polling_place_code INTEGER NOT NULL");
	SQL_command(conn,"INSERT INTO server_parameter VALUES(1,0);");

	/* Put a barcode entry in there */
        create_table(conn, "barcode",
		     "hash bit("STRINGIZE(HASH_BITS)") NOT NULL PRIMARY KEY,"
		     "electorate_code integer NOT NULL,"
		     "polling_place_code INTEGER NOT NULL,"
		     "used BOOL NOT NULL DEFAULT FALSE");
	SQL_command(conn, "INSERT INTO barcode VALUES ( B'%s',%u,%u );",
		    hash, 0,0);
	SQL_command(conn, "INSERT INTO barcode VALUES ( B'%s',%u,%u,TRUE);",
		    hash2, 1,0);

	/* TEST DDS3.2.4: Get Barcode Hash Table */
	bhentry = get_bhash_table(conn, hash);
	if (!bhentry) exit(1);
	if (strcmp(bhentry->barcodehash, hash) != 0) exit(1);
	if (bhentry->ecode != 0) exit(1);
	if (bhentry->used != false) exit(1);
	bhentry = get_bhash_table(conn, hash2);
	if (!bhentry) exit(1);
	if (strcmp(bhentry->barcodehash, hash2) != 0) exit(1);
	if (bhentry->ecode != 1) exit(1);
	if (bhentry->used != true) exit(1);

	/* Populate electorates table */
	drop_table(conn,"electorate");
	create_table(conn,
		     "electorate", 
		     "code INTEGER PRIMARY KEY,"
		     "name TEXT NOT NULL UNIQUE,"
		     "seat_count INTEGER NOT NULL");
	SQL_command(conn,
		    "INSERT INTO electorate VALUES ( %u, '%s', %u );",
		    0, "Molonglo", 7);
	drop_table(conn,"party");
	SQL_command(conn,"CREATE TABLE party ("
		    "electorate_code INTEGER NOT NULL "
		    "REFERENCES electorate(code),"
		    "index INTEGER NOT NULL,"
		    "name TEXT NOT NULL,"
		       "PRIMARY KEY(electorate_code,index));");
	SQL_command(conn,
		    "INSERT INTO party VALUES ( 0, 0, 'First Party' );");
	SQL_command(conn,
		    "INSERT INTO party VALUES ( 0, 1, 'Second Party' );");
	SQL_command(conn,
		    "INSERT INTO party VALUES ( 0, 2, 'Third Party' );");
	SQL_command(conn,
		    "INSERT INTO party VALUES ( 0, 3, 'Fourth Party' );");
	SQL_command(conn,
		    "INSERT INTO party VALUES ( 0, 4, 'Fifth Party' );");
	drop_table(conn,"candidate");
	create_table(conn,"candidate",
		       "electorate_code INTEGER NOT NULL,"
		       "party_index INTEGER NOT NULL,"
		       "index INTEGER NOT NULL,"
		       "name TEXT NOT NULL,"
		       "FOREIGN KEY (electorate_code,party_index) "
		       "REFERENCES party(electorate_code,index),"
		       "PRIMARY KEY(electorate_code,party_index,index)");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 0, 0, 'P1C1' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 0, 1, 'P1C2' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 0, 2, 'P1C3' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 0, 3, 'P1C4' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 0, 4, 'P1C5' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 0, 5, 'P1C6' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 0, 6, 'P1C7' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 1, 0, 'P2C1' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 1, 1, 'P2C2' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 1, 2, 'P2C3' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 1, 3, 'P2C4' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 2, 0, 'P3C1' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 2, 1, 'P3C2' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 2, 2, 'P3C3' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 3, 0, 'P4C1' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 3, 1, 'P4C2' );");
	SQL_command(conn,
		    "INSERT INTO candidate VALUES ( 0, 4, 0, 'P5C1' );");

	/* test create_response */
	elec = get_electorates(conn);
	/* TEST DDS????: Get Ballot Contents */
	vars = create_response(conn, elec);
	free_electorates(elec);
	if (strcmp(vars[0].name, "electorate_name") != 0) exit(1);
	if (strcmp(vars[1].name, "electorate_code") != 0) exit(1);
	if (strcmp(vars[2].name, "electorate_seats") != 0) exit(1);
	if (strcmp(vars[3].name, "num_groups") != 0) exit(1);
	if (strcmp(vars[4].name, "group0") != 0) exit(1);
	if (strcmp(vars[5].name, "group1") != 0) exit(1);
	if (strcmp(vars[6].name, "group2") != 0) exit(1);
	if (strcmp(vars[7].name, "group3") != 0) exit(1);
	if (strcmp(vars[8].name, "group4") != 0) exit(1);
	if (vars[9].name) exit(1);

	if (strcmp(vars[0].value, "Molonglo") != 0) exit(1);
	if (strcmp(vars[1].value, "0") != 0) exit(1);
	if (strcmp(vars[2].value, "7") != 0) exit(1);
	if (strcmp(vars[3].value, "5") != 0) exit(1);
	if (strcmp(vars[4].value, "7") != 0) exit(1);
	if (strcmp(vars[5].value, "4") != 0) exit(1);
	if (strcmp(vars[6].value, "3") != 0) exit(1);
	if (strcmp(vars[7].value, "2") != 0) exit(1);
	if (strcmp(vars[8].value, "1") != 0) exit(1);
	if (vars[9].value) exit(1);
	http_free(vars);

	/* TEST DDS3.2.3: Authenticate */
	if (setjmp(jmpbuf) == 0) {
		/* Bad barcode */
		barcode = "bbbbbbbbbbbbbbbbbbbbbb";
		expected_error = ERR_BARCODE_AUTHENTICATION_FAILED;
		xmain(argc, argv);
	}

	if (setjmp(jmpbuf) == 0) {
		/* TEST DDS3.2.4: Check Unused */
		barcode = USED_BARCODE_ASCII;
		expected_error = ERR_BARCODE_USED;
		xmain(argc, argv);
	}

	/* TEST DDS3.2.4: Authenticate */
	barcode = BARCODE_ASCII;
	xmain(argc, argv);
	exit(1);
}

