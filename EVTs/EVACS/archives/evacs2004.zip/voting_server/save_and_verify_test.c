/* This file is (C) copyright 2001 Software Improvements, Pty Ltd.
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#include <string.h>
#include <time.h>
#include <common/barcode.h>
#include <common/database.h>
#include <common/createtables.h>

#include "save_and_verify.c"

/* TEST DDS3.2.22: Save And Verify Vote */
int main(int argc, char *argv[])
{
	struct preference_set vote_in;
	struct barcode bc;
	struct electorate elec;
	unsigned int err,i,count,num_rows,vote_id;
	PGresult *result;
	PGconn *conn;

	char hash[HASH_BITS + 1];

	conn = connect_db("evacs");

	create_polling_place_table(conn);
	create_barcode_table(conn);
	create_confirmed_vote_table(conn);
	create_confirmed_preference_table(conn);
	create_server_parameter_table(conn);

	SQL_command(conn,"INSERT into server_parameter(polling_place_code)"
		    "VALUES(0);");

	SQL_command(conn,"INSERT into polling_place VALUES(0,'Someplace');");

	strcpy(bc.data,"Single user barcode");
	gen_hash(hash,bc.data,sizeof(bc.data));      
	SQL_command(conn,"INSERT INTO barcode VALUES('%s',0,0,false);",
		    hash);

	elec.code = 0;

	srand(time(NULL));  /* Use random preferences ... */
	vote_in.num_preferences = 5;
	vote_in.candidates[0].group_index = 0;
	vote_in.candidates[0].db_candidate_index = 0;
	vote_in.candidates[0].prefnum = 1;
	vote_in.candidates[1].group_index = 1;
	vote_in.candidates[1].db_candidate_index = 1;
	vote_in.candidates[1].prefnum = 2;
	vote_in.candidates[2].group_index = 2;
	vote_in.candidates[2].db_candidate_index = 2;
	vote_in.candidates[2].prefnum = 3;
	vote_in.candidates[3].group_index = 3;
	vote_in.candidates[3].db_candidate_index = 3;
	vote_in.candidates[3].prefnum = 4;
	vote_in.candidates[4].group_index = 4;
	vote_in.candidates[4].db_candidate_index = 4;
	vote_in.candidates[4].prefnum = 5;
	
	/* TEST DDS3.2.22: Primary Store */
        err = primary_store_start(conn, &vote_in, &bc, &elec);
	if (err != ERR_OK) {
		primary_store_abort(conn);
		exit(1);
	}
	else
		err = primary_store_commit(conn);

	/* Check barcode marked as used */

	if ( !SQL_singleton_bool(conn,
				"SELECT used FROM barcode "
				"WHERE hash = '%s';",hash))
		exit(2);

	/* Check the confirmed vote */

	vote_id = SQL_singleton_int(conn,"SELECT id "
				       "FROM confirmed_vote;");

	if ( vote_id < 0 )
		exit(3);

	/* Extract the preferences */
	result = SQL_query(conn,
			   "SELECT group_index,"
			   "db_candidate_index,"
			   "prefnum "
			   "FROM confirmed_preference "
			   "WHERE vote_id = %u;",vote_id);

	num_rows = PQntuples(result);

	if (num_rows != 5) {
		printf("Got %u rows from confirmed preferences with vote_id %u\n\n",num_rows,vote_id);
		exit(4);
	}

	count = 0;
	for (i=0;i<num_rows;i++) {

		/* Check all the votes are there */

		for (i=0;i<5;i++)
			if ( vote_in.candidates[i].group_index == 
			     atoi(PQgetvalue(result,i,0)) &&
			     vote_in.candidates[i].db_candidate_index == 
			     atoi(PQgetvalue(result,i,1)) &&
			     vote_in.candidates[i].prefnum == 
			     atoi(PQgetvalue(result,i,2)))
				count++;
		
	}
	PQclear(result);

	if (count!=num_rows)
		exit(5);

	/* Insert another vote with the same barcode */

	/* This SHOULD fail! */

	/* TEST DDS3.2.22: Primary Store */
        err = primary_store_start(conn, &vote_in, &bc, &elec);
	if (err != ERR_OK) {
		primary_store_abort(conn);
		exit(0);
	}
	else
		err = primary_store_commit(conn);

	PQfinish(conn);

	exit(6);
}
