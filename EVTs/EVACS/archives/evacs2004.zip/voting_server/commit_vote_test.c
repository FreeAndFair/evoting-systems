/* This file is (C) copyright 2001 Software Improvements, Pty Ltd.
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#define main xmain
extern int xmain(int argc, char *argv[]);
#include "commit_vote.c"
#undef main
#include <setjmp.h>

#define BARCODE_ASCII "aaaaaaaaaaaaaaaaaaaaaa"
#define KEYSTROKES "UDUDUDDS"

static struct http_vars vars[] = { { (char *)"barcode", (char*)BARCODE_ASCII },
				   { (char *)"keystrokes", (char*)KEYSTROKES },
				   { (char *)"vote", (char *)"0,0" },
				   { (char *)"rotation0", (char *)"0" },
				   { (char *)"rotation1", (char *)"1" },
				   { (char *)"rotation2", (char *)"2" },
				   { (char *)"rotation3", (char *)"3" },
				   { (char *)"rotation4", (char *)"4" },
				   { (char *)"rotation5", (char *)"5" },
				   { (char *)"rotation6", (char *)"6" },
				   { NULL, NULL } };

struct a_elec {
	struct electorate elec;
	char name[80];
};

static jmp_buf jmpbuf;
static bool reconstruct_ok;
static struct a_elec elec = { { NULL, 1 }, "Electorate TEST 1" };
static enum error authenticate_error;
static enum error expected_cgi_error;

/* stubs */
void set_cgi_bailout(void)
{
}

PGconn *connect_db_port(const char *name, const char *port)
{
	return NULL;
}

struct http_vars *cgi_get_arguments(void)
{
	struct http_vars *ret;
	unsigned int i;

	ret = malloc(sizeof(vars));
	memcpy(ret, vars, sizeof(vars));
	for (i = 0; vars[i].value; i++) {
		ret[i].name = strdup(vars[i].name);
		ret[i].value = strdup(vars[i].value);
	}
	ret[i].name = ret[i].value = NULL;
		
	return ret;
}

enum error authenticate(const struct barcode *bc, struct electorate **elecp)
{
	if (strcmp(bc->ascii, BARCODE_ASCII) != 0) exit(1);
	*elecp = &elec.elec;
	return authenticate_error;
}

enum error save_and_verify(PGconn *conn,
			   const struct preference_set *vote,
			   const struct barcode *bc,
			    const struct electorate *elec,
			   const struct http_vars *vars)
{
	return ERR_OK;
}

void bailout(const char *fmt, ...)
{
	abort();
}

void cgi_error_response(enum error err)
{
	if (err != expected_cgi_error) exit(1);
	longjmp(jmpbuf, 1);
}

bool reconstruct_and_compare(const struct rotation *rot,
			     const char *keystrokes,
			     const struct preference_set *vote)
{
	return reconstruct_ok;
}

int main(int argc, char *argv[])
{
	struct preference_set prefs;

	setenv("SERVER_PORT", STRINGIZE(SERVER_PORT), 1);
	
	/* Test unwrap vote */
	prefs = unwrap_vote("0,0,4,0,4,1,4,3");
	if (prefs.num_preferences != 4) exit(1);
	if (prefs.candidates[0].group_index != 0) exit(1);
	if (prefs.candidates[0].db_candidate_index != 0) exit(1);
	if (prefs.candidates[1].group_index != 4) exit(1);
	if (prefs.candidates[1].db_candidate_index != 0) exit(1);
	if (prefs.candidates[2].group_index != 4) exit(1);
	if (prefs.candidates[2].db_candidate_index != 1) exit(1);
	if (prefs.candidates[3].group_index != 4) exit(1);
	if (prefs.candidates[3].db_candidate_index != 3) exit(1);
	prefs = unwrap_vote("");
	if (prefs.num_preferences != 0) exit(1);

	/* Test PR-72 failure case. */
	prefs = unwrap_vote("6,2,5,4,4,4,0,1,3,4,7,0,7,1,7,2");
	if (prefs.num_preferences != 8) exit(1);

	/* TEST DDS3.2.26: Commit Vote */
	authenticate_error = ERR_SERVER_UNREACHABLE;
	expected_cgi_error = ERR_SERVER_UNREACHABLE;
	reconstruct_ok = false;
	if (setjmp(jmpbuf) == 0) {
		xmain(argc, argv);
		exit(1);
	}
	authenticate_error = ERR_OK;
	reconstruct_ok = false;
	expected_cgi_error = ERR_RECONSTRUCTION_FAILED;
	if (setjmp(jmpbuf) == 0) {
		xmain(argc, argv);
		exit(1);
	}
	authenticate_error = ERR_OK;
	reconstruct_ok = true;
	expected_cgi_error = ERR_OK;
	if (setjmp(jmpbuf) == 0) {
		xmain(argc, argv);
		exit(1);
	}
	exit(0);
}
