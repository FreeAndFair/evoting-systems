/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "batch_edit.c"
#include <common/createtables.h>
#include <common/ballot_contents.h>
#include <common/batch_history.h>

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

static struct rotation rot5 = { 5, { 1,2,3,4,5 } };
static struct rotation *curr_rotation = &rot5;
struct electorate *voter_electorate=NULL;
char operator_id[20]="test";
unsigned int current_paper_index=0;

/* Stubs */

struct ballot_contents *get_electorate_ballot_contents(PGconn *conn,
						       unsigned int electorate_code)
{
	return NULL;
}

unsigned int get_current_paper_index(void)
{
	return current_paper_index;
}

void set_current_paper_index(unsigned int index)
{
	current_paper_index = index;
}

char *get_operator_id(void)
{
	return (char *) &operator_id;
}

void set_operator_id(char *name)
{
	strcpy((char *) &operator_id,name);
}

void confirm_paper(unsigned int pvn)
{

}

bool enter_paper(void)
{
	return true;
}
void store_electorate(struct electorate *electorate)
{
	if (voter_electorate) free(voter_electorate);
        voter_electorate = malloc(sizeof(struct electorate)
                                  + strlen(electorate->name)+1);
        voter_electorate->code = electorate->code;
        strcpy(voter_electorate->name,electorate->name);
        voter_electorate->num_seats = electorate->num_seats;
}
const struct electorate *get_voter_electorate(void)
{
	return voter_electorate;
}
struct rotation *fetch_rotation(PGconn *conn,
                                unsigned int rotation_num,
                                unsigned int seat_count)
{
	return curr_rotation;
}
void set_current_rotation(const struct rotation *rot)
{

}

const struct rotation *get_current_rotation(void)
{
	return curr_rotation;
}

int main(int argc, char *argv[])
{
	bool print = false;
	PGconn *conn;
	struct entry *entry;
	unsigned int i;
	char command;
	
	if (argc == 2) print = true;

	/* Set up database */
	conn = connect_db("template1");
        drop_database(conn,"batch_edit_test");
        create_database(conn,"batch_edit_test");
        conn=connect_db("batch_edit_test");

	create_electorate_table(conn);
	create_polling_place_table(conn);
	create_batch_table(conn);

	SQL_command(conn,"INSERT INTO electorate VALUES (0,'Electorate1',5);");

	SQL_command(conn,"INSERT INTO polling_place "
		    "VALUES(0,'PollingPlace1');");
	SQL_command(conn,"INSERT INTO batch VALUES(0,0,0,50,false);");
	SQL_command(conn,"INSERT INTO batch VALUES(1,0,0,50,false);");
	store_comm_batch_num(conn,0);

	create_paper_tables(conn);
	create_entry_tables(conn);

	entry = malloc(sizeof(*entry) + sizeof(entry->preferences[0])*5);
        strcpy(entry->e.operator_id,"Olivia");
	entry->e.num_preferences = 1;
	entry->preferences[0].group_index = 0;
        entry->preferences[0].db_candidate_index = 0;
        entry->preferences[0].prefnum = 1;
	append_entry(conn,entry,0,1);
	entry->e.num_preferences = 5;
	for (i=0;i<5;i++) {
                entry->preferences[i].group_index = 0;
                entry->preferences[i].db_candidate_index = i;
                entry->preferences[i].prefnum = i;
        }
	append_entry(conn,entry,0,1);
	entry->e.num_preferences = 1;
	entry->preferences[0].group_index = 0;
        entry->preferences[0].db_candidate_index = 0;
        entry->preferences[0].prefnum = 1;
	append_entry(conn,entry,0,2);
	entry->e.num_preferences = 5;
	for (i=0;i<5;i++) {
                entry->preferences[i].group_index = 0;
                entry->preferences[i].db_candidate_index = i;
                entry->preferences[i].prefnum = i;
        }
	append_entry(conn,entry,0,2);
	create_confirmed_vote_tables(conn);
	
	/* TEST DDS3.34: Print Batch */
	/* TEST DDS3.36: Print Paper */
	/* TEST DDS3.36: Get Candidate Name */
	create_party_table(conn);	
	SQL_command(conn, "INSERT INTO party VALUES(0,0,'Party1');");
	create_candidate_table(conn);
	SQL_command(conn, "INSERT INTO candidate VALUES(0,0,0,'Candidate1');");
	SQL_command(conn, "INSERT INTO candidate VALUES(0,0,1,'Candidate2');");
	SQL_command(conn, "INSERT INTO candidate VALUES(0,0,2,'Candidate3');");
	SQL_command(conn, "INSERT INTO candidate VALUES(0,0,3,'Candidate4');");
	SQL_command(conn, "INSERT INTO candidate VALUES(0,0,4,'Candidate5');");
	if (print) {
		print_batch(conn, 0);
		print_batch(conn, 1);
	}
	
	/* TEST DDS3.30: Print Batch Summary */
	/* TEST DDS3.30: Get Batch Information */
	if (print)
		print_batch_summary(conn);

	/* TEST DDS3.40: Print Errors in Batch */
	if (print)
		print_errors_in_batch(conn,0);

	/* TEST DDS3.38: Print Batches for Polling Place */
	if (print)
		print_pp_batches(conn,0,0);

	/* TEST DDS3.2: Write Menu */
	if (print)
		write_menu(conn,0);

	/* TEST DDS3.2: Get Command */
	if (print) {
		command = get_BEntry_command(conn,0);
		printf("The command you entered was: %c\n",command);
	}

	PQfinish(conn);

	exit(0);
}
