/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "batch_edit.c"
#include <stdbool.h>
#include <common/createtables.h>
#include <common/ballot_contents.h>
/*#include <common/batch_history.h>*/
#include <election_night/update_ens_summaries.h>


#define exit(x) { fprintf(stderr, "\n execution complete at line: %u\n", __LINE__); exit(x); }
#ifdef DATABASE_NAME
#undef DATABASE_NAME
#endif
#define DATABASE_NAME "batch_edit_test"
#ifdef SERVER_ADDRESS
#undef SERVER_ADDRESS
#endif
#define SERVER_ADDRESS "127.0.0.1"

static struct rotation rot5 = { 5, { 1,2,3,4,5 } };
static struct rotation *curr_rotation = &rot5;

struct  electorate voter_electorate = { 
	(struct electorate *)NULL,
	0,
	5,
        ""
};
/* hacky way of initialising voter_electorate.name  */
char el[20]="Electorate1";

char operator_id[20]="test";
unsigned int current_paper_index=0;

/* Stubs */


static void log_batch_operation(PGconn *conn, unsigned int batch_number, 
				enum batch_op opcode,
				int data1, int data2)
{
	
}

static void create_test_preference_summary_table(PGconn *conn)
     /*
       Create preference_summary table without referential constraints.

       NOTE: Ignore failure of DROP TABLE commands.
     */
{
        drop_table(conn,"preference_summary");
	create_table(conn,"preference_summary",
		     "electorate_code INTEGER NOT NULL, "

		     "polling_place_code INTEGER NOT NULL, "

		     "party_index INTEGER NOT NULL,"
		     "candidate_index INTEGER NOT NULL,"
		     "phoned_primary INTEGER NOT NULL,"
		     "evacs_primary INTEGER NOT NULL,"
		     "final_count INTEGER NOT NULL,"
		     "PRIMARY KEY (electorate_code,polling_place_code,"
		     "party_index,candidate_index)");
	
}

static void create_test_vote_summary_table(PGconn *conn)
     /*
       Create vote_summary table without referential constraints..

       NOTE: Ignore failure of DROP TABLE commands.
     */
{
        drop_table(conn,"vote_summary");
	create_table(conn,"vote_summary",
		     "electorate_code INTEGER NOT NULL, "

		     "polling_place_code INTEGER NOT NULL, "

		     "entered_by TEXT NOT NULL,"
		     "entered_at TIMESTAMP NOT NULL,"
		     "informal_count INTEGER NOT NULL");
}


struct ballot_contents *get_electorate_ballot_contents(PGconn *conn,
						       unsigned int electorate_code)
{
	return NULL;
}

unsigned int get_current_paper_index(void)
{
	return current_paper_index;
}

void set_current_paper_index(unsigned int index)
{
	current_paper_index = index;
}

char *get_operator_id(void)
{
	return (char *) &operator_id;
}
void set_operator_id(char *name);
void set_operator_id(char *name)
{
	strcpy((char *) &operator_id,name);
}

void confirm_paper(unsigned int pvn)
{
	printf("pvn is %u\n",pvn);
	printf("Paper Confirmed\n");
}

bool enter_paper(void)
{
	printf("Entering Paper...\n");
	return false;
}


void store_electorate(struct electorate *electorate)
{
        voter_electorate.code = electorate->code;
        strcpy(voter_electorate.name,electorate->name);
        voter_electorate.num_seats = electorate->num_seats;
}

const struct electorate *get_voter_electorate(void)
{
        return (struct electorate *) &voter_electorate;
}

struct rotation *fetch_rotation(PGconn *conn,
                                unsigned int rotation_num,
                                unsigned int seat_count)
{
	return curr_rotation;
}

void set_current_rotation(const struct rotation *rot)
{
	curr_rotation=(struct rotation *)rot;
}

const struct rotation *get_current_rotation(void)
{
	return curr_rotation;
}

/* tools   */
static bool pref_cmp(struct preference p1, struct preference p2)
{
	if (p1.prefnum != p2.prefnum ||
	    p1.group_index != p2.group_index ||
	    p1.db_candidate_index !=  p2.db_candidate_index)
		return false;
	else
		return true;
}

int main(int argc, char *argv[])
{
	struct preference p_in[5], p_out[5], p_out2[5], p_out3[5];
	unsigned int num_prefs_in = 5, num_prefs_out, i, j, entry_index, 
		num_votes, id, e_code, size;
	struct matched_preference *mp;
	struct normalised_preference *np, *norm_p;
	PGconn *conn;
	PGresult *result, *result2;
	bool committed, valid, interactive = false;
	struct entry *entry;
	char *o_id, *e_name;
	struct matched_preference *matched, *matchedp;
	struct batch_with_error *bwe;
	struct preference_set vote_out[2];
	const struct preference_set *vip;
	struct entry *current_entry;
	bool tick = false;
	unsigned int pid, pindex, bnum, ppcode;
	struct paper_with_error *pwe;

	if (argc == 2) interactive = true;
	e_name = sprintf_malloc("Electorate1");

	set_operator_id((char *)"test");

	
	printf("DB: %s IP: %s\n",DATABASE_NAME, SERVER_ADDRESS);
	/* TEST DDS3.26: Normalise Preferences */
	
	/* Correct, not in order   */
/* Init Convention: struct preference; { group_index, db_candidate_index, prefnum } */
	p_in[0] = (struct preference) { 2, 2, 3 };
	p_in[1] = (struct preference) { 0, 0, 2 };
	p_in[2] = (struct preference) { 0, 1, 1 };
	p_in[3] = (struct preference) { 4, 1, 5 };
	p_in[4] = (struct preference) { 2, 3, 4 };

/* I'd rather do something like this....  won't compile  */
/*	p_in = (struct preference[] ) {(struct preference) { 2, 2, 3 },
				      (struct preference) { 0, 0, 2 },
				      (struct preference) { 0, 1, 1 },
				      (struct preference) { 4, 1, 5 },
				      (struct preference) { 2, 3, 4 }
				      };*/
	normalise_prefs(p_out, &num_prefs_out, p_in, num_prefs_in);

	if (num_prefs_out != 5) exit(1);

	if (!pref_cmp(p_out[0],(struct preference) { 0, 1, 1})) exit(1);
	if (!pref_cmp(p_out[1],(struct preference) { 0, 0, 2})) exit(1);
	if (!pref_cmp(p_out[2],(struct preference) { 2, 2, 3})) exit(1);
	if (!pref_cmp(p_out[3],(struct preference) { 2, 3, 4})) exit(1);
 	if (!pref_cmp(p_out[4],(struct preference) { 4, 1, 5})) exit(1);
	
	
	/* Missing preference */
/* Init Convention: struct preference; { group_index, db_candidate_index, prefnum } */
	p_in[0] = (struct preference) { 0, 0, 2 };
	p_in[1] = (struct preference) { 0, 1, 1 };
	p_in[2] = (struct preference) { 4, 1, 6 };
	p_in[3] = (struct preference) { 2, 3, 5 };
	p_in[4] = (struct preference) { 2, 2, 3 };
	
	normalise_prefs(p_out2, &num_prefs_out, p_in, num_prefs_in);
	
	if (( num_prefs_out != 3) || 
	    (!pref_cmp(p_out2[0],(struct preference) { 0, 1, 1})) ||
	    (!pref_cmp(p_out2[1],(struct preference) { 0, 0, 2})) ||
	    (!pref_cmp(p_out2[2],(struct preference) { 2, 2, 3})) )
		exit(1);	

	/* Duplicate preference */
/* Init Convention: struct preference; { group_index, db_candidate_index, prefnum } */
	p_in[0] = (struct preference) { 0, 1, 1 };
	p_in[1] = (struct preference) { 0, 0, 2 };
	p_in[2] = (struct preference) { 2, 2, 2 }; /* duplicate */
	p_in[3] = (struct preference) { 2, 3, 3 };
	p_in[4] = (struct preference) { 4, 1, 4 };

	normalise_prefs(p_out3, &num_prefs_out, p_in, num_prefs_in);
	
	if ((num_prefs_out != 1) || 
	    (!pref_cmp(p_out3[0],(struct preference) { 0, 1, 1})) )
		exit(1);

	/* TEST DDS3.26: Normalise Batch */
	
	mp = malloc(sizeof(struct matched_preference) 
		    + sizeof(struct preference) * 3);
	
	/* Duplicate prefnum */
	mp->m.paper_index = 1;
	mp->m.num_preferences = 3;
	mp->preferences[0] = (struct preference) {3, 2, 2};
	mp->preferences[1] = (struct preference) {0, 2, 2};  /* duplicate */
	mp->preferences[2] = (struct preference) {5, 2, 1};
	
	/* Missing prefnum */
	mp->next = malloc(sizeof(struct matched_preference) 
			  + sizeof(struct preference) * 2);
	mp->next->m.paper_index = 1;
	mp->next->m.num_preferences = 2;
	mp->next->preferences[0] = (struct preference) {4, 2, 1};
	mp->next->preferences[1] = (struct preference) {3, 0, 3}; /* missing prefnum 2 */

	np = normalise_batch(mp);

	if ((np->next->n.num_preferences != 1) || (np->n.num_preferences != 1) || 
	    (!pref_cmp(np->preferences[0],(struct preference) { 4, 2, 1})) ||
	    (!pref_cmp(np->next->preferences[0],(struct preference) { 5, 2, 1})) )
		exit(1);

	/* Correct */
	mp->m.paper_index = 1;
	mp->m.num_preferences = 3;
	mp->preferences[0] = (struct preference) { 1, 1, 2};
	mp->preferences[1] = (struct preference) { 0, 2, 3};
	mp->preferences[2] = (struct preference) { 1, 3, 1};
	mp->next = malloc(sizeof(struct matched_preference) 
			  + sizeof(struct preference) * 4);
	mp->next->m.paper_index = 1;
	mp->next->m.num_preferences = 4;
	mp->next->preferences[0]=  (struct preference) { 1, 1, 1};
	mp->next->preferences[1]=  (struct preference) { 1, 0, 2};
	mp->next->preferences[2]=  (struct preference) { 3, 3, 4};
	mp->next->preferences[3]=  (struct preference) { 5, 2, 3};

	np = normalise_batch(mp);

	if ( (np->n.num_preferences != 4) ||
	     (!pref_cmp(np->preferences[0],(struct preference) { 1, 1, 1})) ||
	     (!pref_cmp(np->preferences[1],(struct preference) { 1, 0, 2})) ||
	     (!pref_cmp(np->preferences[2],(struct preference) { 5, 2, 3})) ||	
	     (!pref_cmp(np->preferences[3],(struct preference) { 3, 3, 4})) )
		exit(1);
	
	if ( (np->next->n.num_preferences != 3) ||
	     (!pref_cmp(np->next->preferences[0],(struct preference) { 1, 3, 1 } )) || 
	     (!pref_cmp(np->next->preferences[1],(struct preference) { 1, 1, 2 } )) ||
	     (!pref_cmp(np->next->preferences[2],(struct preference) { 0, 2, 3 } )) )
		exit(1);
	

	/* TEST DDS3.28: Store Committed Batch Number */

	/* Set up test database */
	conn = connect_db("template1");
        SQL_command_nobail(conn,"DROP DATABASE batch_edit_test;");
        create_database(conn,"batch_edit_test");
        conn=connect_db("batch_edit_test");
	create_electorate_table(conn);
	create_polling_place_table(conn);
        create_batch_table(conn);

	SQL_command(conn,"INSERT INTO electorate VALUES (0,'Electorate1',5);");
	
	SQL_command(conn,"INSERT INTO polling_place "
		    "VALUES(0,'PollingPlace1');");
	SQL_command(conn,"INSERT INTO batch VALUES(0,0,0,50,false);");
	SQL_command(conn,"INSERT INTO batch VALUES(1,0,0,50,false);");

	store_comm_batch_num(conn,0);
		     
	committed = SQL_singleton_bool(conn,
				       "SELECT committed "
				       "FROM batch "
				       "WHERE number = 0;");

	if (!committed) exit(1);

	committed = SQL_singleton_bool(conn,
				       "SELECT committed "
				       "FROM batch "
				       "WHERE number = 1;");
	if (committed) exit(1);

  	/* TEST DDS3.16: Set Entry Index */ 
	/* TEST DDS3.16: Get Entry Index from User */
	/* TEST DDS3.16: Prompt for Entry Index */
	/* TEST DDS3.16: Invalid Entry Index */
	/* TEST DDS3.16: Is Entry Index in Entered Batch Details */
	create_paper_tables(conn);
	create_entry_tables(conn);

	entry = malloc(sizeof(*entry) + sizeof(entry->preferences[0])*5);

        strcpy(entry->e.operator_id,"Olivia");

  	/* Append one entry */ 
        entry->e.num_preferences = 1;

        entry->preferences[0]=(struct preference) { 0, 0, 1};

        append_entry(conn,entry,0,1); 

          /* And one other */ 
        entry->e.num_preferences = 5;

        for (i=0;i<5;i++) {
                entry->preferences[i] = (struct preference) { 0, i, i+1 };
	}

        append_entry(conn,entry,0,1);

	o_id = malloc(10*sizeof(char));



  	/* TEST DDS3.26: Make Matched Preferences */
	entry = malloc(sizeof(*entry) + sizeof(entry->preferences[0])*5);

        strcpy(entry->e.operator_id,"Olivia");

  	/* Append one entry */ 
        entry->e.num_preferences = 1;
	entry->e.paper_version_num=1;
        entry->preferences[0] = (struct preference) { 0, 0, 1};

        append_entry(conn,entry,0,2);

	/* And one other */ 
        entry->e.num_preferences = 5;

        for (i=0;i<5;i++) {
                entry->preferences[i] = (struct preference) { 0, i, i+1};
        }

        append_entry(conn,entry,0,2);
	
	matched = make_match_prefs(conn,0);
	if ((matched->m.paper_index != 2) || (matched->m.num_preferences != 5) ||
	    (!pref_cmp(matched->preferences[0], (struct preference) {0, 0, 1 } )) ||
	    (!pref_cmp(matched->preferences[1], (struct preference) {0, 1, 2 } )) ||
	    (!pref_cmp(matched->preferences[2], (struct preference) {0, 2, 3 } )) ||
	    (!pref_cmp(matched->preferences[3], (struct preference) {0, 3, 4 } )) ||
	    (!pref_cmp(matched->preferences[4], (struct preference) {0, 4, 5 } )) )
		exit(1);
	
	if ((matched->next->m.paper_index != 1) ||
	    (matched->next->m.num_preferences != 5) || 
	    (!pref_cmp(matched->next->preferences[0],(struct preference) { 0, 0, 1 } )) ||
	    (!pref_cmp(matched->next->preferences[1],(struct preference) { 0, 1, 2 } )) ||
	    (!pref_cmp(matched->next->preferences[2],(struct preference) { 0, 2, 3 } )) ||
	    (!pref_cmp(matched->next->preferences[3],(struct preference) { 0, 3, 4 } )) ||
	    (!pref_cmp(matched->next->preferences[4],(struct preference) { 0, 4, 5 } )) )
		exit(1);

  	/* TEST DDS3.28: Commit Votes */ 
	SQL_command(conn,"UPDATE batch SET committed = false "
		    "WHERE number = 0;");

	
	create_confirmed_vote_tables(conn);

	norm_p = malloc(sizeof(struct normalised_preference ) 
			+ sizeof(struct preference) * 3);

	norm_p->n.num_preferences = 3;
	norm_p->preferences[0] = (struct preference) { 1, 1, 1 };
	norm_p->preferences[1] = (struct preference) { 2, 2, 2 };
	norm_p->preferences[2] = (struct preference) { 3, 3, 3 };
	norm_p->next = malloc(sizeof(struct normalised_preference ) 
			+ sizeof(struct preference) * 3);

	norm_p->next->n.num_preferences = 3;
	norm_p->next->preferences[0] = (struct preference) { 5, 5, 1 };
	norm_p->next->preferences[1] = (struct preference) { 4, 4, 2 };
	norm_p->next->preferences[2] = (struct preference) { 3, 3, 3 };
	norm_p->next->next = NULL;
	
	create_party_table(conn);
	create_candidate_table(conn);
	create_test_vote_summary_table(conn);
	create_test_preference_summary_table(conn);
	

	commit_votes(conn,0,norm_p);

/* check committed votes */
	result = SQL_query(conn, "SELECT id, batch_number,preference_list "
			   " FROM %s_confirmed_vote;",e_name);
	num_votes = PQntuples(result);
	
	for (i=0; i<num_votes; i++) {
		if (atoi(PQgetvalue(result, i, 1)) != 0) exit(1);
		id = atoi(PQgetvalue(result, i, 0));

		vote_out[i]=*unpack_preferences(PQgetvalue(result,i,2));
	}
		
	for (j=0;j<3;j++) {
		if (!pref_cmp(norm_p->preferences[j],vote_out[0].candidates[j] ))
			exit(1);
		if (!pref_cmp(norm_p->next->preferences[j],vote_out[1].candidates[j] ))
			exit(1);
	}

	/* TEST DDS3.12: Store Preferences */
	current_entry = malloc(sizeof(struct entry) 
		      + sizeof(struct preference) * 3);
	current_entry->e.num_preferences = 3;
	strcpy(current_entry->e.operator_id,get_operator_id());
	current_entry->e.paper_version_num=1;
	for (i=0;i<3;i++) {
		current_entry->preferences[i] = (struct preference) { i, i+2, i+1 };
	}
	store_pref(current_entry);
	vip = get_vote_in_progress();
	if (vip->num_preferences != current_entry->e.num_preferences) exit(1);
	for (i=0;i<3;i++) {
		if (!pref_cmp(vip->candidates[i], current_entry->preferences[i]))
			exit(1);
	}
	

	/* TEST DDS3.12: Populate Vote in Progress */
	/* TEST DDS3.12: Get Last Preferences */
	delete_prefs();
	pop_votes(conn, 0, 0, 1);

	vip = get_vote_in_progress();
	if (vip->num_preferences != 5) exit(1);
	for (i=0; i<vip->num_preferences; i++) {
		if (!pref_cmp(vip->candidates[i], (struct preference) { 0, i, i+1 } ))
			exit(1);
	}

	/* TEST DDS3.20: Remove Supervisor Tick */
	SQL_command(conn,
		    "UPDATE %s_paper SET supervisor_tick = true "
		    "WHERE id = 2",e_name);
	
	tick = SQL_singleton_bool(conn, "SELECT supervisor_tick FROM %s_paper "
				  "WHERE id = 2",e_name);
	if (!tick) exit(1);
	rm_sup_tick(conn,2);
	tick = SQL_singleton_bool(conn, "SELECT supervisor_tick FROM %s_paper "
				  "WHERE id = 2",e_name);
	if (tick) exit(1);

	/* TEST DDS3.20: Supervisor Duplicate */
	/* TEST DDS3.20: Next Entry Index */
	/* TEST DDS3.20: Get Copy of Entry */
	/* TEST DDS3.20: Store Entry */
	o_id = sprintf_malloc("Olivia");
	duplicate(conn,2,1,2,SQL_singleton_int(conn,"SELECT index FROM "
						 "%s_paper WHERE id = 2;",
						 e_name),
		  0,o_id,e_name);

	result = SQL_query(conn, "SELECT paper_id, operator_id, "
			   "num_preferences, paper_version, operator_id "
			    "FROM %s_entry WHERE id = 2;",e_name);
	if (PQntuples(result) != 1) exit(1);

	result2 = SQL_query(conn, "SELECT paper_id, operator_id, "
			   "num_preferences, paper_version, operator_id "
			    "FROM %s_entry WHERE id = 5;",e_name);

	if (PQntuples(result2) != 1) exit(1);

	if (atoi(PQgetvalue(result,0,0)) != atoi(PQgetvalue(result2,0,0)) - 1)
		exit(1);
	if (atoi(PQgetvalue(result,0,1)) != atoi(PQgetvalue(result2,0,1)))
		exit(1);
	if (atoi(PQgetvalue(result,0,2)) != atoi(PQgetvalue(result2,0,2)))
		exit(1);
	if (atoi(PQgetvalue(result,0,3)) != atoi(PQgetvalue(result2,0,3)))
		exit(1);
	if (strcmp(PQgetvalue(result,0,4),PQgetvalue(result2,0,4)) != 0) 
		exit(1);

	{ 
	/* TEST DDS3.26: Check Paper */
		bool expected_result[2][8] =  {
			/* results for non-approved errors (NO sup_tick) */
			{ false,false,false,false,false,false, true, true },
			/* results for approved errors (HAVE sup_tick) **/
			{ false,false,false, true, true, true, true, true} };
		/*   ^^^^ ignrd,unent,keyst,infml,miss#, dup#,crctd,correct ^^^^  */

		printf("Check Paper Test\n");
		pwe = malloc(sizeof(struct paper_with_error));
		pwe->p.supervisor_tick = false;

		for (pwe->p.supervisor_tick=false;
		     pwe->p.supervisor_tick==false;
		     pwe->p.supervisor_tick=true) 
			for (pwe->error_code= ENTRY_ERR_IGNORED;
			     pwe->error_code <= ENTRY_ERR_CORRECT;
			     pwe->error_code++) {
				printf("%s:",get_error_string(pwe->error_code));
				if (expected_result[pwe->p.supervisor_tick?1:0]
				    [pwe->error_code] != (check_paper(pwe))) 
					exit(1);
			}
		printf("\n");
	
	/* TEST DDS3.26: Extract Preferences & (implicitly) check_paper*/
	/* scenario: every combination of sup_tick and error_code is tested */
	
		printf("Extract Preferences test\n");
			
		bwe = malloc(sizeof(*bwe) + sizeof(bwe->papers[0])*2);
		bwe->b.batch_size = 2;
		bwe->b.batch_number = 0;
		bwe->papers[0].error_code = ENTRY_ERR_CORRECT;
		bwe->papers[0].p.supervisor_tick=false;
		
		for (bwe->papers[1].p.supervisor_tick=false;
		     bwe->papers[1].p.supervisor_tick==false;
		     bwe->papers[1].p.supervisor_tick=true) 
			
			for (bwe->papers[1].error_code= ENTRY_ERR_IGNORED;
			     bwe->papers[1].error_code <= ENTRY_ERR_CORRECT;
			     bwe->papers[1].error_code++) 
				if ( expected_result[bwe->papers[1].p.supervisor_tick?1:0]
				     [bwe->papers[1].error_code] != 
				     (extract_preferences(conn, bwe, &matchedp)) )
					exit(1);
	}
	if (interactive) {
		printf("Set Entry Index Test\n");
		for (i=0;i<2;i++) {
			valid = set_entry_index(conn, 1, &entry_index, o_id);
			if (valid) printf("Valid\n");
			else printf("Invalid\n");
		}

	/* TEST DDS3.10: Set Paper Index */
	/* TEST DDS3.10: Get Paper Index from User */
	/* TEST DDS3.10: Prompt for Paper Index */
		printf("Set Paper Index Test\n");
		for (i=0; i<2; i++) {
			valid = set_paper_index(conn, 0, &pid, &pindex);
			if (valid) printf("paper id %u, paper index %u"
					  "...Valid\n",
					  pid, pindex);
		}

	/* TEST DDS3.32: Set Batch Number */
	/* TEST DDS3.8: Get Batch Number from User */
	/* TEST DDS3.8: Prompt for Batch Number */
	/* TEST DDS3.8: Get Electorate Code from Batch Electorate */
	/* TEST DDS3.8: Get Electorate Code from Predefined Batch Details */
		printf("Set Batch Number Test\n");
		for (i=0; i<2; i++) {
			valid = set_batch_num(conn, &bnum,0);
			if (valid) printf("Batch number %u is Valid\n", bnum);
		}

	/* TEST DDS3.8: Set Uncommitted Batch Number */
		printf("Set Uncommitted Batch Number Test\n");
		for (i=0; i<2; i++) {
			valid = set_uncom_batch_num(conn, &bnum,0);
			if (valid) printf("Batch number %u is valid and "
					  "uncommitted\n",bnum);
		}

	/* TEST DDS3.38: Set Polling Place */
	/* TEST DDS3.38: Resolve Polling Place Code */
		printf("Set Polling Place Test\n");
		for (i=0; i<2; i++) {
			valid = set_polling_place(conn, &ppcode);
			if (valid) printf("polling place code is %u\n",ppcode);
		}
		
	/* TEST DDS3.24: Change Batch Size */		
		printf("Change Batch Size Test\n");
		for (i=0; i<2; i++) {
			chng_batch_size(conn,0);
			size = SQL_singleton_int(conn, "SELECT size "
						 "FROM batch "
						 "WHERE number = 0");
			printf("Batch size changed to %u\n",size);
		}
		
                /* TEST DDS3.2: Prompt for Electorate */
		/* TEST DDS3.2: Set Electorate */
		/* TEST DDS3.2: Get Electorate Name from User */
		/* TEST DDS3.2: Electorate Warning */
		printf("Set Electorate Test\n");
		/* Valid electorate is "Electorate1" */
		e_code = get_user_elect(conn);
		if (e_code != 0) exit(1);
		
		/* TEST DDS3.42: Approve Paper */
		/* TEST DDS3.42: Add Supervisor Tick */
		/* TEST DDS3.42: Invalid Supervisor Tick */
		/* TEST DDS3.42: Has Supervisor Tick */
		printf("Approve Paper Test\n");
		app_paper(conn, 0);
		app_paper(conn, 0);
		
		/* TEST DDS3.6: Edit Paper */ 
		printf("Edit Paper Test\n");
		edit_paper(conn,0,0);
	}
	PQfinish(conn);
	exit(0);
}




