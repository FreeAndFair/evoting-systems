/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

/* This file contains table and database create and drop functions. */
#include <stdlib.h>
#include <common/database.h>
#include <common/evacs.h>

#include "createtables.h"

int main(int argc, const char *argv[])
{
	PGconn *conn;

	/* Create a new database */
	conn = connect_db("template1");
	if (conn == NULL) bailout("Can't connect to database:template1\n");

	drop_database(conn,"canada");
	create_database(conn,"canada");
	PQfinish(conn);
	conn = connect_db("canada");

	/* Create a bunch of tables */
	create_electorate_table(conn);
	create_polling_place_table(conn);

	create_party_table(conn);
	create_candidate_table(conn);

	create_batch_table(conn);

	create_barcode_table(conn);
	create_server_parameter_table(conn);
	create_robson_rotation_table(conn,5);
	create_robson_rotation_table(conn,7);	

	/* Create a few electorates */
	SQL_command(conn,"INSERT INTO electorate VALUES(0,'terrance',5,10,'colour');");
	SQL_command(conn,"INSERT INTO electorate VALUES(1,'phillip',7,12,'colour');");
	SQL_command(conn,"INSERT INTO polling_place VALUES(1,'pplace_1','f',0);");
	SQL_command(conn,"INSERT INTO batch VALUES(1,1,1,50,'f');");


	create_paper_tables(conn);
	create_entry_tables(conn); 	
	create_confirmed_vote_tables(conn);

	/* Create electorate preference tables */
	create_electorate_preference_tables(conn);

	/* Confirm that the tables are really there */
	SQL_command(conn,"SELECT * from polling_place;");
	SQL_command(conn,"SELECT * from electorate;");
	SQL_command(conn,"SELECT * from party;");
	SQL_command(conn,"SELECT * from candidate;");
	SQL_command(conn,"SELECT * from batch;");
	SQL_command(conn,"SELECT * from phillip_paper;");
	SQL_command(conn,"SELECT * from phillip_entry;"); 
	SQL_command(conn,"SELECT * from barcode;");
	SQL_command(conn,"SELECT * from server_parameter;");
	SQL_command(conn,"SELECT * from robson_rotation_5;");
	SQL_command(conn,"SELECT * from robson_rotation_7;");
	SQL_command(conn,"SELECT * from terrance_confirmed_vote;");
	SQL_command(conn,"SELECT * from terrance;");
	SQL_command(conn,"SELECT * from phillip;");

	exit(0);
}

