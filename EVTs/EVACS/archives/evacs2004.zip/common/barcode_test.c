/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "barcode.c"
#include <stdio.h>
#include <stdlib.h>

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

static unsigned char bcvalues[] = { 0, 0x7F, 0xFF };

static void do_test(struct barcode *bc)
{
	struct barcode bc2;

	/* Encode, decode, compare */
	bar_encode_ascii(bc);
	bc2 = *bc;
	if (!bar_decode_ascii(&bc2)) exit(1);
	if (memcmp(bc->data, bc2.data, sizeof(bc->data)) != 0) exit(1);
	if (bc->checksum != bc2.checksum) exit(1);
}

static void count(struct barcode bc, unsigned int digit)
{
	unsigned int i;

	/* Do all from here down */
	if (digit == sizeof(bc.data)) {
		/* Simple checksum variations */
		for (i = 0; i < 16; i++) {
			bc.checksum = i;
			do_test(&bc);
		}
		return;
	}

	for (i = 0; i < sizeof(bcvalues)/sizeof(bcvalues[0]); i++) {
		bc.data[digit] = bcvalues[i];

		do_test(&bc);

		/* Try all lower digits */
		count(bc, digit+1);
	}
}

int main(int argc, char *argv[])
{
	struct barcode bc1, bc2;
	unsigned int i;

	/* TEST DDS3.2.1: Generate Checksum */
	memset(bc1.data, 0xFF, sizeof(bc1.data));
	bc1.checksum = gen_csum(&bc1);
	if (gen_csum(&bc1) != bc1.checksum) exit(1);

	/* Change one bit, and it must change */
	for (i = 0; i < sizeof(bc1.data); i++) {
		bc1.data[i]--;
		if (gen_csum(&bc1) == bc1.checksum) exit(1);
		bc1.checksum = gen_csum(&bc1);
	}

	/* Encode into ascii */
	bar_encode_ascii(&bc1);
	if (strlen(bc1.ascii) != BARCODE_ASCII_BYTES) exit(1);
	bc2 = bc1;
	bar_encode_ascii(&bc2);
	if (strcmp(bc1.ascii, bc2.ascii) != 0) exit(1);

	for (i = 0; i < sizeof(bc1.data); i++) 
		bc1.data[i] = bcvalues[0];
	bc1.checksum = 0;

	/* This complete test takes about 36 hours on my
           laptop... Interactive only */
	if (argc == 2) {
		count(bc1, 0);
	} else {
		count(bc1, 8);
	}
	exit(0);
}
