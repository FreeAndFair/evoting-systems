/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "evacs.c"
#include <stdbool.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

int main()
{
        struct preference_set vote_in;
	char *preference_list;

	/* check preference_string function */
	vote_in.num_preferences = 5;
	vote_in.candidates[0].group_index = 0;
	vote_in.candidates[0].db_candidate_index = 0;
	vote_in.candidates[0].prefnum = 1;
	vote_in.candidates[1].group_index = 1;
	vote_in.candidates[1].db_candidate_index = 1;
	vote_in.candidates[1].prefnum = 2;
	vote_in.candidates[2].group_index = 2;
	vote_in.candidates[2].db_candidate_index = 2;
	vote_in.candidates[2].prefnum = 3;
	vote_in.candidates[3].group_index = 3;
	vote_in.candidates[3].db_candidate_index = 3;
	vote_in.candidates[3].prefnum = 4;
	vote_in.candidates[4].group_index = 4;
	vote_in.candidates[4].db_candidate_index = 4;
	vote_in.candidates[4].prefnum = 5;
	
	preference_list=  preference_string(&vote_in);
	if (0 != strcmp(preference_list,"010000020101030202040303050404")) exit(1);
	  /*	printf("preference_list=>%s<\n",preference_list); */
	free(preference_list);

	vote_in.num_preferences = 0;
	preference_list=  preference_string(&vote_in);
	if (0 != strcmp(preference_list,"")) exit(1);
	    /*	printf("preference_list=>%s<\n",preference_list); */
	free(preference_list);
	exit(0);
}
