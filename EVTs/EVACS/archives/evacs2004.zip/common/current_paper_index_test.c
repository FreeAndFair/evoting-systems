/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

#include "current_paper_index.c"

int main()
{
	unsigned int pi;
	
	/* TEST DDS3.8: Clear Current Paper Index */
	current_paper_index = 0xdeadbeef;
	clear_current_paper_index();
	if (current_paper_index != 0) exit(1);

	/* TEST DDS3.8: Update Current Paper Index */
	pi = current_paper_index;
	update_current_paper_index();
	update_current_paper_index();
	if (pi != current_paper_index - 2) exit(1);

	/* TEST DDS3.22: Get Current Paper Index */
	pi = get_current_paper_index();
	if (pi != current_paper_index) exit(1);

	exit(0);
}	
