/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "socket.c"
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

#define TEST_STRING "This is a test"

int main()
{
	int fd_in;
	int status;
	struct sockaddr_in addr;
	int one=1;
	size_t size;

	fd_in = socket(PF_INET, SOCK_STREAM, 0);
	if (fd_in < 0) exit(1);

	/* This should fail */
	if (open_socket_out("127.0.0.1", 8088) >= 0)
		exit(1);

	/* Ensure test can run again immediately if we die. */
	setsockopt(fd_in, SOL_SOCKET, SO_REUSEADDR,(char *)&one,sizeof(one));

	/* Set up to listen on localhost:8088 */
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(8088);
	addr.sin_addr.s_addr = INADDR_ANY; /*htonl(0x7F000001); */
	if (bind(fd_in, (struct sockaddr *)&addr, sizeof(addr)) != 0)
		exit(1);

	if (listen(fd_in, 1) != 0) exit(1);

	/* Now fork and accept in the child. */
	if (!fork()) {
		int fd_new;
		char *ptr;
		socklen_t socklen = sizeof(addr);
		
		fd_new = accept(fd_in, (struct sockaddr *)&addr, &socklen);
		if (fd_new < 0) {
			perror("Accept failed");
			exit(1);
		}

		ptr = sock_load(fd_new, &size);
		if (!ptr) {
			perror("sock_load failed");
			exit(1);
		}

		if (size != strlen(TEST_STRING)) {
			fprintf(stderr, "sock_load size %u != %u\n", size,
			       strlen(TEST_STRING));
			exit(1);
		}

		if (strcmp(ptr, TEST_STRING) != 0) {
			fprintf(stderr, "sock_load string %s != %s\n",
			       ptr, TEST_STRING);
			exit(1);
		}

		/* Second one should timeout */
		fd_new = accept(fd_in, (struct sockaddr *)&addr, &socklen);
		if (fd_new < 0) {
			perror("Accept II failed");
			exit(1);
		}

		ptr = sock_load(fd_new, &size);
		if (ptr) {
			perror("sock_load didn't timeout");
			exit(1);
		}
		shutdown(fd_new, 3);
		exit(0);
	}

	/* Parent. */
	fd_in = open_socket_out("127.0.0.1", 8088);
	if (fd_in < 0) exit(1);
	
	if (sock_printf(fd_in, "%s", TEST_STRING) != strlen(TEST_STRING))
		exit(1);
	close(fd_in);

	fd_in = open_socket_out("127.0.0.1", 8088);
	if (fd_in < 0) exit(1);

	/* Make child time out */
	sleep(SOCKET_TIMEOUT+4);

	/* Now try a conversation: read should fail */
	sock_printf(fd_in, "%s", TEST_STRING);
	sleep(1);
	if (sock_load(fd_in, &size)) exit(1);
	close(fd_in);

	wait(&status);
	if (!WIFEXITED(status) || WEXITSTATUS(status) != 0)
		exit(1);

	exit(0);
}
