/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

/* this file contains the tests for ballot contents   */

#include "get_electorate_ballot_contents.c"

#include <common/createtables.h>

#undef DATABASE_NAME
#define DATABASE_NAME "evacs_test"
int main(void) 
{
	struct ballot_contents *bc1, *bc2;
	unsigned int electorate=0;

	PGconn *conn;

	/* drop and create test database */
	conn = clean_database(DATABASE_NAME);
	
	create_electorate_table(conn);
       	create_party_table(conn);
       	create_candidate_table(conn);
	SQL_command(conn,"INSERT into electorate "
		    "VALUES(0,'Romani eta domum',5);");
	SQL_command(conn,"INSERT into party (electorate_code, index, name) "
		    "VALUES (0,0,'Peoples Front of Judea');");
	SQL_command(conn,"INSERT into candidate "
		    "(electorate_code,party_index,index, name) "
		    "VALUES (0,0,1,'Brian of Nazareth');");
	SQL_command(conn,"INSERT into candidate "
		    "(electorate_code,party_index,index, name) "
		    "VALUES (0,0,2,'The Holy Gourd');");
	
	PQfinish(conn);

	conn=connect_db(DATABASE_NAME);
	

	bc1 = get_electorate_ballot_contents(conn, electorate);
	
	PQfinish(conn);

	set_ballot_contents(bc1);

	bc2 = get_ballot_contents();

	if (bc1 != bc2) exit(1);
	exit(0);
}
