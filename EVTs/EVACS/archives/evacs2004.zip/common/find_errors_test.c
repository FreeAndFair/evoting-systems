 /* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "find_errors.c"

int main()
{
	struct batch *batch;
	struct batch_with_error *bwe;

	batch = malloc(sizeof(*batch) + sizeof(batch->papers[0])*10);
	batch->next = NULL;
	batch->b.batch_number = 1;
	batch->b.batch_size = 11;
	batch->b.committed = false;
	batch->b.num_papers = 12;

	/* DEO 1 entered eight papers, DEO2 entered ten papers */
	/* Paper 1: Keystroke error (different PVNs) */
	batch->papers[0].p.supervisor_tick = false;
	batch->papers[0].entries = malloc(sizeof(struct entry));
	batch->papers[0].entries->e.paper_version_num = 1;
	batch->papers[0].entries->e.num_preferences = 0;
	batch->papers[0].entries->next = malloc(sizeof(struct entry));
	batch->papers[0].entries->next->e.paper_version_num = 2;
	batch->papers[0].entries->next->e.num_preferences = 0;
	batch->papers[0].entries->next->next = NULL;

	/* Paper 2: Keystroke error (different prefnums) */
	batch->papers[1].p.supervisor_tick = false;
	batch->papers[1].entries = malloc(sizeof(struct entry)
					  + sizeof(struct preference));
	batch->papers[1].entries->e.paper_version_num = 1;
	batch->papers[1].entries->e.num_preferences = 1;
	batch->papers[1].entries->preferences[0].group_index = 1;
	batch->papers[1].entries->preferences[0].db_candidate_index = 1;
	batch->papers[1].entries->preferences[0].prefnum = 1;
	batch->papers[1].entries->next = malloc(sizeof(struct entry)
					       + sizeof(struct preference));
	batch->papers[1].entries->next->e.paper_version_num = 1;
	batch->papers[1].entries->next->e.num_preferences = 1;
	batch->papers[1].entries->next->preferences[0].group_index = 1;
	batch->papers[1].entries->next->preferences[0].db_candidate_index = 1;
	batch->papers[1].entries->next->preferences[0].prefnum = 2;
	batch->papers[1].entries->next->next = NULL;

	/* Paper 3: Keystroke error (different groups) */
	batch->papers[2].p.supervisor_tick = false;
	batch->papers[2].entries = malloc(sizeof(struct entry)
					  + sizeof(struct preference));
	batch->papers[2].entries->e.paper_version_num = 1;
	batch->papers[2].entries->e.num_preferences = 1;
	batch->papers[2].entries->preferences[0].group_index = 1;
	batch->papers[2].entries->preferences[0].db_candidate_index = 1;
	batch->papers[2].entries->preferences[0].prefnum = 1;
	batch->papers[2].entries->next = malloc(sizeof(struct entry)
					       + sizeof(struct preference));
	batch->papers[2].entries->next->e.paper_version_num = 1;
	batch->papers[2].entries->next->e.num_preferences = 1;
	batch->papers[2].entries->next->preferences[0].group_index = 2;
	batch->papers[2].entries->next->preferences[0].db_candidate_index = 1;
	batch->papers[2].entries->next->preferences[0].prefnum = 1;
	batch->papers[2].entries->next->next = NULL;

	/* Paper 4: Keystroke error (different candidates) */
	batch->papers[3].p.supervisor_tick = false;
	batch->papers[3].entries = malloc(sizeof(struct entry)
					  + sizeof(struct preference));
	batch->papers[3].entries->e.paper_version_num = 1;
	batch->papers[3].entries->e.num_preferences = 1;
	batch->papers[3].entries->preferences[0].group_index = 1;
	batch->papers[3].entries->preferences[0].db_candidate_index = 1;
	batch->papers[3].entries->preferences[0].prefnum = 1;
	batch->papers[3].entries->next = malloc(sizeof(struct entry)
					       + sizeof(struct preference));
	batch->papers[3].entries->next->e.paper_version_num = 1;
	batch->papers[3].entries->next->e.num_preferences = 1;
	batch->papers[3].entries->next->preferences[0].group_index = 1;
	batch->papers[3].entries->next->preferences[0].db_candidate_index = 2;
	batch->papers[3].entries->next->preferences[0].prefnum = 1;
	batch->papers[3].entries->next->next = NULL;

	/* Paper 5: Informal (no 1) */
	batch->papers[4].p.supervisor_tick = false;
	batch->papers[4].entries = malloc(sizeof(struct entry)
					  + sizeof(struct preference));
	batch->papers[4].entries->e.paper_version_num = 1;
	batch->papers[4].entries->e.num_preferences = 1;
	batch->papers[4].entries->preferences[0].group_index = 1;
	batch->papers[4].entries->preferences[0].db_candidate_index = 1;
	batch->papers[4].entries->preferences[0].prefnum = 2;
	batch->papers[4].entries->next = malloc(sizeof(struct entry)
					       + sizeof(struct preference));
	batch->papers[4].entries->next->e.paper_version_num = 1;
	batch->papers[4].entries->next->e.num_preferences = 1;
	batch->papers[4].entries->next->preferences[0].group_index = 1;
	batch->papers[4].entries->next->preferences[0].db_candidate_index = 1;
	batch->papers[4].entries->next->preferences[0].prefnum = 2;
	batch->papers[4].entries->next->next = NULL;

	/* Paper 6: Informal (two 1s) */
	batch->papers[5].p.supervisor_tick = false;
	batch->papers[5].entries = malloc(sizeof(struct entry)
					  + sizeof(struct preference)*2);
	batch->papers[5].entries->e.paper_version_num = 1;
	batch->papers[5].entries->e.num_preferences = 2;
	batch->papers[5].entries->preferences[0].group_index = 1;
	batch->papers[5].entries->preferences[0].db_candidate_index = 1;
	batch->papers[5].entries->preferences[0].prefnum = 1;
	batch->papers[5].entries->preferences[1].group_index = 1;
	batch->papers[5].entries->preferences[1].db_candidate_index = 2;
	batch->papers[5].entries->preferences[1].prefnum = 1;
	batch->papers[5].entries->next = malloc(sizeof(struct entry)
					       + sizeof(struct preference)*2);
	batch->papers[5].entries->next->e.paper_version_num = 1;
	batch->papers[5].entries->next->e.num_preferences = 2;
	batch->papers[5].entries->next->preferences[0].group_index = 1;
	batch->papers[5].entries->next->preferences[0].db_candidate_index = 1;
	batch->papers[5].entries->next->preferences[0].prefnum = 1;
	batch->papers[5].entries->next->preferences[1].group_index = 1;
	batch->papers[5].entries->next->preferences[1].db_candidate_index = 2;
	batch->papers[5].entries->next->preferences[1].prefnum = 1;
	batch->papers[5].entries->next->next = NULL;

	/* Paper 7: Missing number */
	batch->papers[6].p.supervisor_tick = false;
	batch->papers[6].entries = malloc(sizeof(struct entry)
					  + sizeof(struct preference)*2);
	batch->papers[6].entries->e.paper_version_num = 1;
	batch->papers[6].entries->e.num_preferences = 2;
	batch->papers[6].entries->preferences[0].group_index = 1;
	batch->papers[6].entries->preferences[0].db_candidate_index = 1;
	batch->papers[6].entries->preferences[0].prefnum = 1;
	batch->papers[6].entries->preferences[1].group_index = 1;
	batch->papers[6].entries->preferences[1].db_candidate_index = 2;
	batch->papers[6].entries->preferences[1].prefnum = 3;
	batch->papers[6].entries->next = malloc(sizeof(struct entry)
					       + sizeof(struct preference)*2);
	batch->papers[6].entries->next->e.paper_version_num = 1;
	batch->papers[6].entries->next->e.num_preferences = 2;
	batch->papers[6].entries->next->preferences[0].group_index = 1;
	batch->papers[6].entries->next->preferences[0].db_candidate_index = 1;
	batch->papers[6].entries->next->preferences[0].prefnum = 1;
	batch->papers[6].entries->next->preferences[1].group_index = 1;
	batch->papers[6].entries->next->preferences[1].db_candidate_index = 2;
	batch->papers[6].entries->next->preferences[1].prefnum = 3;
	batch->papers[6].entries->next->next = NULL;

	/* Paper 8: Duplicated number */
	batch->papers[7].p.supervisor_tick = false;
	batch->papers[7].entries = malloc(sizeof(struct entry)
					  + sizeof(struct preference)*3);
	batch->papers[7].entries->e.paper_version_num = 1;
	batch->papers[7].entries->e.num_preferences = 3;
	batch->papers[7].entries->preferences[0].group_index = 1;
	batch->papers[7].entries->preferences[0].db_candidate_index = 1;
	batch->papers[7].entries->preferences[0].prefnum = 1;
	batch->papers[7].entries->preferences[1].group_index = 1;
	batch->papers[7].entries->preferences[1].db_candidate_index = 2;
	batch->papers[7].entries->preferences[1].prefnum = 2;
	batch->papers[7].entries->preferences[2].group_index = 1;
	batch->papers[7].entries->preferences[2].db_candidate_index = 3;
	batch->papers[7].entries->preferences[2].prefnum = 2;
	batch->papers[7].entries->next = malloc(sizeof(struct entry)
					       + sizeof(struct preference)*3);
	batch->papers[7].entries->next->e.paper_version_num = 1;
	batch->papers[7].entries->next->e.num_preferences = 3;
	batch->papers[7].entries->next->preferences[0].group_index = 1;
	batch->papers[7].entries->next->preferences[0].db_candidate_index = 1;
	batch->papers[7].entries->next->preferences[0].prefnum = 1;
	batch->papers[7].entries->next->preferences[1].group_index = 1;
	batch->papers[7].entries->next->preferences[1].db_candidate_index = 2;
	batch->papers[7].entries->next->preferences[1].prefnum = 2;
	batch->papers[7].entries->next->preferences[2].group_index = 1;
	batch->papers[7].entries->next->preferences[2].db_candidate_index = 3;
	batch->papers[7].entries->next->preferences[2].prefnum = 2;
	batch->papers[7].entries->next->next = NULL;

	/* Paper 9: Corrected */
	batch->papers[8].p.supervisor_tick = false;
	batch->papers[8].entries = malloc(sizeof(struct entry)
					  + sizeof(struct preference));
	batch->papers[8].entries->e.paper_version_num = 1;
	batch->papers[8].entries->e.num_preferences = 1;
	batch->papers[8].entries->preferences[0].group_index = 1;
	batch->papers[8].entries->preferences[0].db_candidate_index = 1;
	batch->papers[8].entries->preferences[0].prefnum = 1;
	batch->papers[8].entries->next = malloc(sizeof(struct entry)
					       + sizeof(struct preference));
	batch->papers[8].entries->next->e.paper_version_num = 1;
	batch->papers[8].entries->next->e.num_preferences = 1;
	batch->papers[8].entries->next->preferences[0].group_index = 1;
	batch->papers[8].entries->next->preferences[0].db_candidate_index = 2;
	batch->papers[8].entries->next->preferences[0].prefnum = 1;
	batch->papers[8].entries->next->next = malloc(sizeof(struct entry)
						     + sizeof(struct preference));
	batch->papers[8].entries->next->next->e.paper_version_num = 1;
	batch->papers[8].entries->next->next->e.num_preferences = 1;
	batch->papers[8].entries->next->next->preferences[0].group_index = 1;
	batch->papers[8].entries->next->next->preferences[0].db_candidate_index = 2;
	batch->papers[8].entries->next->next->preferences[0].prefnum = 1;
	batch->papers[8].entries->next->next->next = NULL;

	/* Paper 10: Correct */
	batch->papers[9].p.supervisor_tick = false;
	batch->papers[9].entries = malloc(sizeof(struct entry)
					  + sizeof(struct preference));
	batch->papers[9].entries->e.paper_version_num = 1;
	batch->papers[9].entries->e.num_preferences = 1;
	batch->papers[9].entries->preferences[0].group_index = 1;
	batch->papers[9].entries->preferences[0].db_candidate_index = 1;
	batch->papers[9].entries->preferences[0].prefnum = 1;
	batch->papers[9].entries->next = malloc(sizeof(struct entry)
					       + sizeof(struct preference));
	batch->papers[9].entries->next->e.paper_version_num = 1;
	batch->papers[9].entries->next->e.num_preferences = 1;
	batch->papers[9].entries->next->preferences[0].group_index = 1;
	batch->papers[9].entries->next->preferences[0].db_candidate_index = 1;
	batch->papers[9].entries->next->preferences[0].prefnum = 1;
	batch->papers[9].entries->next->next = NULL;

	/* Paper 11: Unentered */
	batch->papers[10].p.supervisor_tick = false;
	batch->papers[10].entries = malloc(sizeof(struct entry)
					  + sizeof(struct preference));
	batch->papers[10].entries->e.paper_version_num = 1;
	batch->papers[10].entries->e.num_preferences = 1;
	batch->papers[10].entries->preferences[0].group_index = 1;
	batch->papers[10].entries->preferences[0].db_candidate_index = 1;
	batch->papers[10].entries->preferences[0].prefnum = 1;
	batch->papers[10].entries->next = NULL;

	/* Paper 12: Ignored */
	batch->papers[11].p.supervisor_tick = false;
	batch->papers[11].entries = malloc(sizeof(struct entry)
					  + sizeof(struct preference));
	batch->papers[11].entries->e.paper_version_num = 1;
	batch->papers[11].entries->e.num_preferences = 1;
	batch->papers[11].entries->preferences[0].group_index = 1;
	batch->papers[11].entries->preferences[0].db_candidate_index = 1;
	batch->papers[11].entries->preferences[0].prefnum = 1;
	batch->papers[11].entries->next = NULL;

	bwe = find_errors_in_batch(batch);

	if (bwe->b.batch_number != batch->b.batch_number) exit(1);
	if (bwe->b.batch_size != batch->b.batch_size) exit(1);
	if (bwe->b.num_papers != batch->b.num_papers) exit(1);
	if (bwe->b.committed != batch->b.committed) exit(1);

	if (bwe->papers[0].error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[1].error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[2].error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[3].error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[4].error_code != ENTRY_ERR_INFORMAL) exit(1);
	if (bwe->papers[5].error_code != ENTRY_ERR_INFORMAL) exit(1);
	if (bwe->papers[6].error_code != ENTRY_ERR_MISSING_NUM) exit(1);
	if (bwe->papers[7].error_code != ENTRY_ERR_DUPLICATED_NUM) exit(1);
	if (bwe->papers[8].error_code != ENTRY_ERR_CORRECTED) exit(1);
	if (bwe->papers[9].error_code != ENTRY_ERR_CORRECT) exit(1);
	if (bwe->papers[10].error_code != ENTRY_ERR_UNENTERED) exit(1);
	if (bwe->papers[11].error_code != ENTRY_ERR_IGNORED) exit(1);

	if (bwe->papers[0].entries->error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[0].entries->next->error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[1].entries->error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[1].entries->next->error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[2].entries->error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[2].entries->next->error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[3].entries->error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[3].entries->next->error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[4].entries->error_code != ENTRY_ERR_INFORMAL) exit(1);
	if (bwe->papers[4].entries->next->error_code != ENTRY_ERR_INFORMAL) exit(1);
	if (bwe->papers[5].entries->error_code != ENTRY_ERR_INFORMAL) exit(1);
	if (bwe->papers[5].entries->next->error_code != ENTRY_ERR_INFORMAL) exit(1);
	if (bwe->papers[6].entries->error_code != ENTRY_ERR_MISSING_NUM) exit(1);
	if (bwe->papers[6].entries->next->error_code != ENTRY_ERR_MISSING_NUM) exit(1);
	if (bwe->papers[7].entries->error_code != ENTRY_ERR_DUPLICATED_NUM) exit(1);
	if (bwe->papers[7].entries->next->error_code != ENTRY_ERR_DUPLICATED_NUM) exit(1);
	if (bwe->papers[8].entries->error_code != ENTRY_ERR_KEYSTROKE) exit(1);
	if (bwe->papers[8].entries->next->error_code != ENTRY_ERR_CORRECTED) exit(1);
	if (bwe->papers[8].entries->next->next->error_code != ENTRY_ERR_CORRECTED) exit(1);
	if (bwe->papers[9].entries->error_code != ENTRY_ERR_CORRECT) exit(1);
	if (bwe->papers[9].entries->next->error_code != ENTRY_ERR_CORRECT) exit(1);
	if (bwe->papers[10].entries->error_code != ENTRY_ERR_UNENTERED) exit(1);
	if (bwe->papers[11].entries->error_code != ENTRY_ERR_IGNORED) exit(1);

	free_batch_with_error(bwe);
	exit(0);
}
