/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "authenticate.c"

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

static struct http_vars vars[] =
{ { (char *)"error", (char *)"0" },
  { (char *)"num_groups", (char *)"7" },
  { (char *)"group0", (char *)"1" },
  { (char *)"group1", (char *)"2" },
  { (char *)"group2", (char *)"3" },
  { (char *)"group3", (char *)"4" },
  { (char *)"group4", (char *)"5" },
  { (char *)"group5", (char *)"6" },
  { (char *)"group6", (char *)"7" },
  { (char *)"electorate_name", (char *)"Molonglo" },
  { (char *)"electorate_code", (char *)"0" },
  { (char *)"electorate_seats", (char *)"7" },
  { NULL, NULL } 
};

#define BARCODE "aaaaaaaaaaaaaaaaaaaaaa"

/* stub */
const char *http_string(const struct http_vars *hvars, const char *name)
{
	unsigned int i;

	for (i=0; hvars && hvars[i].name; i++)
		if (strcmp(name, hvars[i].name) == 0) return hvars[i].value;

	/* Not found. */
	return NULL;
}

struct ballot_contents *get_ballot_contents(void)
{
	return NULL;
}

void set_ballot_contents(struct ballot_contents *bc)
{
	if (bc->num_groups != 7) exit(1);
	if (bc->num_candidates[0] != 1) exit(1);
	if (bc->num_candidates[1] != 2) exit(1);
	if (bc->num_candidates[2] != 3) exit(1);
	if (bc->num_candidates[3] != 4) exit(1);
	if (bc->num_candidates[4] != 5) exit(1);
	if (bc->num_candidates[5] != 6) exit(1);
	if (bc->num_candidates[6] != 7) exit(1);
}

struct http_vars *http_exchange(const char *servername,
				uint16_t portnum,
				const char *scripturl,
				const struct http_vars *request_params)
{
	if (strcmp(http_string(request_params, "barcode"),
		   BARCODE) != 0) exit(1);
	return vars;
}

enum error http_error(const struct http_vars *hvars)
{
	const char *s = http_string(hvars, "error");

	if (!s) return ERR_SERVER_UNREACHABLE;
	return (enum error)atoi(s);
}

uint16_t get_port(void)
{
	return SERVER_PORT;
}

const char *get_server(void)
{
	return SERVER_ADDRESS;
}

void http_free(struct http_vars *hvars)
{
	if (hvars != vars) exit(1);
}

int main()
{
	struct barcode bc = { {0}, 0, BARCODE };
	struct electorate *elec;

	if (unpack_ballot_contents(vars) != ERR_OK) exit(1);

	/* TEST DDS3.2.4: Authenticate */
	if (authenticate(&bc, &elec) != ERR_OK) exit(1);

	if (elec->code != 0) exit(1);
	if (elec->num_seats != 7) exit(1);
	exit(0);
}
