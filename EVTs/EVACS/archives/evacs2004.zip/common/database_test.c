/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <common/evacs.h>
#include <common/database.h>
#include <common/safe.h>
#include <common/createtables.h>
#include <common/batch.h>

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

int main()
{

	/* TEST DDS3.2: Get Polling Places */
	{
		PGconn *conn;
		
		conn = clean_database("test");

		/* SQL command tests */

		/* Create a test table - should have processed one row */
		if (SQL_command(conn,"CREATE TABLE test ("
					   "id SERIAL, data TEXT);") == 1)
			exit(17);

		/* Drop table should return zero rows affected */
		if (SQL_command(conn,"DROP TABLE test;") != 0)
			exit(18);
		
		/* Drop sequence should return rows affected */
		if (SQL_command(conn,"DROP SEQUENCE test_id_seq;") != 0)
			exit(19);
		
		/* Recreate the table and play with it some more */
		create_sequence(conn,"test_id_seq");
		create_table(conn,"test","id INTEGER NOT NULL PRIMARY KEY "
			     "DEFAULT NEXTVAL('test_id_seq'),"
			     "data TEXT");

		/* Do a bunch of inserts */
		if (SQL_command(conn,"INSERT INTO test(data)"
				"VALUES('Blah');") != 1)
			exit(10);
		if (SQL_command(conn,"INSERT INTO test(data) "
				"VALUES('Blah');") != 1)
			exit(11);
		if (SQL_command(conn,"INSERT INTO test(data) "
				"VALUES('Blah');") != 1)
			exit(12);

		/* Check for sane sequence values */
		if (get_seq_currval(conn,"test_id_seq") != 3)
			exit(13);

		if (get_seq_nextval(conn,"test_id_seq") != 4)
			exit(14);
		/* Test update */
		if (SQL_command(conn,"UPDATE test "
				"SET data = 'Stuff' "
				"WHERE data = 'Blah';") != 3)
			exit(15);

		/* Test delete */
		if (SQL_command(conn,"DELETE FROM test;") != 3)
			exit(16);

		create_electorate_table(conn);
		create_polling_place_table(conn);

		/* Create bogus entries */
		SQL_command(conn,
			       "INSERT INTO polling_place"
			       " VALUES ( 0, 'Place1',false );");
		SQL_command(conn,
			       "INSERT INTO polling_place"
			       " VALUES ( 1, 'Place2',false );");

		if (SQL_singleton_int(conn,"SELECT code FROM polling_place "
				  "WHERE name = 'Place1';") != 0)
			exit (1);

		if (SQL_singleton_int(conn,"SELECT code FROM polling_place "
				  "WHERE name = 'Place2';") != 1)
			exit (1);
		
		PQfinish(conn);
	}

	/* TEST DDS3.2: Get Electorates */
	{
		struct electorate *elec;
		PGconn *conn;

		/* Open database connection, to create test db. */
		conn = connect_db("test");
		create_electorate_table(conn);

		/* Create bogus entries */
		SQL_command(conn,
			       "INSERT INTO electorate"
			       " VALUES ( 0, 'Electorate1', 5 );");
		SQL_command(conn,
			       "INSERT INTO electorate"
			       " VALUES ( 1, 'Electorate2', 7 );");

		elec = get_electorates(conn);
		if (!elec || !elec->next || elec->next->next != NULL) exit(1);
		if (elec->code != 1 || elec->next->code != 0) exit(1);
		if (elec->num_seats != 7 || elec->next->num_seats != 5)
			exit(1);
		if (strcmp(elec->name, "Electorate2") != 0
		    || strcmp(elec->next->name, "Electorate1") != 0)
			exit(1);
		free_electorates(elec);
		PQfinish(conn);
	}
	/* Test  DDSv2B 3.6:Get Electorate Prefs 
	   Test  DDSv2B 3.4:Resolve Batch Source 
	 */
	{
		char *elec1,*elec2;
	        PGconn *conn;
/*
		PGresult result;
		char *name;
*/
		const char *e1name = "Electorate1";
		const char *e2name = "Electorate2";

	        conn = connect_db("test");
		if (conn == NULL) exit(1);
		
		/* create dependency tables */
		create_ballot_content_tables(conn);

		/* create batch table */
		create_batch_table(conn);

		/* Create bogus entries in electorate table*/
		SQL_command(conn,
			       "INSERT INTO electorate"
			       " VALUES ( 0, 'Electorate1', 5 );");
		SQL_command(conn,
			       "INSERT INTO electorate"
			       " VALUES ( 1, 'Electorate2', 7 );");

		SQL_command(conn,
			       "INSERT INTO batch"
			       " VALUES ( 1, 0, 0 );");

		SQL_command(conn,
			       "INSERT INTO batch"
			       " VALUES ( 2, 0, 0 );");
		
		SQL_command(conn,
			       "INSERT INTO batch"
			       " VALUES ( 3, 0, 1 );");		


		/* create paper and entry tables */
		create_paper_table(conn);
		create_entry_table(conn);
	       
		/* create electorate tables */
		create_electorate_preference_tables(conn);

		/* add some preferences to each electorate table */
		elec1 = resolve_electorate_name(conn,0);
		elec2 = resolve_electorate_name(conn,1);

		if (strcmp(elec1, e1name) + strcmp(elec2, e2name)!=0) exit(1);
#if 0		
		for (i=0;i<3;i++) {
			pref = malloc(sizeof(*pref));
			pref->batch_number = 1;
			pref->paper_index = 1;
			pref->entry_index = 1;
			pref->operator_id = 0;
			pref->paper_version = 1;
			pref->electorate_code = 0;
			pref->party_index = 0;
			pref->candidate_index = i;
			pref->preference = i+1;
			pref->next = top;
			top = pref;
		}
		/*
		  SQL_command(conn,
		  "INSERT INTO paper(batch_number,"
		  "index,paper_version,"
		  "supervisor_tick) VALUES(1,%u,0,'f');",i);
		  SQL_command(conn,"INSERT INTO entry"
		  "(paper_id,index,operator_id)"
		  "VALUES(currval('paper_id_seq'),1,0);");
		*/
	}

	/* Insert a party for electorate 0 */
	SQL_command(conn,"INSERT INTO party VALUES(0,0,'ZeroParty');");
		/* And 3 candidates */
		for (i=0;i<3;i++)
		        SQL_command(conn,
				    "INSERT INTO candidate VALUES"
				    "(0,0,%u,'Candidate%u');",i,i);
		
		/* Add entries using append_entry */
		append_entry(conn,top,0,1,1,0);
		
		/*
		  
		  SQL_command(conn,
		  "INSERT INTO %s "
		  "VALUES (currval('entry_id_seq'),0,0,0,1);",elec1);
		  
		  SQL_command(conn,
		  "INSERT INTO %s "
		  "VALUES (currval('entry_id_seq'),0,0,1,2);",elec1);
		  
		  SQL_command(conn,
		  "INSERT INTO %s "
		  "VALUES (currval('entry_id_seq'),0,0,2,3);",elec1);
		*/
		printf("resolve_batch_source 1\n");
		btch = resolve_batch_source(conn,1);
		if (btch->electorate_code != 0) exit (9);
		
		printf("resolve_batch_source 3\n");
		btch = resolve_batch_source(conn,3);
		if (btch->electorate_code != 1) exit (2);
		
		printf("get_electorate_prefs\n");
		pref = get_electorate_prefs(conn,0);
                if (pref->next->next->next != NULL) exit(3);
      		free_prefs(pref);
		
		printf("get_batch_prefs\n");
		pref = get_batch_prefs(conn,1);
		if (pref->next->next->next != NULL) exit(4); 
		free_prefs(pref);
		
		/* clean up electorate tables */
		result = SQL_query(conn,"SELECT name from electorate"); 
		
		for (i=0;i<PQntuples(result);i++) {
			strcpy(name, PQgetvalue(result,i,0));
			/* drop table */
			drop_table(conn,name);
			
		}
		
		
		drop_table(conn, "entry");
		drop_table(conn, "paper");
		drop_table(conn, "electorate");
		drop_table(conn, "party");
		drop_table(conn, "candidate");
		drop_table(conn, "batch");
#endif
		PQfinish(conn);
	}


	exit(0);
}




