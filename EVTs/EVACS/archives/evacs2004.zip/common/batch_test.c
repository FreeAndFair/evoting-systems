/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

/* This file contains implementation of batch functionality*/
#include <string.h>
#include <stdlib.h>
#include <common/database.h>
#include <common/createtables.h>
#include <common/safe.h>
#include "batch.h"

int main(int argc,char *argv[])
{
	PGconn *conn;
	struct entry *entry;
	struct batch *batch;
	int i;

	conn = clean_database("batch_test");

	create_electorate_table(conn);	
	create_polling_place_table(conn);
	create_batch_table(conn);
	create_paper_tables(conn);
	create_entry_tables(conn);

	SQL_command(conn,"INSERT INTO electorate VALUES (0,'Electorate1',5);");
	create_electorate_preference_tables(conn);

	SQL_command(conn,"INSERT INTO polling_place VALUES(0,'PollingPlace1',"
		    "false);");

	SQL_command(conn,"INSERT INTO batch VALUES(0,0,0,50,0,false);");

	entry = malloc(sizeof(*entry) + sizeof(entry->preferences[0])*5);

	strcpy(entry->e.operator_id,"Steve");

	/* Append one entry */
	entry->e.num_preferences = 1;

	entry->preferences[0].group_index = 0;
	entry->preferences[0].db_candidate_index = 0;
	entry->preferences[0].prefnum = 1;

	append_entry(conn,entry,0,1,123);	

	/* And one other */
	entry->e.num_preferences = 5;

	for (i=0;i<5;i++) {
		entry->preferences[i].group_index = 0;
		entry->preferences[i].db_candidate_index = i;
		entry->preferences[i].prefnum = i;
	}

	append_entry(conn,entry,0,1,123);


/* TEST DDS3.6: Get Entered Papers 
    from v2B */

	batch = get_entered_batch(conn, 0);

	if (batch->b.batch_number != 0 ) {
		printf("batch number %u\n",batch->b.batch_number);
		exit (1);
	}
	if (batch->b.num_papers != 1) {
		printf("num papers is %u\n",batch->b.num_papers);
		exit(1);
	}
	if (batch->b.batch_size != 50) {
		printf("batch size is %u\n",batch->b.batch_size);
		exit(1);
	}
	if (batch->papers[0].p.supervisor_tick) {
		printf("supervisor tick is true\n");
		exit(1);
	}

	if (batch->papers[0].entries->e.num_preferences != 5) {
		printf("num prefs is %u\n",batch->papers[0].entries->e.num_preferences);
		exit(1);
	}
	if (strcmp(batch->papers[0].entries->e.operator_id,"Steve")) {
		printf("operator id is %s\n",batch->papers[0].entries->e.operator_id);
		exit(1);
	}
	if (batch->papers[0].entries->e.paper_version_num != 123) {
		printf("paper version is %u\n",batch->papers[0].entries->e.paper_version_num);
		exit(1);
	}
	for (i=0;i<5;i++) {
		if (batch->papers[0].entries->preferences[i].prefnum != i) {
			printf("preference[%d] prefnum is %u\n",i,
			       batch->papers[0].entries->preferences[i].prefnum);
			exit(1);
		}
		if (batch->papers[0].entries->preferences[i].db_candidate_index != i) {
			printf("preference[%d] candidate index is %u\n",i,
			       batch->papers[0].entries->preferences[i].db_candidate_index);
			exit(1);
		}
		if (batch->papers[0].entries->preferences[i].group_index != 0){
			printf("preference[%d] group index is %u\n",i,
			       batch->papers[0].entries->preferences[i].group_index);
			exit(1);
		}
	}

	if(batch->papers[0].entries->next == NULL) {
		printf("Less than two entrys in the batch!\n");
		exit(1);
	}

	if(batch->papers[0].entries->next->next != NULL) {
		printf("More than two entrys in the batch!\n");
		exit(1);
	}
	exit(0);
}
