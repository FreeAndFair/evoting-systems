# This file contains definitions and utilities for loading
# CDROMs

# cdrom.sh exports:
#           $CDROM_DEVICE
#           $CDROM_DIRECTORY
#           $CDROM_SCSI_DEVICE
#           $CDROM_RECORD_OPTIONS
#           load_blank_cdrom()
#           load_evacs_cdrom()

# source the console library unless it has already been loaded
if [ -z $CONSOLE ]; then
   # set SCRIPTROOT if not already set
    if [ -z $SCRIPTROOT ]; then
	SCRIPTROOT=/opt/eVACS/bin
    fi
    source "$SCRIPTROOT/console.sh" && CONSOLE='loaded'
fi

CDROM_DEVICE=/dev/cdrom
CDROM_SCSI_DEVICE=`cdrecord -scanbus 2>&1 | egrep "[0-9\,]{5}\s*[0-9)]*" | fgrep -v '*' | cut -b2-6`
CDROM_DIRECTORY=/mnt/cdrom
CDROM_RECORD_OPTIONS=" -eject gracetime=0 "
MOUNT_OPTIONS=""

# make mount point if necessary
[ -d $CDROM_DIRECTORY ] || mkdir $CDROM_DIRECTORY || \
    bailout "Can't create directory $CDROM_DIRECTORY" 

# return when there is a blank CDROM in the drive
load_blank_cdrom()
{
msg="$@"
# If user has already loaded the blank disk, mount will fail with the message:
# "mount: you must specify the filesystem type"
# CAVEAT - entering a non data disk will also generate this error
# so an audio disk will pass this test but fail at cdrecord
mounted=`mount $MOUNT_OPTIONS $CDROM_DEVICE $CDROM_DIRECTORY 2>&1 | grep "filesystem type"`
# if mount command succeeded, disk is not blank
success=`mount | grep $CDROM_DEVICE`
if [ -n "$success" ]; then
    warn "Currently loaded disk is not blank"
    umount $CDROM_DEVICE 2>&1 > /dev/null
fi
while [ -z "$mounted"  ]; do
    eject $CDROM_DEVICE
    instruct "$msg"
    read -s
    # replace highlighted instruction with default colours
    delete_instruction
    announce "CD loading                                                   "
    mounted=`mount $MOUNT_OPTIONS $CDROM_DEVICE $CDROM_DIRECTORY 2>&1 | grep "filesystem type"`    
    # if mount command succeeded, disk is not blank
    success=`mount | grep $CDROM_DEVICE`
    if [ -n "$success" ]; then
	warn "Currently loaded disk is not blank"
	umount $CDROM_DEVICE 2>&1 > /dev/null
    fi
done

}

# return when a CD is loaded that satisfies current $MOUNT_OPTIONS 
load_evacs_cdrom()
{
    msg="$@"
    mounted=`mount $MOUNT_OPTIONS $CDROM_DEVICE $CDROM_DIRECTORY 2>&1`
    success=`mount | grep $CDROM_DEVICE`
    # give the user some feedback if mount failed
#    echo $mounted | grep "wrong fs type" && warn "Loaded CD does not appear to be an evacs disk."
#    echo $mounted | grep "No medium found" && warn "CD not detected. "
	error=`echo $mounted | grep "wrong fs type"` && warn "Loaded CD does not appear to be an evacs disk."
	error=`echo $mounted | grep "No medium found"` && warn "CD not detected. "
    
    while  [ -z "$success" ]; do
	eject $CDROM_DEVICE
	instruct "$msg"
	read -s
	# replace highlighted instruction with default colours
	delete_instruction
	announce "CD loading                                                      "
        # attempt to mount cd
	mounted=`mount $MOUNT_OPTIONS $CDROM_DEVICE $CDROM_DIRECTORY 2>&1`
	success=`mount | grep $CDROM_DEVICE`

	# give the user some feedback if mount failed
	error=`echo $mounted | grep "wrong fs type"` && warn "Loaded CD does not appear to be an evacs disk."
#	echo $mounted | grep "wrong fs type" >  && warn "Loaded CD does not appear to be an evacs disk."
	error=`echo $mounted | grep "No medium found"` && warn "CD not detected. "
    done
}
