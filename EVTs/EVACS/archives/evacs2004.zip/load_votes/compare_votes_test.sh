#! /bin/sh

# DDSv1D-3.2: Test compare votes
# 
# Note: this script drops the evacs db (plus others)

#drop databases
su - postgres -c "psql template1 2>&1 > /dev/null <<%
	DROP DATABASE evacs;
	DROP DATABASE evacs1;
	DROP DATABASE evacs2;
	DROP DATABASE evacs_load_test;
%" 2>&1 >/dev/null
    	if [ $? != 0 ]; then
		echo Failed to drop/create database
		exit 1
    	fi


# load a test backup db
OLD_DIR="`pwd`"
su - postgres -c "psql template1 <$OLD_DIR/load_votes/evacs_load_test.dmp"
su - postgres -c "psql template1 <$OLD_DIR/load_votes/cv_tables_load_test.dmp"

# When the tables are the same, check votes is ok
su - postgres -c "createdb -T evacs_load_test evacs1"
su - postgres -c "createdb -T evacs_load_test evacs2"
su - postgres -c "$PWD/load_votes/check_votes_bin" || exit 1


#Remove the 49th pref candidate
su - postgres -c "psql evacs2 >/dev/null<<EOF
update molonglo_confirmed_vote set preference_list = '010000020001030100040101050102060103070104080105090106100200110201120202130203140204150205160206170300180301190302200303210304220305230306240400250401260402270500280501290600300601310700320701330702340703350704360705370706380800390801400900410901421000431100441101451102461103471104481105' where id =1;
EOF" 2>&1 > /dev/null

su - postgres -c "$PWD/load_votes/check_votes_bin" && exit 1
su - postgres -c "psql template1 2>&1 > /dev/null <<%
	DROP DATABASE evacs2;
%" 2>&1 >/dev/null

#Change batch number
su - postgres -c "createdb -T evacs_load_test evacs2"
su - postgres -c "psql evacs2 >/dev/null<<EOF
update molonglo_confirmed_vote set batch_number  = 2001000 where id =1;
EOF" 2>&1 > /dev/null

su - postgres -c "$PWD/load_votes/check_votes_bin" && exit 1
su - postgres -c "psql template1 2>&1 > /dev/null <<%
	DROP DATABASE evacs2;
%" 2>&1 >/dev/null

#Change paper version number
su - postgres -c "createdb -T evacs_load_test evacs2"
su - postgres -c "psql evacs2 >/dev/null<<EOF
update molonglo_confirmed_vote set  paper_version  = 2 where id =1;
EOF" 2>&1 > /dev/null

su - postgres -c "$PWD/load_votes/check_votes_bin" && exit 1
su - postgres -c "psql template1 2>&1 > /dev/null <<%
	DROP DATABASE evacs2;
%" 2>&1 >/dev/null

#Add a vote
su - postgres -c "createdb -T evacs_load_test evacs2"
su - postgres -c "psql evacs2 >/dev/null<<EOF
insert into brindabella_confirmed_vote values (200100,1,'');
EOF" 2>&1 > /dev/null

su - postgres -c "$PWD/load_votes/check_votes_bin" && exit 1
su - postgres -c "psql template1 2>&1 > /dev/null <<%
	DROP DATABASE evacs2;
%" 2>&1 >/dev/null

#remove an informala vote
su - postgres -c "createdb -T evacs_load_test evacs2"
su - postgres -c "psql evacs2 >/dev/null<<EOF
DELETE FROM ginninderra_confirmed_vote where id=1;
EOF" 2>&1 > /dev/null

su - postgres -c "$PWD/load_votes/check_votes_bin" && exit 1
su - postgres -c "psql template1 2>&1 > /dev/null <<%
	DROP DATABASE evacs2;
%" 2>&1 >/dev/null
echo
echo compare_votes_test PASSED
exit 0
