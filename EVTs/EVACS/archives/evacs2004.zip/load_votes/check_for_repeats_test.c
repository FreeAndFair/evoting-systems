/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "check_for_repeats.c"

int main()
{
	/* TEST DDS999998 */
	PGconn *conn;
	
	conn = connect_db("template1");
	SQL_command_nobail(conn,"drop database %s;",LOAD1DB_NAME);
	SQL_command(conn,"create database %s;",LOAD1DB_NAME);
	SQL_command_nobail(conn,"drop database %s;",DATABASE_NAME);
	SQL_command_nobail(conn,"create database %s;",DATABASE_NAME);

	PQfinish(conn);

	conn = connect_db(LOAD1DB_NAME);

	/* Setup dummy polling place master database with one row */
	create_table(conn,"confirmed_vote",
		     "id INTEGER NOT NULL PRIMARY KEY,"
		     "electorate_code INTEGER NOT NULL,"
		     "polling_place_code INTEGER NOT NULL");
	SQL_command(conn, "INSERT into confirmed_vote"
		    "(id,electorate_code,"
		    "polling_place_code) "
		    "values (1,0,0);");
	PQfinish(conn);

	/* Setup dummy counting server */
	conn = connect_db(DATABASE_NAME);
	create_table(conn,"polling_place",
		     "code INTEGER NOT NULL PRIMARY KEY,"
		     "name TEXT NOT NULL,"
		     "loaded BOOL DEFAULT false");
	SQL_command(conn,"INSERT INTO polling_place VALUES "
		    "(0,'Test polling place',false);");
	PQfinish(conn);

	/* Should NOT be a repeat */
	if (check_for_repeats())
		exit(1);

	/* Add in this polling place */
	conn = connect_db(DATABASE_NAME);
	SQL_command(conn,"UPDATE polling_place "
		    "SET loaded = true "
		    "WHERE code = 0;");
	PQfinish(conn);

	/* Now it should be a repeat */
	if (!check_for_repeats())
		exit(2);
	
	exit(0);
}
