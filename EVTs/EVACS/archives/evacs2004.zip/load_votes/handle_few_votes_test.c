/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "handle_few_votes.c"
#include <common/createtables.h>
int main()
{
	/* TEST DDS999998 */
	PGconn *conn;
 	int num_votes,i;

#define LOAD1DB_NAME "evacs1"

	conn = connect_db("template1");
	drop_database(conn,LOAD1DB_NAME);
	create_database(conn,LOAD1DB_NAME); 
	drop_database(conn,DATABASE_NAME);
	create_database(conn,DATABASE_NAME);

	PQfinish(conn);

	conn = connect_db(LOAD1DB_NAME);

	/* Create the tables the same way they are in real life */

	create_electorate_table(conn);
	SQL_command(conn,"INSERT INTO electorate VALUES(1,'Electorate1',5);");
	SQL_command(conn,"INSERT INTO electorate VALUES(2,'Electorate2',5);");
	SQL_command(conn,"INSERT INTO electorate VALUES(3,'Electorate3',7);");


	create_polling_place_table(conn);

	SQL_command(conn,"INSERT INTO polling_place VALUES("
			   "1,'Polling place one',false,1);");
	SQL_command(conn,"INSERT INTO polling_place VALUES("
		    "400,'Central Scrutiny',false);");

	create_batch_table(conn);
	SQL_command(conn, "INSERT into batch"
			    "(number,electorate_code,polling_place_code) "
			    "values (1001000,1,1);");
	SQL_command(conn, "INSERT into batch"
			    "(number,electorate_code,polling_place_code) "
			    "values (2001000,2,1);");
	SQL_command(conn, "INSERT into batch"
			    "(number,electorate_code,polling_place_code) "
			    "values (3001000,3,1);");
	SQL_command(conn, "INSERT into batch"
			    "(number,electorate_code,polling_place_code) "
			    "values (1400000,1,400);");
	SQL_command(conn, "INSERT into batch"
			    "(number,electorate_code,polling_place_code) "
			    "values (2400000,2,400);");
	SQL_command(conn, "INSERT into batch"
			    "(number,electorate_code,polling_place_code) "
			    "values (3400000,3,400);");


	create_confirmed_vote_tables(conn);

	create_server_parameter_table(conn);
SQL_command(conn, "INSERT into server_parameter "
			    "values (1,1);");
	
	for(i=0;i<10;i++) {
	/* Insert 10 votes for electorate 1 */
		SQL_command(conn, "INSERT into electorate1_confirmed_vote"
			    "(batch_number,paper_version,time_stamp, preference_list) "
			    "values (1001000,1,' 2002/06/03 16:04:44','010000');");

	/* Insert 10 votes for electorate 3 */
		SQL_command(conn, "INSERT into electorate3_confirmed_vote"
			    "(batch_number,paper_version,time_stamp, preference_list) "
			    "values (3001000,1,' 2002/06/03 16:04:44','010000');");
	}
	for(i=0;i<9;i++) {
	/* Insert 9 informal votes for electorate 1 */
		SQL_command(conn, "INSERT into electorate1_confirmed_vote"
			    "(batch_number,paper_version,time_stamp, preference_list) "
			    "values (1001000,1,' 2002/06/03 16:04:44','');");

	/* Insert 9 informal votes for electorate 3 */
		SQL_command(conn, "INSERT into electorate3_confirmed_vote"
			    "(batch_number,paper_version,time_stamp, preference_list) "
			    "values (3001000,1,' 2002/06/03 16:04:44','');");
	}
	/* Insert 21 votes for electorate 2 */
	for(i=0;i<21;i++) {
		SQL_command(conn, "INSERT into electorate2_confirmed_vote"
			    "(batch_number,paper_version,time_stamp, preference_list) "
			    "values (2001000,1,' 2002/06/03 16:04:44','010001');");

	}	
	PQfinish(conn);

	conn = connect_db(DATABASE_NAME);

	/* Create the tables the same way they are in real life */

	create_electorate_table(conn);
	SQL_command(conn,"INSERT INTO electorate VALUES(1,'Electorate1',5);");
	SQL_command(conn,"INSERT INTO electorate VALUES(2,'Electorate2',7);");
	SQL_command(conn,"INSERT INTO electorate VALUES(3,'Electorate3',7);");


	create_polling_place_table(conn);

	SQL_command(conn,"INSERT INTO polling_place VALUES("
			   "1,'Polling place one',false,1);");
	SQL_command(conn,"INSERT INTO polling_place VALUES("
		    "400,'Central Scrutiny',false);");

	create_batch_table(conn);
	SQL_command(conn, "INSERT into batch"
			    "(number,electorate_code,polling_place_code) "
			    "values (1001000,1,1);");
	SQL_command(conn, "INSERT into batch"
			    "(number,electorate_code,polling_place_code) "
			    "values (2001000,2,1);");
	SQL_command(conn, "INSERT into batch"
			    "(number,electorate_code,polling_place_code) "
			    "values (1400000,1,400);");
	SQL_command(conn, "INSERT into batch"
			    "(number,electorate_code,polling_place_code) "
			    "values (2400000,2,400);");

	SQL_command(conn, "INSERT into batch"
			    "(number,electorate_code,polling_place_code) "
			    "values (3001000,3,1);");
	SQL_command(conn, "INSERT into batch"
			    "(number,electorate_code,polling_place_code) "
			    "values (3400000,3,400);");



	create_confirmed_vote_tables(conn);
	create_party_table(conn);
	SQL_command(conn, "INSERT into party "
			    "values (1,0,'The ACT Greens','GREEN');");
	SQL_command(conn, "INSERT into party "
			    "values (2,0,'The ACT Greens','GREEN');");
	SQL_command(conn, "INSERT into party "
			    "values (3,0,'The ACT Greens','GREEN');");

	create_candidate_table(conn);
	SQL_command(conn, "INSERT into candidate "
			    "values (1,0,0,'Fiona Tito','f');");
	SQL_command(conn, "INSERT into candidate "
			    "values (1,0,1,'Sue Ellerman','f');");
	SQL_command(conn, "INSERT into candidate "
			    "values (2,0,0,'Tito','f');");
	SQL_command(conn, "INSERT into candidate "
			    "values (2,0,1,'Ellerman','f');");
	SQL_command(conn, "INSERT into candidate "
			    "values (3,0,0,'Fiona','f');");
	SQL_command(conn, "INSERT into candidate "
			    "values (3,0,1,'Sue','f');");
	create_vote_summary_table(conn);
	create_preference_summary_table(conn);
	/* Light blue touch paper and stand well clear */
	handle_few_votes();

	/* Check results */

	/* There should be 19 votes with  batch_number = 140000 (CSC) */

	conn = connect_db(DATABASE_NAME);
	num_votes = SQL_singleton_int(conn,"SELECT COUNT(*) "
				      "FROM electorate1_confirmed_vote "
				      "WHERE batch_number = 1400000;");

	if (num_votes != 19)
		exit(1);

	/* There should be 19 votes with  batch_number = 340000 (CSC) */
	num_votes = SQL_singleton_int(conn,"SELECT COUNT(*) "
				      "FROM electorate3_confirmed_vote "
				      "WHERE batch_number = 3400000;");

	if (num_votes != 19)
		exit(2);

	/* There should be 21 votes with batch_number = 2001000 */

	num_votes = SQL_singleton_int(conn,"SELECT COUNT(*) "
				      "FROM electorate2_confirmed_vote "
				      "WHERE batch_number = 2001000;");

	if (num_votes != 21)
		exit(3);
	

	/* Check the polling place has been marked as loaded */
	if (!SQL_singleton_bool(conn,"SELECT loaded FROM polling_place "
				"WHERE code = 1;"))
		exit(4);
	
	/* Check the ENS tables */
	/*vote summary has 3 rows */
	num_votes = SQL_singleton_int(conn,"SELECT COUNT(*) "
				      "FROM   vote_summary;");

	if (num_votes != 3)
		exit(5);
	
	/* preference summary has 3 rows */
	num_votes = SQL_singleton_int(conn,"SELECT COUNT(*) "
				      "FROM   vote_summary;");
	if (num_votes != 3)
		exit(6);

	/* there are 18 informal votes   */
	num_votes = SQL_singleton_int(conn,"SELECT SUM(informal_count) "
				      "FROM   vote_summary;");
	if (num_votes != 18)
		exit(7);

	/* there are 41 formal votes votes   */
	num_votes = SQL_singleton_int(conn,"SELECT SUM(evacs_primary) "
				      "FROM   preference_summary;");
	if (num_votes != 41)
		exit(8);

	/* there are 21 formal votes votes for candidate 1 in electorate 2  */
	num_votes = SQL_singleton_int(conn,"SELECT SUM(evacs_primary) "
				      "FROM   preference_summary "
				      " where candidate_index =1 and electorate_code =2;");
	if (num_votes != 21)
		exit(8);

	PQfinish(conn);

	/*
	  Make sure all there's still the same number of votes
	*/

	conn = connect_db(LOAD1DB_NAME);
	num_votes = SQL_singleton_int(conn,"SELECT COUNT(*) "
				      "FROM electorate1_confirmed_vote;");
	num_votes += SQL_singleton_int(conn,"SELECT COUNT(*) "
				      "FROM electorate2_confirmed_vote;");
	num_votes += SQL_singleton_int(conn,"SELECT COUNT(*) "
				      "FROM electorate3_confirmed_vote;");

	/* There should be 59 of them */
	if (num_votes != 59)
		exit(9);

	PQfinish(conn);
	exit(0);
}
