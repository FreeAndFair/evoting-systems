/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include <stdbool.h>
#include <stdlib.h>
#include <unistd.h>
#include "input.h"
#include "verify_barcode.c"
#include "initiate_session.h"

struct barcode barc, *bc;

/* Stub */
void display_error(enum error err)
{
	abort();
}

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

int main(void)
{
	char electorate_name[9];
	struct electorate *electorate;
	const struct electorate *stored_electorate;
	bc = &barc;
	bc->data[0] = 0;
	bc->checksum = 0;
	bar_encode_ascii(bc);
	
	
	/* TEST DDS3.2.4: Verify Checksum */
	if (verify_checksum(bc)!=true) 
		exit(1);

	/* TEST DDS3.2.4: Store Voter Electorate */
	/* TEST DDS3.2.6: Get Voter Electorate */
	strcpy(electorate_name,"TestElec");
	electorate = malloc(sizeof(struct electorate) 
			    + strlen(electorate_name)+1);
	electorate->code = 1;
	electorate->num_seats = 7;
	strcpy(electorate->name, "TestElec");

	store_electorate(electorate);
	stored_electorate = get_voter_electorate();
	if (electorate->code != stored_electorate->code) exit(1);
	if (electorate->num_seats != stored_electorate->num_seats) exit(1);
	if (strcmp(electorate->name,stored_electorate->name)) exit(1);

	/* TEST DDS3.2.4: Verify Initial Barcode */
	if (verify_init_barcode(bc)!=true) 
	        exit(1);
        
	/* TEST DDS3.2.4: Store Barcode */
	if (bc->checksum != once_swiped->checksum)
                exit(1); 	
        if (strcmp(bc->data,once_swiped->data)) 
	        exit(1);
	if (strcmp(bc->ascii,once_swiped->ascii)) 
	        exit(1);

	exit(0);
}

