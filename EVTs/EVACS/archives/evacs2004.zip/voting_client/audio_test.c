/* This file is (C) copyright 2001 Software Improvements, Pty Ltd. */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "audio.c"
#include <unistd.h>

void display_error(enum error err)
{
	abort();
}

int main(int argc, char *argv[])
{
	audio_init();

	if (argc == 1) {
		play_audio(true, get_audio("undo.raw"));
		play_audio(false, get_audio("undo.raw"));
		play_audio_loop(false, get_audio("unused_key.raw"));
		sleep(20);
		play_audio(true, get_audio("undo.raw"));
		play_pause(false);
		play_audio(false, get_audio("undo.raw"));
	} else if (argc == 2) {
		play_audio(true, get_audio(argv[1]));
	} else if (argc == 4) {
		play_audio_loop(true, get_audio(argv[1]));
		sleep(atoi(argv[2]));
		play_audio(true, get_audio(argv[3]));
	}
	sleep(10);
	audio_shutdown();
	exit(0);
}
