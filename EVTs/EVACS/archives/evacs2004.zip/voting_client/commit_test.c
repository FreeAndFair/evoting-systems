/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "commit.c"

#include "get_rotation.h"
#define BARCODE_ASCII "aaaaaaaaaaaaaaaaaaaaaa"
static struct preference_set prefs;
static struct rotation rot;
static struct http_vars *retvars;

/* Stubs */
const struct rotation *get_current_rotation(void)
{
	return &rot;
}

const char *get_keystrokes(void)
{
	/* With rotation 0, this corresponds to the vote */
	return "DSN" "DDSN" "DDDSN" "DDDDSN" "DDDDDSN";
}

const struct preference_set *get_vote_in_progress(void)
{
	return &prefs;
}

/* Retrieve a string value from an http_vars associative array.
   Returns NULL on failure.  */
const char *http_string(const struct http_vars *hvars, const char *name)
{
	unsigned int i;

	for (i=0; hvars && hvars[i].name; i++)
		if (strcmp(name, hvars[i].name) == 0) return hvars[i].value;

	/* Not found. */
	return NULL;
}

struct http_vars *http_exchange(const char *server, uint16_t port,
				const char *url, const struct http_vars *vars)
{
	if (strcmp(server, SERVER_ADDRESS) != 0) exit(1);
	if (port != SERVER_PORT) exit(1);
	if (strcmp(url, "/cgi-bin/commit_vote") != 0) exit(1);
	if (strcmp(http_string(vars, "barcode"), BARCODE_ASCII) != 0) exit(1);
	if (strcmp(http_string(vars, "keystrokes"), get_keystrokes()) != 0)
		exit(1);
	if (strcmp(http_string(vars, "vote"), "1,1,2,2,3,3,4,4,5,5") != 0)
		exit(1);
	if (strcmp(http_string(vars, "rotation0"), "0") != 0) exit(1);
	if (strcmp(http_string(vars, "rotation1"), "1") != 0) exit(1);
	if (strcmp(http_string(vars, "rotation2"), "2") != 0) exit(1);
	if (strcmp(http_string(vars, "rotation3"), "3") != 0) exit(1);
	if (strcmp(http_string(vars, "rotation4"), "4") != 0) exit(1);
	if (strcmp(http_string(vars, "rotation5"), "5") != 0) exit(1);
	if (strcmp(http_string(vars, "rotation6"), "6") != 0) exit(1);
	if (vars[10].name != NULL) exit(1);
	if (vars[10].value != NULL) exit(1);

	return retvars;
}

enum error http_error(const struct http_vars *hvars)
{
	const char *s = http_string(hvars, "error");

	if (!s) return ERR_SERVER_UNREACHABLE;
	return (enum error)atoi(s);
}

void display_error(enum error err)
{
	if (err != 1) exit(1);
	exit(0);
}

void http_free(struct http_vars *hvars)
{
	unsigned int i; 
	for (i=0; hvars[i].name; i++) {
		free(hvars[i].name);
		free(hvars[i].value);
	}
	free(hvars);
}

int main()
{
	char *votes;
	struct barcode bc;

	/* Straight-forward rotation */
	rot.size = 7;
	rot.rotations[0] = 0;
	rot.rotations[1] = 1;
	rot.rotations[2] = 2;
	rot.rotations[3] = 3;
	rot.rotations[4] = 4;
	rot.rotations[5] = 5;
	rot.rotations[6] = 6;
	rot.rotations[7] = 7;

	/* Test build_vote */
	prefs.num_preferences = 5;
	prefs.candidates[0].group_index = 1;
	prefs.candidates[0].db_candidate_index = 1;
	prefs.candidates[0].prefnum = 1;
	prefs.candidates[1].group_index = 2;
	prefs.candidates[1].db_candidate_index = 2;
	prefs.candidates[1].prefnum = 2;
	prefs.candidates[2].group_index = 3;
	prefs.candidates[2].db_candidate_index = 3;
	prefs.candidates[2].prefnum = 3;
	prefs.candidates[3].group_index = 4;
	prefs.candidates[3].db_candidate_index = 4;
	prefs.candidates[3].prefnum = 4;
	prefs.candidates[4].group_index = 5;
	prefs.candidates[4].db_candidate_index = 5;
	prefs.candidates[4].prefnum = 5;

	votes = build_vote(&prefs);
	if (strcmp(votes, "1,1,2,2,3,3,4,4,5,5") != 0) exit(1);
	free(votes);

	/* TEST DDS3.2.26: Commit Vote */
	strcpy(bc.ascii, BARCODE_ASCII);
	retvars = malloc(sizeof(*retvars)*2);
	retvars[0].name = strdup("error");
	retvars[0].value = strdup("0");
	retvars[1].name = retvars[1].value = NULL;
	commit_vote(&bc);

	/* This should call display_error() */
	retvars = malloc(sizeof(*retvars)*2);
	retvars[0].name = strdup("error");
	retvars[0].value = strdup("1");
	retvars[1].name = retvars[1].value = NULL;
	commit_vote(&bc);
	exit(1);
}
