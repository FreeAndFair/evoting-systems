/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

#include "keystroke.c"

static enum input_event feed_key;

/* Stub */
enum input_event get_keystroke(void)
{
	return feed_key;
}

void display_error(enum error err)
{
	abort();
}

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

int main()
{
	unsigned int i;
	const char *p;

	/* TEST DDS3.2.6: Interpret Keystroke */
	feed_key = INPUT_UP;
	if (interpret_keystroke() != INPUT_UP) exit(1);
	feed_key = INPUT_DOWN;
	if (interpret_keystroke() != INPUT_DOWN) exit(1);
	feed_key = INPUT_NEXT;
	if (interpret_keystroke() != INPUT_NEXT) exit(1);
	feed_key = INPUT_PREVIOUS;
	if (interpret_keystroke() != INPUT_PREVIOUS) exit(1);
	feed_key = INPUT_SELECT;
	if (interpret_keystroke() != INPUT_SELECT) exit(1);
	feed_key = INPUT_FINISH;
	if (interpret_keystroke() != INPUT_FINISH) exit(1);
	feed_key = INPUT_UNDO;
	if (interpret_keystroke() != INPUT_UNDO) exit(1);
	feed_key = INPUT_START_AGAIN;
	if (interpret_keystroke() != INPUT_START_AGAIN) exit(1);

	/* TEST DDS3.2.26: Get Keystrokes */
	if (strcmp(get_keystrokes(), "UDNPSX") != 0) exit(1);

	/* TEST DDS3.2.10: Delete All Keystrokes */
	delete_keystrokes();

	if (strcmp(get_keystrokes(), "") != 0) exit(1);

	/* Similate someone smashing one key over and over */
	feed_key = INPUT_DOWN;
	for (i = 0; i < 20000; i++) 
		if (interpret_keystroke() != feed_key) exit(1);

	p = get_keystrokes();
	for (i = 0; i < 20000; i++) 
		if (p[i] != 'D') exit(1);

	if (p[i] != '\0') exit(1);
	exit (0);
}
