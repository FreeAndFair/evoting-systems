/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include <stdbool.h>
#include "input.h"
#include "initiate_session.c"
#include <stdlib.h>
#include <unistd.h>


static enum input_event ks;
unsigned int number_of_keystrokes; 

void get_event(void);

bool verify_init_barcode(struct barcode *bc)
{
	return true;
}

enum input_event get_keystroke_or_barcode(struct barcode *bc)
{
	if (number_of_keystrokes-- > 0)
		return ks;
	else
		return INPUT_BARCODE;
}

void get_event(void)
{
	return;
}


/* Wait for end of the world */
void wait_for_reset(void)
{
	/* get_event handles RESET internally */
	while (true) get_event();
}
#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

struct audio *get_audio(const char *fmt, ...)
{
	return NULL;
}

void play_audio(bool interrupt, struct audio *audio)
{
}

void play_audio_loop(bool interrupt, struct audio *audio)
{
}

int main(void)
{
       	int i;

	if(!initialise_display(false))
		exit(1);

	/* TEST DDS3.2.2: Format Welcome Screen */
	welcome_screen();
	if (get_language() != 0)
		exit(1);
	/* TEST DDS3.2.2: Update Language */
	update_language(2);
	if (get_language() != 2)
		exit(1);
	/* TEST DDS3.2.2: Get Language */
	if (get_language() != 2)
		exit(1);
	/* TEST DDS3.2.2: Set Language */
	set_language(0);
	
	if (get_language() != 0)
		exit(1);
	set_language(2);
	update_language(0);
	//sleep(5);

	/* TEST DDS3.2.2: Wait for Language Selection */
	ks = INPUT_DOWN;
	for (i=1; i<=15; i++) {
		update_language(0);
		number_of_keystrokes = i;
		wait_for_language();
	}
	if (get_language() != 3)
		exit(1);

	ks = INPUT_UP;
	update_language(0);
	for (i=1; i<=15; i++) {
		update_language(0);
		number_of_keystrokes = i;
		wait_for_language();
	}
	if (get_language() != 9) 
		exit(1);
	
	update_language(get_language());
	
	/* TEST DDS3.2.2: Initiate Session */
	clear_screen();
	number_of_keystrokes = 5;
	init_session();
	if (get_language() != 7) 
		exit(1);
			       
	exit(0);
}

