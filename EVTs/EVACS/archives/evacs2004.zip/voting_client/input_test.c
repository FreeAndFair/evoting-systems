/* This file is (C) copyright 2001 Software Improvements, Pty Ltd.
   Based on prototypes/Graph-c-booth/simulator.c:
	   Copyright (C) Andrew Tridgell 2001
*/

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "input.c"
#include "message.h"
#include "verify_barcode.h"
#include "initiate_session.h"

#include <stdio.h>

#define BARCODE "baAkanqF&Yboct&fuWY7aN"

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

static void send_barcode_event(void)
{
	XEvent ev;

	/* Set up X event to send to parent */
	memset(&ev, 0, sizeof(ev));
	ev.type = ClientMessage;
	ev.xclient.message_type = XInternAtom(get_display(),
					      "barcode",
					      False);
	ev.xclient.format = 8;

	if (!XSendEvent(get_display(), InputFocus, True, 0, &ev))
		exit(1);

	/* Flush to make sure it arrives */
	XSync(get_display(), False);
}

static void send_key(unsigned int xkey)
{
	XKeyEvent event;
	static int count;

	memset(&event, 0, sizeof(event));

	event.serial = count++;
	event.type = KeyPress;
	event.send_event = 1;
	event.same_screen = 1;
	event.window = InputFocus;
	event.subwindow = InputFocus;
	event.keycode = xkey;

	XSendEvent(get_display(),
		   InputFocus, True, KeyPressMask, (XEvent *)&event);

	XSync(get_display(), False);

	event.serial = count++;
	event.type = KeyRelease;

	XSendEvent(get_display(),
		   InputFocus, True, KeyReleaseMask, (XEvent *)&event);

	XSync(get_display(), False);
}

/* stub */
unsigned int get_language(void)
{
	return 1;
}

struct audio *get_audio(const char *fmt, ...)
{
	return NULL;
}

void play_audio(bool interrupt, struct audio *audio)
{
}

void play_audio_loop(bool interrupt, struct audio *audio)
{
}

void play_multiaudio_loop(bool interrupt, 
			  unsigned int num_samples,
			  struct audio *audio[num_samples])
{
}

void audio_shutdown(void)
{
}

int main(int argc, const char *argv[])
{
	unsigned int i;

	/* Open display, events in window */
	if (!initialise_display(false)) exit(1);

	/* TEST DDS???: Get Keystroke */
	for (i = 0; i < sizeof(keymap)/sizeof(keymap[0]); i++) {
		enum input_event e;

		send_key(keymap[i].xkey);
		e = get_keystroke();
		if (e != keymap[i].evacs_key) exit(1);
	}

	/* Test get_keystroke_or_barcode() */
	for (i = 0; i < sizeof(keymap)/sizeof(keymap[0]); i++) {
		enum input_event e;
		struct barcode bc;

		send_key(keymap[i].xkey);
		e = get_keystroke_or_barcode(&bc);
		if (e != keymap[i].evacs_key) exit(1);
	}

	/* TEST DDS???: Read Barcode */ 
	{
		int pipeend[2];
		struct barcode bc;
		enum input_event e;

		if (pipe(pipeend) != 0) exit(1);
		pipe_from_child = pipeend[0];

		/* -1 so the \0 isn't included */
		write(pipeend[1], BARCODE, sizeof(BARCODE)-1);
		write(pipeend[1], "\n", 1);
		send_barcode_event();
	
		e = get_keystroke_or_barcode(&bc);
		if (e != INPUT_BARCODE) exit(1);
		if (strcmp(bc.ascii, BARCODE) != 0) exit(1);
		} 

	/* Finally, integrated test requires interaction */
	if (argc == 2) {
		bool ChecksumOK = false;
		/* Creates barcode-reading child */
		if (!initialize_input()) exit(1);

		/* Exit should be via reset combination */
		while (true) {
			struct barcode bc;

			switch (get_keystroke_or_barcode(&bc)) {
			case INPUT_UP: printf("UP\n"); break;
			case INPUT_DOWN: printf("DOWN\n"); break;
			case INPUT_NEXT: printf("NEXT\n"); break;
			case INPUT_PREVIOUS: printf("PREVIOUS\n"); break;
			case INPUT_SELECT: printf("SELECT\n"); break;
			case INPUT_FINISH: printf("FINISH\n"); break;
			case INPUT_UNDO: printf("UNDO\n"); break;
			case INPUT_START_AGAIN: printf("START AGAIN\n"); break;
			case INPUT_BARCODE:
				printf("Barcode: `%s'\n", bc.ascii);
				ChecksumOK = verify_init_barcode(&bc);
				if (ChecksumOK) {
					printf("Check sum ok\n");
				} else {
					printf("Check sum failed\n");
				}

				break;
			default:
				printf("Unknown key return!\n");
				exit(1);
			}
		}
	} else
		exit(0);
}
