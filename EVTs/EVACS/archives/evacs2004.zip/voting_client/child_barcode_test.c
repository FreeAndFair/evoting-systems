/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "child_barcode.c"

#define BARCODE_FILE "voting_client/test_data/barcode.input"
/* This matches the barcode in BARCODE_FILE */
#define BARCODE "baAkanqF&Yboct&fuWY7aN"

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

int main(int argc, const char *argv[])
{
	if (argc == 2) {
		child_barcode(STDOUT_FILENO);
		exit(1);
	}
		
	/* Test open_serial */
	close(open_serial(SERIAL_DEVICE));

	/* Test send_barcode */
	{
		int pipeend[2];
		char barcode[sizeof(BARCODE)+1];
		int r;

		if (pipe(pipeend) != 0) exit(1);

		send_barcode(XOpenDisplay(NULL), BARCODE, pipeend[1]);
		/* Barcode should be in pipe */
		r = read(pipeend[0], barcode, sizeof(barcode));

		/* +1 since a /n is added to the barcode */
		if (r != sizeof(BARCODE))
			exit(1);
		if (memcmp(barcode, BARCODE, sizeof(BARCODE)) != 0)
			exit(1);

		close(pipeend[0]);
		close(pipeend[1]);
	}

	/* TEST DDS????: Read Barcode */
	{
		/* Needs to be done in child, as it will die after
                   first "barcode" */
		int pipeend[2];
		int r;
		char barcode[sizeof(BARCODE)+1];
		int fake_serial = open(BARCODE_FILE, O_RDONLY);

		if (fake_serial < 0) exit(1);
		if (pipe(pipeend) != 0) exit(1);

		if (fork() == 0) {
			/* Shutup, kid */
			close(STDERR_FILENO);
			/* Child does read barcode */
			read_barcode(XOpenDisplay(NULL),
				     fake_serial,
				     pipeend[1]);
		}

		/* Barcode should be in pipe */
		r = read(pipeend[0], barcode, sizeof(barcode));
		if (r != sizeof(BARCODE))
			exit(1);

		if (memcmp(barcode, BARCODE, sizeof(BARCODE)) != 0)
			exit(1);
		close(pipeend[0]);
		close(pipeend[1]);
	}

	exit(0);
}
