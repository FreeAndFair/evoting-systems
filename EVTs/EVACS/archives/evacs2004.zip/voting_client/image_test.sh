#! /bin/sh

# Test that width reported is correct.
# Remember: this is run from the top directory!

WIDTH=`grep '^#define WINDOW_WIDTH' voting_client/image.c | cut -d\  -f3`
[ -n "$WIDTH" ] || exit 1

# TEST DDS3.2.11: Get Screen Width
./voting_client/image_test $WIDTH || exit 1

# Success
exit 0
