/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "get_rotation.c"
#include <stdlib.h>

/* Stub */
void display_error(enum error err)
{
	abort();
}

int main()
{
	const struct rotation *rot;
	struct electorate *elec;
	unsigned int i;

	elec = malloc(sizeof(*elec) + sizeof("TestElectorate"));
	strcpy(elec->name, "TestElectorate");
	elec->num_seats = 7;
	elec->code = 0;

	/* TEST DDS3.2.6: Get Rotation */
	/* TEST DDS3.2.6: Save Rotation */
	get_rotation(elec);

	if (current_rotation.size != elec->num_seats) exit(1);
	/* Each number once */
	for (i = 0; i < current_rotation.size; i++) {
		unsigned int j;
		for (j = 0; current_rotation.rotations[j] != i; j++) {
			if (j == current_rotation.size) exit(1);
		}
	}
	free(elec);

	elec = malloc(sizeof(*elec) + sizeof("TestElectorate2"));
	strcpy(elec->name, "TestElectorate2");
	elec->num_seats = 5;
	elec->code = 1;

	get_rotation(elec);
	if (current_rotation.size != elec->num_seats) exit(1);
	/* Each number once */
	for (i = 0; i < current_rotation.size; i++) {
		unsigned int j;
		for (j = 0; current_rotation.rotations[j] != i; j++) {
			if (j == current_rotation.size) exit(1);
		}
	}
	free(elec);

	/* TEST DDS3.2.12: Get Current Rotation */
	rot = get_current_rotation();
	if (rot->size != elec->num_seats) exit(1);
	/* Each number once */
	for (i = 0; i < rot->size; i++) {
		unsigned int j;
		for (j = 0; rot->rotations[j] != i; j++) {
			if (j == rot->size) exit(1);
		}
	}
	free(elec);

	exit(0);
}
