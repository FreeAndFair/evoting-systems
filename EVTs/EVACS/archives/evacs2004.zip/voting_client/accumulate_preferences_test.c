/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "accumulate_preferences.c"
#include <stdlib.h>
#include "initiate_session.h"
#include "input.h"
#include "vote_in_progress.h"
#include <common/authenticate.h>
#include <common/ballot_contents.h>

static struct rotation rot5 = { 5, { 1, 2, 3, 4, 5 } };
static struct rotation *curr_rotation;
static struct preference_set prefs = { 0,  {} };
struct ballot_contents bc = {8,{4,2,1,5,3,2,4,3}};
struct electorate *voter_electorate;
static unsigned int language = 0; 
enum input_event startkey[3] = {INPUT_SELECT,INPUT_DOWN,INPUT_SELECT};
bool confirm[2] = {true,false};
unsigned int number_of_keystrokes = 0;
unsigned int num = 0, num2 = 0;
enum input_event key[30] = {INPUT_UP,INPUT_SELECT,INPUT_START_AGAIN,INPUT_DOWN,
			    INPUT_DOWN,INPUT_SELECT,INPUT_NEXT,INPUT_NEXT,
			    INPUT_NEXT,INPUT_NEXT,INPUT_UP,INPUT_UP,
			    INPUT_SELECT,INPUT_PREVIOUS,INPUT_DOWN,INPUT_DOWN,
			    INPUT_DOWN,INPUT_SELECT,INPUT_DOWN,INPUT_UNDO,
			    INPUT_DOWN,INPUT_START_AGAIN,INPUT_DOWN,
			    INPUT_SELECT,INPUT_PREVIOUS,INPUT_FINISH,INPUT_UP,
			    INPUT_SELECT,INPUT_UP,INPUT_FINISH}; 
static char *ordered_keystrokes = NULL;
bool slow;
bool confirm_and_commit_vote(unsigned int language);
void child_barcode(int p);
void get_event(void);
/* Stubs */
void child_barcode(int p)
{}

unsigned int get_language(void)
{
	return(language);
}          

void delete_prefs(void)
{
        prefs.num_preferences = 0;
}

void add_candidate(unsigned int group_index,
                   unsigned int db_candidate_index)
{
        prefs.candidates[prefs.num_preferences]
                .group_index = group_index;
        prefs.candidates[prefs.num_preferences]
                .db_candidate_index = db_candidate_index;
	prefs.candidates[prefs.num_preferences].prefnum 
		= prefs.num_preferences + 1;
        prefs.num_preferences++;
}

const struct rotation *get_current_rotation(void)
{
	return curr_rotation;
}

const struct preference_set *get_vote_in_progress(void)
{
	return &prefs;
}

bool remove_last_pref(struct preference *undone_pref)
{
	if (prefs.num_preferences == 0)
		return false;
	prefs.num_preferences--;
	*undone_pref = prefs.candidates
		[prefs.num_preferences];
	return true;
}

const struct electorate *get_voter_electorate(void)
{
	return voter_electorate;
}

struct ballot_contents *get_ballot_contents(void)
{
	return &bc;
}

void delete_keystrokes(void)
{
        free(ordered_keystrokes);
        ordered_keystrokes = NULL;
}

const char *get_keystrokes(void)
{
        if (ordered_keystrokes == NULL) return "";
        else return ordered_keystrokes;
}

void get_event(void)
{
	return;
}

void wait_for_reset(void)
{
	while (true) get_event();
}

enum input_event interpret_keystroke(void)
{
	if (slow) sleep(1);
	return key[number_of_keystrokes++];
}

enum input_event get_keystroke(void)
{
	if (slow) sleep(1);
	return startkey[num++];
}

void get_rotation(const struct electorate *electorate)
{
}

bool confirm_and_commit_vote(unsigned int language)
{
	if (slow) sleep(1);
	return confirm[num2++];
}

int main(int argc, char *argv[])
{
	char electorate_name[9];
		     
	if (argc == 2) slow = true;
	curr_rotation = &rot5;

	audio_init();
	if(!initialise_display(false))
		exit(1);
	/* Setup data */
	strcpy(electorate_name,"Molonglo");

	voter_electorate = malloc(sizeof(struct electorate) 
				  + strlen(electorate_name)+1);

	voter_electorate->code = 1;
	voter_electorate->num_seats = 5;
	strcpy(voter_electorate->name, "Molonglo");

	accumulate_preferences();

	exit(0);
}





