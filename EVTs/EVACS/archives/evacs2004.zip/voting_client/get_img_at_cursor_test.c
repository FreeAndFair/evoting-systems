/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "get_img_at_cursor.c"
#include <stdbool.h>
#include <limits.h>
#include <string.h>

#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif

static struct rotation rot5 = { 5, { 5, 4, 3, 1, 2 } };
static struct rotation *curr_rotation;
static struct preference_set prefs = { 1, { { 1, 2, 1 } } };
static struct {
	struct electorate elec;
	char name[80];
} elec = {{ NULL, 1, 7 }, "TEST ELECTORATE"};
static struct {
	struct ballot_contents bc;
	unsigned int num_candidates[5];
} bc = { { 5 }, { 1, 2, 3, 4, 5 } };
static unsigned int expected_prefnum;
static unsigned int expected_group_index;
static unsigned int expected_dbci;

/* Stub functions */
const struct electorate *get_voter_electorate(void)
{
	return &elec.elec;
}

const struct rotation *get_current_rotation(void)
{
	return curr_rotation;
}

const struct preference_set *get_vote_in_progress(void)
{
	return &prefs;
}

struct image *get_preference_image(unsigned int ecode, unsigned int prefnum)
{
	if (ecode != elec.elec.code) exit(1);
	if (prefnum != expected_prefnum) exit(1);
	return (struct image *)0x7e57f00d;
}

struct image *get_group_image(unsigned int ecode, unsigned int group_index)
{
	if (ecode != elec.elec.code) exit(1);
	if (group_index != expected_group_index) exit(1);
	return (struct image *)0xdeadbeef;
}

struct image *get_candidate_image(unsigned int ecode,
				  unsigned int group_index,
				  unsigned int dbci)
{
	if (ecode != elec.elec.code) exit(1);
	if (group_index != expected_group_index) exit(1);
	if (dbci != expected_dbci) exit(1);
	return (struct image *)0xbeefdead;
}

struct ballot_contents *get_ballot_contents(void)
{
	return &bc.bc;
}

struct audio *get_audio(const char *fmt, ...)
{
	return NULL;
}

void play_audio(bool interrupt, struct audio *audio)
{
}

void play_audio_loop(bool interrupt, struct audio *audio)
{
}

void play_multiaudio_loop(bool interrupt, 
			  unsigned int num_samples,
			  struct audio *audio[num_samples])
{
}
	
int main()
{
	struct cursor cursor;
	struct image_set iset;
	struct audio *audio;

	curr_rotation = &rot5;

	/* TEST DDS3.2.12: Get Preference Image for Candidate */
	expected_prefnum = 1;
	if (get_pref_img_for_candidate(&elec.elec, 1, 2, &audio)
	    != (void *)0x7e57f00d)
		exit(1);
	expected_prefnum = 0;
	if (get_pref_img_for_candidate(&elec.elec, 1, 1, &audio)
	    != (void *)0x7e57f00d)
		exit(1);

	/* TEST DDS3.2.12: Get Image Under Cursor */
	cursor.group_index = 0;
	cursor.screen_candidate_index = -1;
	expected_group_index = cursor.group_index;
	iset = get_img_at_cursor(&cursor);
	if (iset.prefnumber != NULL || iset.candidate != NULL) exit(1);
	if (iset.group != (void *)0xdeadbeef) exit(1);

	/* Map candidate zero, group zero (which has 1 candidate
	   according to bc), and we wil get dbci = 0. */
	cursor.screen_candidate_index = 0;
	expected_dbci = 0;
	iset = get_img_at_cursor(&cursor);
	if (iset.group != NULL) exit(1);
	if (iset.prefnumber != (void *)0x7e57f00d
	    || iset.candidate != (void *)0xbeefdead)
		exit(1);

	/* Map candidate zero, group one (which has 2 candidates), and
	   we will get dbci = 1 */
	cursor.group_index = 1;
	expected_group_index = 1;
	expected_dbci = 1;
	iset = get_img_at_cursor(&cursor);
	if (iset.group != NULL) exit(1);
	if (iset.prefnumber != (void *)0x7e57f00d
	    || iset.candidate != (void *)0xbeefdead)
		exit(1);

	exit(0);
}
