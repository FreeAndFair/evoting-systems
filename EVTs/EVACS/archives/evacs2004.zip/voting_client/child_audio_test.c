/* This file is (C) copyright 2001 Software Improvements, Pty Ltd. */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "child_audio.c"
#include <sys/stat.h>

#define AUDIO_SAMPLE "voting_client/test_data/inigo.raw"

int main(int argc, char *argv[])
{
	struct stat st;
	const char *name;
	int fd;

	if (argc > 1)
		name = argv[1];
	else
		name = AUDIO_SAMPLE;

	stat(name, &st);

	fd = open(name, O_RDONLY, 0);
	{
		char buffer[st.st_size];
		int audio_fd;

		read(fd, buffer, st.st_size);
		
		audio_fd = open_audiodev("/dev/dsp");
		/* Round down to fragsize */
		st.st_size = st.st_size / fragsize * fragsize;

		if (argc == 3) {
			unsigned int upto = 0;
			struct play_list list;
			list.next = NULL;
			list.command = AUDIO_LOOP;
			list.buffer = buffer;
			list.bufsize = st.st_size;
			do {
				char buf[20];
				play(0, audio_fd, &list, &upto);
				read(0, buf, sizeof(buf));
			} while(1);
			exit(0);
		}
		if (play_sample(0, audio_fd, buffer, st.st_size)
		    != st.st_size)
			exit(1);

		/* Files always return true for reading immediately */
		if (play_sample(fd, audio_fd, buffer, st.st_size)
		    != AUDIO_INPUT_RATE/4)
			exit(1);
		close(fd);
	}
	exit(0);
}
