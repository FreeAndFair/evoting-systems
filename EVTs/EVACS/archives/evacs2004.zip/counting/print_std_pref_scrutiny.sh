#! /bin/sh
# Post-process scrutiny sheets for a 'standard preferential'count 
# (C) 2003 Software Improvements Pty Ltd.
#

# If printer is postscript, set this to 1
POSTSCRIPT=0

# printer type for non-postcript printers (as known to ghostscript)
PRINTER_DEVICE="lj4dith"
PAPERSIZE="a4"
OUTPUTDIR="/tmp"

# root directory (where the scripts are)
ROOT=`pwd`

# command to convert ps into bitmap
GSCOMMAND="gs -q -sDEVICE=$PRINTER_DEVICE -r600x600 -sPAPERSIZE=$PAPERSIZE -dNOPAUSE -dSAFER -sOutputFile=$OUTPUTDIR/raw"

# post-process ps to BOLD 'so& so was elected n' statements in table2
elections=$OUTPUTDIR/election*_table2.ps;
for file in $elections; do
    num_elections=$((num_elections + 1))
    elec_nums="$elec_nums $num_elections"
done

#echo number of elections: $num_elections
#echo $elec_nums

for election in $elec_nums;do
    echo Election $election:
    echo ----------
#    echo $election
#    echo     $ROOT/bold_elected $OUTPUTDIR/election${election}_table2.ps
    $ROOT/bold_elected $OUTPUTDIR/election${election}_table2.ps
#    echo     mv $OUTPUTDIR/election${election}_table2.ps.bold  $OUTPUTDIR/election${election}_table2.ps
    mv $OUTPUTDIR/election${election}_table2.ps.bold  $OUTPUTDIR/election${election}_table2.ps
    rm -f  $OUTPUTDIR/election${election}_table2.ps.bold
    
# Centre postscript output on a3/a4 page.
    $ROOT/normalise.sh $PAPERSIZE $OUTPUTDIR/election${election}_table1.ps $OUTPUTDIR/election${election}_table2.ps

#    if [ $POSTSCRIPT -eq 0 ]; then
    # FOR NON-POSTSCRIPT PRINTER
#	for file in $OUTPUTDIR/table*.ps.*; do
#	    $GSCOMMAND $file < $ROOT/quit
#	    lpr $OUTPUTDIR/raw	   
#	done
#    else
	# FOR POSTSCRIPT PRINTER
#	lpr $OUTPUTDIR/table1.ps.*
#	lpr $OUTPUTDIR/table2.ps.*
#    fi

cp  $OUTPUTDIR/election${election}*.ps.* $ROOT
cp  $OUTPUTDIR/election${election}*.raw $ROOT
done
# remove normalised pages ready for another scrutiny
#rm -f $OUTPUTDIR/election*

exit 0	







