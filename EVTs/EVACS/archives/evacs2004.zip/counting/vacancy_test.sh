#! /bin/sh

echo -e "Molonglo\nCandidate B4\n\nCandidate A1\ny\ny\ny\ny\ny\ny\ny\ny\ny\n" | counting/vacancy_test foo
