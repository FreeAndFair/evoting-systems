#! /bin/sh

echo -e "Molonglo\n\nCandidate A1\n" | counting/hare_clarke_test foo
