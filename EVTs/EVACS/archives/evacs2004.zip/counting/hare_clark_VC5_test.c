/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#define main xmain
int xmain(int argc, char *argv[]);
#include "hare_clark.c"
#undef main

struct a_elec {
	struct electorate elec;
	char name[80];
};

static struct a_elec electorate = { { NULL, 1, 5 }, "Brindabella" };

static struct group mygroups[]
= {{ (char *)"Independent", 0 }};

static struct candidate cands[] 
= { { 0, (char *)"Bill WOOD", &mygroups[0] },
    { 1, (char *)"Trevor KAINE", &mygroups[0] },
    { 2, (char *)"Brendan SMYTH", &mygroups[0] },
    { 3, (char *)"Paul OSBORNE", &mygroups[0] },
    { 4, (char *)"John HARGREAVES", &mygroups[0] },
    { 5, (char *)"Louise LITTLEWOOD", &mygroups[0] } };

#define NUM_CANDIDATES (sizeof(cands)/sizeof(cands[0]))

/* Case-insensitive search for electorate: NULL if not found. */
struct electorate *fetch_electorate(PGconn *conn, const char *ename)
{
	if (strcmp(ename, electorate.elec.name) == 0)
		return &electorate.elec;
	return NULL;
}

/* Given the non-NULL electorate, fill in all the groups, return number. */
unsigned int fetch_groups(PGconn *conn, 
			  const struct electorate *elec,
			  struct group *groups)
{
	unsigned int i;

	for (i = 0; i < sizeof(mygroups)/sizeof(mygroups[0]); i++) {
		groups[i] = mygroups[i];
		groups[i].name = strdup(mygroups[i].name);
	}

	return i;
}

/* Given the group information, return the candidate list */
struct cand_list *fetch_candidates(PGconn *conn, 
				   const struct electorate *elec,
				   struct group *groups)
{
	int i;
	struct cand_list *list = NULL;

	/* We prepend to list, so do this backwards */
	for (i = NUM_CANDIDATES-1; i >= 0; i--) {
		struct candidate *cand = malloc(sizeof(*cand));
		*cand = cands[i];
		cand->name = strdup(cands[i].name);
		/* Prepend to list */
		list = new_cand_list(cand, list);
		list->cand->scrutiny_pos = i;
	}
	return list;
}

static struct ballot_list *gen_prefs(struct ballot_list *list,
				     unsigned int num_ballots,
				     unsigned int num_prefs, ...)
{
	unsigned int i;
	size_t ballot_size;
	struct ballot *ballot;
	va_list ap;

	ballot_size = sizeof(*ballot) + sizeof(ballot->prefs[0])*num_prefs;
	/* Create one ballot */
	va_start(ap, num_prefs);
	ballot = malloc(ballot_size);
	ballot->num_preferences = num_prefs;
	for (i = 0; i < num_prefs; i++) {
		struct candidate *cand;

		cand = &cands[va_arg(ap, unsigned int)];
		
		ballot->prefs[i].db_candidate_index = cand->db_candidate_index;
		ballot->prefs[i].group_index = cand->group->group_index;
	}
	va_end(ap);

	/* Create all the ballots */
	for (i = 0; i < num_ballots; i++) {
		struct ballot_list *tmp;

		tmp = malloc(sizeof(*tmp));
		tmp->next = list;
		tmp->ballot = malloc(ballot_size);
		memcpy(tmp->ballot, ballot, ballot_size);
		list = tmp;
	}
	free(ballot);
	return list;
}

/* Get all the ballots for this electorate */
struct ballot_list *fetch_ballots(PGconn *conn, const struct electorate *elec)
{
	struct ballot_list *list = NULL;

	/* 12 SMYTH */
	list = gen_prefs(list, 12, 1, 2);
	/* 1 SMYTH OSBOURNE */
	list = gen_prefs(list, 1, 2, 2, 3);
	/* 1 SMYTH OSBOURNE LITTLEWOOD */
	list = gen_prefs(list, 1, 3, 2, 3, 5);
	/* 3 SMYTH OSBOURNE WOOD */
	list = gen_prefs(list, 3, 3, 2, 3, 0);
	/* 1 SMYTH OSBOURNE WOOD HARGREAVES */
	list = gen_prefs(list, 1, 4, 2, 3, 0, 4);
	/* 4 SMYTH OSBOURNE KAINE LITTLEWOOD */
	list = gen_prefs(list, 4, 4, 2, 3, 1, 5);
	/* 1 SMYTH WOOD */
	list = gen_prefs(list, 1, 2, 2, 0);
	/* 1 SMYTH KAINE */
	list = gen_prefs(list, 1, 2, 2, 1);
	/* 4 OSBOURNE */
	list = gen_prefs(list, 4, 1, 3);
	/* 2 OSBOURNE WOOD */
	list = gen_prefs(list, 2, 2, 3, 0);
	/* 2 OSBOURNE KAINE */
	list = gen_prefs(list, 2, 2, 3, 1);
	/* 1 OSBOURNE LITTLEWOOD */
	list = gen_prefs(list, 1, 2, 3, 5);
	/* 2 WOOD */
	list = gen_prefs(list, 2, 1, 0);
	/* 1 WOOD HARGREAVES */
	list = gen_prefs(list, 1, 2, 0, 4);
	/* 1 KAINE */
	list = gen_prefs(list, 1, 1, 1);
	/* 2 KAINE LITTLEWOOD */
	list = gen_prefs(list, 2, 2, 1, 5);
	/* 9 HARGREAVES */
	list = gen_prefs(list, 9, 1, 4);
	/* 7 LITTLEWOOD */
	list = gen_prefs(list, 7, 1, 5);
	return list;
}

PGconn *connect_db(const char *name)
{
	return NULL;
}

void free_electorates(struct electorate *e)
{
	if (e != &electorate.elec) exit(1);
}

/* Debugger use function */
static bool dump_candidate(struct candidate *cand, void *unused)
{
	printf("  %s (%s): ", cand->name, cand->group->name);
	switch (cand->status) {
	case CAND_CONTINUING: printf("CONTINUING\n"); break;
	case CAND_EXCLUDED: printf("EXCLUDED\n"); break;
	case CAND_ELECTED: printf("ELECTED\n"); break;
	case CAND_PENDING: printf("PENDING\n"); break;
	case CAND_BEING_EXCLUDED: printf("BEING_EXCLUDED\n"); break;
	default: printf("UNKNOWN\n"); break;
	}
	return false;
}	

static void print_candidates(struct cand_list *list) __attribute__((unused));
static void print_candidates(struct cand_list *list)
{
	for_each_candidate(list, &dump_candidate, NULL);
}

static char *load_file(const char *filename)
{
	struct stat stbuf;
	int fd;
	char *ret;

	fd = open(filename, O_RDONLY, 0);
	fstat(fd, &stbuf);

	ret = malloc(stbuf.st_size + 1);
	read(fd, ret, stbuf.st_size);
	ret[stbuf.st_size] = '\0';
	close(fd);

	return ret;
}

int main(int argc, char *argv[])
{
	int status;
	int pipeends[2];
	char *file;

	pipe(pipeends);

	if (argc > 1 || !fork()) {
		if (argc == 1) dup2(pipeends[0], STDIN_FILENO);
		xmain(argc, argv);
		exit(0);
	}
		
	write(pipeends[1], electorate.name, strlen(electorate.name));
	write(pipeends[1], "\n\n", strlen("\n\n"));
	write(pipeends[1], "Trevor KAINE\n", strlen("Trevor KAINE\n"));
	wait(&status);
	if (!WIFEXITED(status) || WEXITSTATUS(status) != 0)
		exit(1);

	/* Suck in table 2, and search for the candidates in the
           correct order */
	file = load_file("table2.ps");
	if (strstr(file, "Trevor KAINE chosen for exclusion tiebreak") == 0)
		exit(1);
	file = strstr(file, "Brendan SMYTH elected.");
	file = strstr(file, "Paul OSBORNE elected.");
	file = strstr(file, "Trevor KAINE fully excluded.");
	file = strstr(file, "Louise LITTLEWOOD elected.");
	/* Order for last two doesn't matter */
	if (!strstr(file, "Bill WOOD elected.")
	    || !strstr(file, "John HARGREAVES elected."))
		exit(1);

	exit(0);
}
