#! /bin/sh

# Read file in, convert CR to CR/LF pairs to avoid "stairstep" effect

cat "$1" | while read LINE; do
	echo "$LINE"
	echo -ne \\r
done | lpr
