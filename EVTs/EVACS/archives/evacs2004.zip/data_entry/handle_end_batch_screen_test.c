/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include "handle_end_batch_screen.c"

enum deo_keystroke key;

enum deo_keystroke interpret_deo_keystroke(void)
{
	return key;
}
unsigned int get_current_batch_number(void)
{
	return 1;
}
int main(int argc, char *argv[])
{
	/* TEST DDS3.24: Handle END BATCH Screen */
	bool result;
	
	key = DEO_KEYSTROKE_DELETE;
	if (argc == 2) {
		result = handle_end_batch_screen();
		if(result) exit(1);
	}
	
	key = DEO_KEYSTROKE_DOWN;
	if (argc == 2) {
		result = handle_end_batch_screen();
		if(!result) exit(1);
	}
	
	exit(0);
}
