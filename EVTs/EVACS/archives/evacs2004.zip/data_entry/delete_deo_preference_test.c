/* This file is (C) copyright 2001 Software Improvements, Pty Ltd */

/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include <stdlib.h>
#include <string.h>
#include "delete_deo_preference.c"
#include "update_deo_preference.h"
#include "interpret_deo_keystroke.h"
#include <voting_client/verify_barcode.h>

struct ballot_contents bc = {8,{4,2,1,3,2,2,4,3}};
static struct rotation rot5 = { 5, { 1,2,3,4,5 } };
static struct rotation *curr_rotation = &rot5;
struct cursor current_cursor = {-1,0};
struct electorate *voter_electorate;
unsigned int get_language(void);
unsigned int get_language(void)
{
	return 0;
}
void wait_for_reset(void)
{
	while (true);
}
const struct electorate *get_voter_electorate(void)
{
	return voter_electorate;
}

struct cursor get_cursor_position(void)
{
        return current_cursor;
}
void set_cursor_position(struct cursor cursor_position)
{
        current_cursor.group_index = cursor_position.group_index;
        current_cursor.screen_candidate_index
                = cursor_position.screen_candidate_index;
}
struct ballot_contents *get_ballot_contents(void)
{
	return &bc;
}
const struct rotation *get_current_rotation(void)
{
	return curr_rotation;
}
#if 0
#define exit(x) { fprintf(stderr, "%u\n", __LINE__); exit(x); }
#endif


int main(int argc, char *argv[])
{
	const struct preference_set *pref;
	struct cursor cursor;
	char electorate_name[9];
	unsigned int dbci;

	if(!initialise_display(false))
                exit(1);

	strcpy(electorate_name,"Molonglo");

	voter_electorate = malloc(sizeof(struct electorate) 
				  + strlen(electorate_name)+1);

	voter_electorate->code = 1;
	voter_electorate->num_seats = 5;
	strcpy(voter_electorate->name, "Molonglo");

	/* TEST DDS3.20: Delete Preference */
	add_candidate_with_pref(4,1,9);
	pref = get_vote_in_progress();
	if ((pref->num_preferences != 1)
            || (pref->candidates[0].group_index != 4)
            || (pref->candidates[0].db_candidate_index != 1)
            || (pref->candidates[0].prefnum != 9))
                exit(1);
	delete_preference(4,1);
	pref = get_vote_in_progress();
	if ((pref->num_preferences != 1)
            || (pref->candidates[0].group_index != 4)
            || (pref->candidates[0].db_candidate_index != 1)
            || (pref->candidates[0].prefnum != 0))
                exit(1);

	/* TEST DDS3.20: Delete DEO Preference */
	cursor.group_index = 4;
	cursor.screen_candidate_index = 0;
	dbci = translate_sci_to_dbci(bc.num_candidates[4],0,curr_rotation);
	set_cursor_position(cursor);
	update_deo_preference(DEO_KEYSTROKE_2);
	update_deo_preference(DEO_KEYSTROKE_0);
	if (argc == 2) sleep(1);
	delete_deo_preference();
	if (argc == 2) sleep(1);
	pref = get_vote_in_progress();
	if ((pref->num_preferences != 2)
            || (pref->candidates[1].group_index != 4)
            || (pref->candidates[1].db_candidate_index != dbci)
            || (pref->candidates[1].prefnum != 0))
                exit(1);
	
	exit(0);
}
