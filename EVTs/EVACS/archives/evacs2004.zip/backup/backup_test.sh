#! /bin/sh

# DDSv1D-3.2: Test End of Day Backup
# 
# The mod for teh zip driver must already be loaded;
#modprobe imm (or ppa for old zips) 
#
# Script to set up backup polling place electronic votes.
# the first argument is the name of the database to backup.
# defaults to evacs.
#run as root from the top directory


ZIP_DEVICE=/dev/sda4
ZIP_DIRECTORY=/mnt/zip

# We need vfat for long names.
MOUNT_OPTIONS="-t vfat"

# DDSv1D-3.2: Check Media
check_media()
{
    # Mount the zip drive
    mount $MOUNT_OPTIONS $ZIP_DEVICE $ZIP_DIRECTORY
    if [ $? != 0 ]; then
        # DDSv1D-3.2: Format Backup Error Message
	echo "Can't find zip disk: exiting."
	exit 1
    fi
}

eject_media()
{
    umount $ZIP_DEVICE
    # SCSI layer gives nasty-looking (harmless) messages, so suppress them.
    dmesg -n1
    eject $ZIP_DEVICE
    dmesg -n5
}


TMPFILE=`mktemp /tmp/example_bin_test.XXXXXX`
trap "rm $TMPFILE" EXIT

#Set up the test bds.  They are called evacs_backup_test.
OLD_DIR="`pwd`"
su - postgres -c"psql template1 <$OLD_DIR/backup/backup_test.dmp"
su - postgres -c"psql -p 5433 template1 <$OLD_DIR/backup/backup_test.dmp"

#Run the executable

echo put the zip disk in.
echo wait for it to load
echo press return.
echo the disk should pop out
echo
echo push the zip disk in.
echo wait for it to load
echo press return.

backup/backup.sh evacs_backup_test >$TMPFILE
if [ $? != 0 ]; then
		echo Backup script failed!
		exit 1
    	fi


#Check screen output
grep -q "Brindabella 0 , Ginninderra 2 , Molonglo 1 , votes in the master database" $TMPFILE || exit 1
grep -q "Brindabella 0 , Ginninderra 2 , Molonglo 1 , votes in the slave database" $TMPFILE || exit 2

#check the database on the zip disk. Are all the tables there?

 echo -n "Insert removable media for $TYPE, wait for the orange light to go off and press return:"
    read DISCARD

check_media

grep -q 'CREATE TABLE "brindabella_confirmed_vote"' ${ZIP_DIRECTORY}/master.dmp || (eject_media &&exit 3)
grep -q 'CREATE TABLE "molonglo_confirmed_vote"' ${ZIP_DIRECTORY}/master.dmp || (eject_media && exit 4)
grep -q 'CREATE TABLE "ginninderra_confirmed_vote"' ${ZIP_DIRECTORY}/master.dmp || (eject_media && exit 5)

eject_media

echo backup.sh test PASS
exit 0
